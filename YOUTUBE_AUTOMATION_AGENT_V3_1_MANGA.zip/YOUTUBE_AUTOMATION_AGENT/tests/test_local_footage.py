"""Test-only local footage mode: --local-footage sequential."""
import json
from pathlib import Path

import pytest

from core.job_manager import StageFailed
from core.media import ffmpeg, probe
from scripts import asset_manager
from tests.fixtures import tone_tts
from workflows.topic_to_video import TopicWorkflow


def clip(path: Path, secs=3, color="blue"):
    path.parent.mkdir(parents=True, exist_ok=True)
    ffmpeg(["-f", "lavfi", "-i", f"color=c={color}:s=320x180:r=25:d={secs}", "-pix_fmt", "yuv420p", path])


def stub(path: Path, license=None):                      # not a real video: only the scanner / selector is exercised
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"x")
    if license:
        Path(str(path) + ".license.json").write_text(json.dumps({"license": license}))


def script(n):
    return {"topic": "t", "sections": [{"id": f"s{i}", "title": "x", "kind": "body", "visual_hint": "ignored",
                                          "sentences": [{"text": "words"}]} for i in range(n)]}


def names(assets):
    return [Path(a["path"]).name for a in assets]


def test_ordering_is_by_filename_regardless_of_creation_order_and_ignores_non_video(tmp_path):
    lib = tmp_path / "assets"
    for n in ("c.mov", "B.mp4", "a.webm", "z.mkv", "d.txt", "e.jpg"):
        stub(lib / n, "CC0")
    sub = lib / "sub"
    stub(sub / "aa.mp4", "CC0")
    out = asset_manager.assign_local_sequential(script(5), lib, False)
    assert names(out) == ["a.webm", "aa.mp4", "B.mp4", "c.mov", "z.mkv"]
    assert names(out) == names(asset_manager.assign_local_sequential(script(5), lib, False))      # deterministic
    assert all(a["kind"] == "video" and a["local_footage"] == "sequential" for a in out)


def test_cycles_when_more_sections_than_clips(tmp_path):
    lib = tmp_path / "assets"
    stub(lib / "a.mp4", "CC0")
    stub(lib / "b.mp4", "CC0")
    out = asset_manager.assign_local_sequential(script(5), lib, False)
    assert names(out) == ["a.mp4", "b.mp4", "a.mp4", "b.mp4", "a.mp4"]
    assert [a["clip_cycle"] for a in out] == [0, 0, 1, 1, 2] and [a["section"] for a in out] == [f"s{i}" for i in range(5)]
    assert names(asset_manager.assign_local_sequential(script(1), lib, False)) == ["a.mp4"]       # fewer sections than clips


def test_licence_filtering(tmp_path):
    lib = tmp_path / "assets"
    stub(lib / "a_ok.mp4", "CC0")
    stub(lib / "b_unknown.mp4")
    stub(lib / "c_restricted.mp4", "All rights reserved")
    stub(lib / "d_nc.mp4", "CC BY-NC 4.0")
    out = asset_manager.assign_local_sequential(script(4), lib, False)
    assert set(names(out)) == {"a_ok.mp4"} and all(a["license_status"] == "ok" for a in out)
    out = asset_manager.assign_local_sequential(script(4), lib, True)             # --allow-unknown-assets
    assert names(out) == ["a_ok.mp4", "b_unknown.mp4", "a_ok.mp4", "b_unknown.mp4"]
    unk = out[1]
    assert unk["license_status"] == "unknown" and any("UNKNOWN" in w for w in unk["warnings"])
    assert not any("restricted" in n or "nc" in n for n in names(out))             # restricted never used, even with the flag


@pytest.mark.parametrize("setup,msg", [("empty", "no video files"), ("restricted", "none eligible"), ("unknown", "--allow-unknown-assets"),
                                       ("images", "no video files")])
def test_no_eligible_clips_fails_clearly(tmp_path, setup, msg):
    lib = tmp_path / "assets"
    lib.mkdir()
    if setup == "restricted":
        stub(lib / "a.mp4", "All rights reserved")
    elif setup == "unknown":
        stub(lib / "a.mp4")
    elif setup == "images":
        from PIL import Image
        Image.new("RGB", (8, 8)).save(lib / "a.jpg")
    with pytest.raises(asset_manager.NoEligibleFootage) as e:
        asset_manager.assign_local_sequential(script(2), lib, False)
    assert msg in str(e.value)


def test_workflow_fails_without_clips_and_makes_no_cards(env):
    tmp, s, _, jm = env
    wf = TopicWorkflow(jm, s, {}, tts=tone_tts())
    j = wf.create("How habits form", "en", duration_s=30, local_footage="sequential")
    with pytest.raises(StageFailed) as e:
        wf.run(j)
    assert "local footage mode" in str(e.value)
    jd = Path(s["paths"]["outputs"]) / j
    assert not list((jd / "assets").glob("card_*")) and jm.get_job(j)["status"] == "failed"


def test_unknown_mode_rejected_and_default_keyword_matching_unchanged(env, tmp_path):
    from providers.image_generation import get_image_provider
    from PIL import Image
    _, s, _, jm = env
    with pytest.raises(ValueError):
        TopicWorkflow(jm, s, {}).create("How habits form", "en", local_footage="random")
    lib = tmp_path / "lib"
    lib.mkdir()
    Image.new("RGB", (64, 64)).save(lib / "habits_cc0.jpg")
    Image.new("RGB", (64, 64)).save(lib / "aaa_first.jpg")
    (lib / "habits_cc0.jpg.license.json").write_text(json.dumps({"license": "CC0", "tags": ["habits"]}))
    sc = {"topic": "habits", "sections": [{"id": "s0", "title": "Hook", "kind": "hook", "visual_hint": "habits", "sentences": [{"text": "habits matter"}]},
                                          {"id": "s1", "title": "B", "kind": "body", "visual_hint": "zzz", "sentences": [{"text": "unrelated"}]}]}
    out = asset_manager.assign_assets(sc, lib, tmp_path / "o", get_image_provider(), 320, 180, "en")
    assert out[0]["path"].endswith("habits_cc0.jpg") and "local_footage" not in out[0]      # keyword match as before
    assert out[1]["source"] == "generated:local_cards"                                       # cards still used without the flag


def test_end_to_end_natural_render_records_clips_and_trims_to_section(tmp_path):
    from core.config import load_settings
    from core.database import open_database
    from core.job_manager import JobManager
    from tests.fixtures import NOTES
    d = tmp_path
    (d / "notes.txt").write_text(NOTES)
    clip(d / "assets" / "b_second.mp4", 3, "red")
    clip(d / "assets" / "a_first.mp4", 4, "blue")                          # shorter than the sections: must loop/trim, not fail
    (d / "assets" / "a_first.mp4.license.json").write_text(json.dumps({"license": "own", "source": "test"}))
    (d / "assets" / "b_second.mp4.license.json").write_text(json.dumps({"license": "CC0"}))
    s = load_settings(d, {"paths": {"outputs": str(d / "out"), "database": str(d / "a.db"), "assets": str(d / "assets"),
                                    "backups": str(d / "bk"), "logs": str(d / "l")}, "encoding": {"preset": "ultrafast", "crf": 32},
                          "topic_to_video": {"research": {"providers": ["manual"], "manual": {"paths": [str(d / "notes.txt")]}}}})
    jm = JobManager(open_database(d / "a.db", d / "bk"), s)
    wf = TopicWorkflow(jm, s, {}, tts=tone_tts())
    j = wf.create("How habits form", "en", duration_s=30, editing="natural", local_footage="sequential")
    out = wf.run(j)
    jd = d / "out" / j
    assets = json.loads((jd / "assets" / "assets.json").read_text())
    got = [(a["section"], Path(a["path"]).name, a["license_status"]) for a in assets]
    assert [g[1] for g in got[:3]] == ["a_first.mp4", "b_second.mp4", "a_first.mp4"] and all(a["kind"] == "video" for a in assets)
    assert all(g[2] == "ok" for g in got) and not list((jd / "assets").glob("card_*"))
    assert out["local_footage"][0] == {"section": got[0][0], "clip": assets[0]["path"], "license": "own", "license_status": "ok"}
    qa = jm.latest_qa(j, "video")
    names_ = {c["check"]: c for c in qa["checks"]}
    assert names_["local_footage_video_clips_only"]["ok"] and "a_first.mp4 (ok)" in names_["local_footage_assignments"]["detail"]
    v = probe(jd / "final_video" / "video.mp4")
    assert abs(v["duration"] - json.loads((jd / "narration" / "timeline.json").read_text())["duration"]) < 1 and (v["width"], v["height"]) == (1920, 1080)
