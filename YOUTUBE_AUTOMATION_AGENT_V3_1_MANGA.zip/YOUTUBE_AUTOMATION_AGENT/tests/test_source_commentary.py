"""YAA V3.1 Source-to-Commentary Video: inputs, extraction failures, grounding, review gate, workflow integration, V3 compatibility."""
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

from core.job_manager import StageFailed
from core.media import ffmpeg
from modules.source_commentary import extractors, ingest
from modules.source_commentary.sources import SourceError, detect_type, expand_sources
from providers.llm import LLMUnavailable
from scripts import commentary_script as cs
from scripts import script_generator
from tests.fixtures import tone_tts
from workflows.topic_to_video import TopicWorkflow

ROOT = Path(__file__).resolve().parent.parent
HAS_OCR = shutil.which("tesseract") is not None
HAS_PDF = shutil.which("pdftotext") is not None
needs_ocr = pytest.mark.skipif(not HAS_OCR, reason="tesseract not installed")
needs_pdf = pytest.mark.skipif(not HAS_PDF, reason="pdftotext not installed")

PARA1 = "Habits form through repeated cues and rewards. A cue triggers a routine and the reward makes the brain repeat it."
PARA2 = "Researchers found that environment design changes behavior more than motivation does."


# ---- builders ----------------------------------------------------------------------------------------------------
def make_pdf(path, pages):
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", None]
    kids = []
    for i, txt in enumerate(pages):
        pn, cn = 3 + 2 * i, 4 + 2 * i
        kids.append(f"{pn} 0 R")
        stream = f"BT /F1 12 Tf 50 700 Td ({txt}) Tj ET"
        objs += [f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents {cn} 0 R /Resources << /Font << /F1 {3 + 2 * len(pages)} 0 R >> >> >>",
                 f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream"]
    objs[1] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(pages)} >>"
    objs.append("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out, offs = b"%PDF-1.4\n", []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += f"{i} 0 obj\n{o}\nendobj\n".encode()
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode() + b"".join(f"{o:010d} 00000 n \n".encode() for o in offs)
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    Path(path).write_bytes(out)


def make_docx(path, paras):
    body = "".join(f"<w:p><w:r><w:t>{p}</w:t></w:r></w:p>" for p in paras)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("word/document.xml", '<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                                        f"<w:body>{body}</w:body></w:document>")


def make_pptx(path, slides):
    with zipfile.ZipFile(path, "w") as z:
        for i, t in enumerate(slides, 1):
            z.writestr(f"ppt/slides/slide{i}.xml", '<p:sld xmlns:p="p" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
                                                   f"<a:p><a:r><a:t>{t}</a:t></a:r></a:p></p:sld>")


def make_page(path, text, size=(900, 500)):
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new("RGB", size, "white")
    ImageDraw.Draw(im).text((40, size[1] // 2 - 30), text, fill="black", font=ImageFont.load_default(46))
    im.save(path)


def make_video(path, srt=True):
    ffmpeg(["-f", "lavfi", "-i", "color=c=red:s=320x180:r=25:d=4", "-f", "lavfi", "-i", "color=c=blue:s=320x180:r=25:d=4",
            "-f", "lavfi", "-i", "color=c=green:s=320x180:r=25:d=4", "-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono",
            "-filter_complex", "[0][1][2]concat=n=3:v=1:a=0[v]", "-map", "[v]", "-map", "3:a", "-t", "12", "-pix_fmt", "yuv420p", path])
    if srt:
        Path(path).with_suffix(".srt").write_text(
            "1\n00:00:01,000 --> 00:00:03,000\nThe knight swears to protect the village.\n\n"
            "2\n00:00:05,000 --> 00:00:07,000\nA storm approaches the castle gates tonight.\n\n"
            "3\n00:00:09,000 --> 00:00:11,000\nThe village celebrates the harvest together.\n")


def cfg_ctx(tmp_path, **kw):
    d = tmp_path / "work"
    d.mkdir(exist_ok=True)
    return {"work_dir": str(d), "language": "en", "transcription": {"engine": "auto"}, **kw}


# ---- 1. discovery / supported inputs ---------------------------------------------------------------------------------------
def test_folder_expands_in_natural_page_order_and_explicit_order_is_kept(tmp_path):
    d = tmp_path / "ch"
    d.mkdir()
    for n in ("page_10.png", "page_2.png", "page_1.png", "notes.txt", "skip.exe"):
        (d / n).write_bytes(b"x")
    assert [p.name for p in expand_sources([d])] == ["notes.txt", "page_1.png", "page_2.png", "page_10.png"]
    a, b = tmp_path / "b.txt", tmp_path / "a.txt"
    a.write_text("x")
    b.write_text("y")
    assert [p.name for p in expand_sources([a, b, a])] == ["b.txt", "a.txt"]           # order kept, duplicates dropped


@pytest.mark.parametrize("name,ctype", [("a.txt", "text"), ("a.md", "text"), ("a.srt", "subtitle"), ("a.vtt", "subtitle"), ("a.pdf", "pdf"),
                                        ("a.docx", "docx"), ("a.pptx", "pptx"), ("a.png", "image"), ("a.JPG", "image"), ("a.webp", "image"),
                                        ("a.mp4", "video"), ("a.mkv", "video"), ("a.webm", "video"), ("a.mov", "video")])
def test_supported_types_detected(tmp_path, name, ctype):
    p = tmp_path / name
    p.write_bytes(b"x")
    assert detect_type(p) == ctype


def test_unsupported_empty_missing_and_empty_folder_give_clear_errors(tmp_path):
    (tmp_path / "a.xyz").write_bytes(b"x")
    (tmp_path / "e.pdf").write_bytes(b"")
    (tmp_path / "empty").mkdir()
    with pytest.raises(SourceError, match=r"unsupported file type '.xyz'.*supported: "):
        expand_sources([tmp_path / "a.xyz"])
    with pytest.raises(SourceError, match="empty"):
        expand_sources([tmp_path / "e.pdf"])
    with pytest.raises(SourceError, match="not found"):
        expand_sources([tmp_path / "nope.txt"])
    with pytest.raises(SourceError, match="no supported files"):
        expand_sources([tmp_path / "empty"])


def test_text_markdown_and_subtitle_extraction(tmp_path):
    t = tmp_path / "a.txt"
    t.write_text(PARA1 + "\n\n" + PARA2)
    r = extractors.extract_text(t, cfg_ctx(tmp_path))
    assert [u["text"] for u in r["units"]] == [PARA1, PARA2] and r["units"][0]["ref"] == {"para": 1}
    s = tmp_path / "a.srt"
    s.write_text("1\n00:00:01,000 --> 00:00:03,000\nHello there friend.\n\n2\n00:00:04,000 --> 00:00:06,000\nSecond line here.\n")
    r = extractors.extract_subtitle(s, cfg_ctx(tmp_path))
    assert r["units"][0]["kind"] == "transcript" and "Hello there friend." in r["units"][0]["text"] and r["units"][0]["ref"]["start"] == 1.0
    v = tmp_path / "a.vtt"
    v.write_text("WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nVtt caption text.\n")
    assert "Vtt caption text." in extractors.extract_subtitle(v, cfg_ctx(tmp_path))["units"][0]["text"]


def test_docx_and_pptx_extraction_preserve_order(tmp_path):
    d = tmp_path / "a.docx"
    make_docx(d, ["First paragraph about cues.", "Second paragraph about rewards."])
    texts = [u["text"] for u in extractors.extract_docx(d, cfg_ctx(tmp_path))["units"]]
    assert " ".join(texts) == "First paragraph about cues. Second paragraph about rewards."
    p = tmp_path / "a.pptx"
    make_pptx(p, ["Slide one title", "Slide two body", "Slide three end"])
    sl = extractors.extract_pptx(p, cfg_ctx(tmp_path))["units"]
    assert [(u["ref"]["slide"], u["text"]) for u in sl] == [(1, "Slide one title"), (2, "Slide two body"), (3, "Slide three end")]


@needs_pdf
def test_pdf_text_extraction_per_page(tmp_path):
    p = tmp_path / "a.pdf"
    make_pdf(p, ["First page has plenty of readable text.", "Second page also has plenty of readable text."])
    u = extractors.extract_pdf(p, cfg_ctx(tmp_path))["units"]
    assert [(x["ref"]["page"], x["kind"]) for x in u] == [(1, "text"), (2, "text")] and "First page" in u[0]["text"]


@needs_pdf
@needs_ocr
def test_scanned_pdf_page_is_ocred(tmp_path):
    if not shutil.which("pdftoppm"):
        pytest.skip("pdftoppm not installed")
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new("RGB", (1200, 700), "white")
    ImageDraw.Draw(im).text((60, 300), "Scanned page about dragons", fill="black", font=ImageFont.load_default(60))
    p = tmp_path / "scan.pdf"
    im.save(p, "PDF")
    u = extractors.extract_pdf(p, cfg_ctx(tmp_path))["units"]
    assert u[0]["kind"] == "ocr" and "dragons" in u[0]["text"].lower() and u[0]["image"]


@needs_ocr
def test_image_ocr_page_order_and_confidence(tmp_path):
    make_page(tmp_path / "p1.png", "The hero draws the sword")
    r = extractors.extract_image(tmp_path / "p1.png", cfg_ctx(tmp_path))
    u = r["units"][0]
    assert "sword" in u["text"].lower() and u["confidence"] in ("ok", "low") and u["image"].endswith("p1.png")


def test_blank_image_and_missing_ocr_are_flagged_unreadable_not_invented(tmp_path, monkeypatch):
    from PIL import Image
    Image.new("RGB", (200, 200), "white").save(tmp_path / "blank.png")
    monkeypatch.setattr(extractors, "ocr_available", lambda: False)
    u = extractors.extract_image(tmp_path / "blank.png", cfg_ctx(tmp_path))["units"][0]
    assert u["text"] == "" and u["confidence"] == "unreadable" and "no_ocr_engine" in u["flags"]
    if HAS_OCR:
        monkeypatch.setattr(extractors, "ocr_available", lambda: True)
        u = extractors.extract_image(tmp_path / "blank.png", cfg_ctx(tmp_path))["units"][0]
        assert u["text"] == "" and "no_text_detected" in u["flags"]


def test_video_scenes_frames_and_dialogue_from_sidecar_subtitles(tmp_path):
    v = tmp_path / "ep.mp4"
    make_video(v)
    r = extractors.extract_video(v, cfg_ctx(tmp_path))
    us = r["units"]
    assert len(us) >= 3 and all(Path(u["frame"]).is_file() for u in us)
    assert all(a["ref"]["end"] <= b["ref"]["start"] + 0.01 for a, b in zip(us, us[1:]))        # chronological, no overlap
    joined = " ".join(u["text"] for u in us)
    assert "knight swears" in joined and "storm approaches" in joined and "celebrates the harvest" in joined
    assert any("dialogue from: imported" in w for w in r["warnings"])


def test_video_without_transcript_gives_visual_only_units_and_ingest_refuses(env, tmp_path, monkeypatch):
    from providers.transcription import EngineUnavailable
    import providers.transcription as pt
    v = tmp_path / "ep.mp4"
    make_video(v, srt=False)
    monkeypatch.setattr("providers.transcription.choose_engine", lambda *a, **k: (_ for _ in ()).throw(EngineUnavailable("no engine")))
    r = extractors.extract_video(v, cfg_ctx(tmp_path))
    assert r["units"] and all(not u["text"] and "no_dialogue" in u["flags"] for u in r["units"])
    _, s, _, jm = env
    j = jm.create_job("topic_to_video", "t", "en")
    with pytest.raises(SourceError, match="no readable content"):
        ingest.ingest_sources(jm, j, [str(v)], s, "en")


# ---- 2. extraction failures ---------------------------------------------------------------------------------------------
@needs_pdf
def test_corrupt_and_fake_pdfs_fail_clearly(tmp_path):
    bad = tmp_path / "bad.pdf"
    bad.write_bytes(b"%PDF-1.4\n" + b"garbage\x00\x01" * 50)
    with pytest.raises(SourceError, match="corrupt or not a valid PDF"):
        extractors.extract_pdf(bad, cfg_ctx(tmp_path))
    fake = tmp_path / "fake.pdf"
    fake.write_bytes(b"this is not a pdf at all")
    with pytest.raises(SourceError, match="not a PDF"):
        extractors.extract_pdf(fake, cfg_ctx(tmp_path))


def test_corrupt_docx_pptx_png_text_and_video_fail_clearly(tmp_path):
    (tmp_path / "a.docx").write_bytes(b"not a zip")
    (tmp_path / "a.pptx").write_bytes(b"not a zip")
    (tmp_path / "a.png").write_bytes(b"\x89PNG garbage")
    (tmp_path / "a.txt").write_bytes(b"abc\x00def" * 10)
    (tmp_path / "a.mp4").write_bytes(b"not a video" * 100)
    for fn, name, msg in ((extractors.extract_docx, "a.docx", "corrupt"), (extractors.extract_pptx, "a.pptx", "corrupt"),
                          (extractors.extract_image, "a.png", "not a readable image"), (extractors.extract_text, "a.txt", "binary"),
                          (extractors.extract_video, "a.mp4", "cannot be read as video")):
        with pytest.raises(SourceError, match=msg):
            fn(tmp_path / name, cfg_ctx(tmp_path))


def test_unsafe_xml_in_docx_is_refused(tmp_path):
    with zipfile.ZipFile(tmp_path / "evil.docx", "w") as z:
        z.writestr("word/document.xml", '<?xml version="1.0"?><!DOCTYPE d [<!ENTITY x "boom">]><w:document xmlns:w="w"/>')
    with pytest.raises(SourceError, match="unsafe XML"):
        extractors.extract_docx(tmp_path / "evil.docx", cfg_ctx(tmp_path))


def test_ingest_reports_every_bad_source_by_name_and_creates_nothing(env, tmp_path):
    _, s, _, jm = env
    good = tmp_path / "good.txt"
    good.write_text(PARA1)
    (tmp_path / "bad.docx").write_bytes(b"nope")
    (tmp_path / "bad.png").write_bytes(b"nope")
    j = jm.create_job("topic_to_video", "t", "en")
    with pytest.raises(SourceError) as e:
        ingest.ingest_sources(jm, j, [str(good), str(tmp_path / "bad.docx"), str(tmp_path / "bad.png")], s, "en")
    assert "bad.docx" in str(e.value) and "bad.png" in str(e.value) and "good.txt" not in str(e.value)


# ---- 3. manifest, ordering, cache ------------------------------------------------------------------------------------------
def test_manifest_tracks_paths_order_units_and_facts(env, tmp_path):
    _, s, conn, jm = env
    a, b = tmp_path / "b_second.txt", tmp_path / "a_first.txt"
    a.write_text(PARA1)
    b.write_text(PARA2)
    j = jm.create_job("topic_to_video", "t", "en")
    r = ingest.ingest_sources(jm, j, [str(a), str(b)], s, "en")
    man = json.loads(Path(r["manifest"]).read_text())
    assert [m["name"] for m in man["sources"]] == ["b_second.txt", "a_first.txt"]                  # user order, not alphabetical
    assert all(Path(m["path"]).is_absolute() and m["rights"] == "unverified" and m["status"] == "ok" for m in man["sources"])
    assert "does not verify ownership" in man["rights_notice"]
    units = json.loads(Path(r["units"]).read_text())
    assert [u["id"] for u in units] == ["u0001", "u0002"] and units[0]["source"] == "src1" and units[0]["fact_id"]
    rows = conn.execute("SELECT title,url,license FROM research_sources WHERE job_id=? ORDER BY id", (j,)).fetchall()
    assert [r_[0] for r_ in rows] == ["b_second.txt", "a_first.txt"] and rows[0][1] == "file://b_second.txt" and rows[0][2] == "unknown"
    assert conn.execute("SELECT COUNT(*) FROM research_facts WHERE job_id=?", (j,)).fetchone()[0] == 2


@needs_ocr
def test_image_pages_are_numbered_in_source_order(env, tmp_path):
    _, s, _, jm = env
    d = tmp_path / "chapter"
    d.mkdir()
    for n in (10, 2, 1):
        make_page(d / f"page_{n}.png", f"Page number {n} text here")
    j = jm.create_job("topic_to_video", "t", "en")
    r = ingest.ingest_sources(jm, j, [str(d)], s, "en")                                           # a folder = one chapter
    pages = [(u["ref"]["page"], Path(u["image"]).name) for u in json.loads(Path(r["units"]).read_text())]
    assert pages == [(1, "page_1.png"), (2, "page_2.png"), (3, "page_10.png")]


def test_extraction_is_cached_across_jobs_and_damaged_cache_is_redone(env, tmp_path, monkeypatch):
    _, s, _, jm = env
    f = tmp_path / "a.txt"
    f.write_text(PARA1)
    calls = []
    real = extractors.EXTRACTORS["text"]
    monkeypatch.setitem(extractors.EXTRACTORS, "text", lambda p, c: calls.append(1) or real(p, c))
    j1, j2, j3 = (jm.create_job("topic_to_video", "t", "en") for _ in range(3))
    r1 = ingest.ingest_sources(jm, j1, [str(f)], s, "en")
    r2 = ingest.ingest_sources(jm, j2, [str(f)], s, "en")
    assert len(calls) == 1 and json.loads(Path(r1["manifest"]).read_text())["sources"][0]["cached"] is False
    assert json.loads(Path(r2["manifest"]).read_text())["sources"][0]["cached"] is True
    for rj in (Path(s["_root"]) / "projects" / "cache" / "sources").glob("*/result.json"):
        rj.write_text("{ damaged")
    ingest.ingest_sources(jm, j3, [str(f)], s, "en")
    assert len(calls) == 2
    f.write_text(PARA1 + " Changed content now differs.")                                          # changed source -> new cache key
    ingest.ingest_sources(jm, jm.create_job("topic_to_video", "t", "en"), [str(f)], s, "en")
    assert len(calls) == 3


def test_sources_are_never_modified(env, tmp_path):
    _, s, _, jm = env
    f = tmp_path / "a.txt"
    f.write_text(PARA1)
    before = (f.read_bytes(), f.stat().st_mtime_ns)
    ingest.ingest_sources(jm, jm.create_job("topic_to_video", "t", "en"), [str(f)], s, "en")
    assert (f.read_bytes(), f.stat().st_mtime_ns) == before and sorted(p.name for p in tmp_path.glob("*.txt")) == ["a.txt", "notes.txt"]


# ---- 4. script grounding ---------------------------------------------------------------------------------------------------
def U(i, text, stype="video", kind="scene", ref=None, conf="ok", label="supported", flags=None, **kw):
    return {"id": f"u{i:04d}", "text": text, "source_type": stype, "kind": kind, "ref": ref or {"start": i * 10.0, "end": i * 10.0 + 8},
            "confidence": conf, "confidence_label": label, "flags": flags or [], "fact_id": i if text else None, "source": "src1", **kw}


DIALOGUE = ["The knight swears to protect the village from the dragon.", "A storm approaches the castle gates tonight and nobody is ready.",
            "The village celebrates the harvest together under the lanterns.", "The dragon returns and the knight keeps the promise."]
UNITS = [U(i + 1, t) for i, t in enumerate(DIALOGUE)]
WPM = {"en": 150}


class FakeLLM:
    def __init__(self, *outs):
        self.outs, self.prompts = list(outs), []

    def complete(self, prompt, max_tokens=0):
        self.prompts.append(prompt)
        out = self.outs.pop(0) if len(self.outs) > 1 else self.outs[0]
        if isinstance(out, Exception):
            raise out
        return out


def test_template_script_is_grounded_quotes_are_short_and_dialogue_is_not_read_out():
    sc = cs.generate_commentary_script("The Knight", UNITS, "recap", "en", 90, WPM)
    fact_ids = {u["fact_id"] for u in UNITS}
    claims = [x for sec in sc["sections"] for x in sec["sentences"] if x["kind"] == "claim"]
    assert claims and all(x["fact_ids"] and set(x["fact_ids"]) <= fact_ids for x in claims)
    src = " ".join(DIALOGUE).lower()
    for x in claims:
        if x["text"].startswith("One line reads"):
            q = x["text"].split('"')[1]
            assert len(q.split()) <= 10 and q.lower() in src                                      # short, verbatim, capped
        else:
            terms = x["text"].rsplit("mentions ", 1)[1].rstrip(".").replace(" and ", ", ").split(", ")
            assert all(t in src for t in terms)                                                     # key terms come from the source
    assert sc["commentary"]["verbatim_ratio"] < 0.6 and sc["method"] == "source_template"
    assert any("no LLM was used" in w for w in sc["warnings"])


def test_script_passes_existing_validation_with_matching_facts():
    sc = cs.generate_commentary_script("The Knight", UNITS, "explanation", "en", 90, WPM)
    facts = [{"id": u["fact_id"], "confidence": "supported"} for u in UNITS]
    checks = script_generator.validate_script(sc, facts, "en")
    assert all(c["ok"] for c in checks if c["level"] == "fail"), checks
    kinds = [s["kind"] for s in sc["sections"]]
    assert kinds[0] == "hook" and kinds[1] == "intro" and kinds[-1] == "conclusion"
    assert [s["id"] for s in sc["sections"]] == [f"s{i}" for i in range(len(kinds))]


def test_order_preserved_and_quote_words_zero_removes_quotes():
    sc = cs.generate_commentary_script("The Knight", UNITS, "recap", "en", 90, WPM, quote_words=0)
    order = [u for sec in sc["sections"] for u in sec.get("unit_ids", []) if sec["kind"] == "body"]
    assert order == [u["id"] for u in UNITS]
    assert not any("One line reads" in x["text"] for sec in sc["sections"] for x in sec["sentences"])


def test_modes_differ_and_review_theory_require_an_llm():
    hooks = {m: cs.generate_commentary_script("T", UNITS, m, "en", 90, WPM)["sections"][0]["sentences"][0]["text"]
             for m in ("recap", "explanation", "lesson", "summary")}
    assert len(set(hooks.values())) == 4
    for m in ("review", "theory"):
        with pytest.raises(cs.CommentaryError, match="needs an LLM"):
            cs.generate_commentary_script("T", UNITS, m, "en", 90, WPM)
    with pytest.raises(cs.CommentaryError, match="unknown content mode"):
        cs.generate_commentary_script("T", UNITS, "parody", "en", 90, WPM)
    with pytest.raises(cs.CommentaryError, match="templates exist for"):
        cs.generate_commentary_script("T", UNITS, "recap", "kn", 90, {"kn": 120})


def test_unreadable_and_low_confidence_parts_are_flagged_not_described():
    units = [UNITS[0], U(9, "", stype="image", kind="ocr", ref={"page": 2}, conf="unreadable", flags=["no_text_detected"]),
             U(10, "blurry text mentions a lantern festival", stype="image", kind="ocr", ref={"page": 3}, conf="low", label="uncertain"),
             UNITS[1]]
    sc = cs.generate_commentary_script("T", units, "recap", "en", 120, WPM)
    text = " ".join(x["text"] for sec in sc["sections"] for x in sec["sentences"])
    assert "page 2" not in text.lower() and "hard to read" in text
    assert any("could not be read" in w for w in sc["warnings"]) and sc["commentary"]["unreadable_units"] == ["u0009"]
    low = [x for sec in sc["sections"] for x in sec["sentences"] if "hard to read" in x["text"]][0]
    assert low["hedged"] is True and low["fact_ids"] == [10]


def test_long_source_is_condensed_evenly_with_a_warning_and_short_source_is_not_padded():
    many = [U(i + 1, f"Scene {i} the knight faces trial number {i} in the castle") for i in range(40)]
    sc = cs.generate_commentary_script("T", many, "recap", "en", 60, WPM)
    used = [u for sec in sc["sections"] for u in sec.get("unit_ids", []) if sec["kind"] == "body"]
    assert 3 <= len(used) < 40 and used == sorted(used) and any("condensed" in w for w in sc["warnings"])
    short = cs.generate_commentary_script("T", UNITS[:2], "recap", "en", 600, WPM)
    assert any("less material" in w for w in short["warnings"])


def test_llm_commentary_accepted_only_when_grounded():
    good = "The knight vows to defend the village. A storm is coming toward the castle."
    llm = FakeLLM(good)
    sc = cs.generate_commentary_script("The Knight", UNITS, "recap", "en", 90, WPM, llm)
    assert sc["method"].startswith("source_llm_validated") and "storm is coming" in " ".join(x["text"] for sec in sc["sections"] for x in sec["sentences"])
    body = [s for s in sc["sections"] if s["kind"] == "body"][0]
    assert all(set(x["fact_ids"]) == {u["fact_id"] for u in UNITS[:3]} for x in body["sentences"] if x["kind"] == "claim")
    for bad in ("The knight defeated 300 soldiers at the castle.",                              # new number
                "Sir Lancelot defeated the dragon with a sword.",                               # new proper name
                "Pirates plunder merchant ships across distant oceans.",                        # unrelated to the source section
                "A storm approaches the castle gates tonight and nobody is ready at all."):     # copied run of source words
        sc = cs.generate_commentary_script("The Knight", UNITS[:3], "recap", "en", 90, WPM, FakeLLM(bad))
        text = " ".join(x["text"] for sec in sc["sections"] for x in sec["sentences"])
        assert bad not in text and "mentions" in text                                           # fell back to the grounded template


def test_theory_must_be_hedged_and_review_with_unusable_llm_output_fails():
    ok = cs.generate_commentary_script("The Knight", UNITS, "theory", "en", 90, WPM,
                                       FakeLLM("The promise might hint that the knight fears the dragon."))
    assert ok["sections"][2]["sentences"][0]["text"].startswith("The promise might")
    with pytest.raises(cs.CommentaryError, match="rejected for every section"):
        cs.generate_commentary_script("The Knight", UNITS, "theory", "en", 90, WPM, FakeLLM("The knight fears the dragon deeply."))
    with pytest.raises(cs.CommentaryError, match="rejected for every section"):
        cs.generate_commentary_script("The Knight", UNITS, "review", "en", 90, WPM, FakeLLM(LLMUnavailable("offline")))


def test_ngram_overlap_measures_copying():
    assert cs.ngram_overlap("one two three four five six seven", "x one two three four five six seven y") == 1.0
    assert cs.ngram_overlap("completely different words here today friend ok", "one two three four five six seven") == 0.0


# ---- 5. review / edit ---------------------------------------------------------------------------------------------------------
def test_edit_keeps_grounding_for_unchanged_text_and_marks_user_sentences():
    sc = cs.generate_commentary_script("The Knight", UNITS, "recap", "en", 90, WPM)
    md = cs.script_markdown(sc)
    edited = md.replace("Here is a recap of The Knight.", "Here is my own opening line.", 1)
    body_sentence = [x["text"] for x in sc["sections"][2]["sentences"] if x["kind"] == "claim"][0]
    edited = edited.replace(body_sentence, body_sentence + " I added this sentence myself.", 1)
    out, stats = cs.apply_edit(json.loads(json.dumps(sc)), edited)
    assert stats["changed"] == 2 and stats["kept"] >= 1
    kinds = [x["kind"] for sec in out["sections"] for x in sec["sentences"]]
    assert kinds.count("user_edit") == 2 and out["edited_by_user"] and any("edited or added by the user" in w for w in out["warnings"])
    kept = [x for x in out["sections"][2]["sentences"] if x["text"] == body_sentence][0]
    assert kept["fact_ids"] and kept["kind"] == "claim"
    with pytest.raises(cs.CommentaryError, match="sections"):
        cs.apply_edit(json.loads(json.dumps(sc)), "## Only one\nsection")


# ---- 6. workflow integration -----------------------------------------------------------------------------------------------
@pytest.fixture()
def src_env(env, tmp_path):
    tmp, s, conn, jm = env
    s["encoding"] = {**s["encoding"], "preset": "ultrafast", "crf": 32}
    d = tmp_path / "src"
    d.mkdir()
    (d / "notes.txt").write_text(PARA1 + "\n\n" + PARA2)
    make_video(d / "ep.mp4")
    return s, jm, d, TopicWorkflow(jm, s, {}, tts=tone_tts())


def test_source_job_pauses_for_review_then_renders_after_approval(src_env):
    s, jm, d, wf = src_env
    j = wf.create("Habits and the knight", "en", duration_s=40, sources=[str(d / "notes.txt"), str(d / "ep.mp4")], content_mode="recap")
    with pytest.raises(StageFailed) as e:
        wf.run(j)
    assert e.value.status == "review_required" and "video approve-script" in str(e.value)
    jd = Path(s["paths"]["outputs"]) / j
    assert jm.get_job(j)["status"] == "review_required"
    assert not any((jd / "narration").iterdir()) and not any((jd / "final_video").iterdir())       # nothing narrated before approval
    assert "## Hook" in wf.script_text(j) and (jd / "sources" / "manifest.json").is_file()
    with pytest.raises(StageFailed):
        wf.run(j)                                                                                 # still blocked without approval
    md = wf.script_text(j).replace("Here is a recap of Habits and the knight.", "Here is my recap of habits and the knight.")
    stats = wf.edit_script(j, md)
    assert stats["changed"] == 1
    with pytest.raises(StageFailed):
        wf.run(j)                                                                                 # editing resets approval
    wf.approve_script(j)
    out = wf.run(j)
    assert "my recap" in (jd / "scripts" / "script.md").read_text()
    assert jm.get_job(j)["status"] in ("completed", "qa_failed") and (jd / "final_video" / "video.mp4").is_file()
    with pytest.raises(StageFailed, match="narration already exists"):
        wf.edit_script(j, md)
    # manifest + report
    sc = out["source_commentary"]
    assert [x["type"] for x in sc["sources"]] == ["text", "video"] and all(Path(x["path"]).is_absolute() for x in sc["sources"])
    assert "does not verify ownership" in sc["rights_notice"] and sc["content_mode"] == "recap"
    qa = {c["check"]: c for c in jm.latest_qa(j, "video")["checks"]}
    assert not qa["source_rights_not_verified"]["ok"] and qa["source_rights_not_verified"]["level"] == "warn"
    assert qa["source_manifest_recorded"]["ok"] and "src2=ep.mp4" in qa["source_manifest_recorded"]["detail"]
    assert not qa["commentary_is_written_analysis"]["ok"]
    # visuals come from the source frames, flagged as unverified rights
    assets = json.loads((jd / "assets" / "assets.json").read_text())
    src_assets = [a for a in assets if a.get("source_unit")]
    assert src_assets and all(a["license_status"] == "unknown" and "rights" in a["warnings"][0] for a in src_assets)
    meta = json.loads((jd / "metadata" / "metadata.json").read_text())
    assert "notes.txt" in meta["description"] and "ep.mp4" in meta["description"] and "responsible for having the rights" in meta["description"]
    # original files untouched
    assert (d / "notes.txt").read_text().startswith("Habits form")


def test_auto_approve_script_skips_the_pause(src_env):
    s, jm, d, wf = src_env
    j = wf.create("Habits", "en", duration_s=30, sources=[str(d / "notes.txt")], content_mode="summary", auto_approve_script=True)
    wf.run(j)
    assert jm.get_job(j)["status"] in ("completed", "qa_failed")


def test_unreadable_source_stops_job_with_clear_message(src_env):
    s, jm, d, wf = src_env
    (d / "broken.docx").write_bytes(b"not really a docx")
    j = wf.create("Habits", "en", duration_s=30, sources=[str(d / "notes.txt"), str(d / "broken.docx")])
    with pytest.raises(StageFailed, match=r"source problem: broken.docx: .*corrupt"):
        wf.run(j)
    assert jm.get_job(j)["status"] == "failed"


def test_review_mode_without_llm_stops_with_explanation(src_env):
    s, jm, d, wf = src_env
    j = wf.create("Habits", "en", duration_s=30, sources=[str(d / "notes.txt")], content_mode="review", auto_approve_script=True)
    with pytest.raises(StageFailed, match="needs an LLM"):
        wf.run(j)


def test_create_validation(src_env):
    s, jm, d, wf = src_env
    with pytest.raises(SourceError, match="not found"):
        wf.create("t", "en", sources=[str(d / "missing.pdf")])
    with pytest.raises(ValueError, match="unknown content mode"):
        wf.create("t", "en", sources=[str(d / "notes.txt")], content_mode="parody")
    with pytest.raises(ValueError, match="needs at least one --source"):
        wf.create("t", "en", content_mode="recap")
    sf = d / "s.txt"
    sf.write_text("x")
    with pytest.raises(ValueError, match="cannot be combined"):
        wf.create("t", "en", sources=[str(d / "notes.txt")], script_file=str(sf))


# ---- 7. V3 backward compatibility -------------------------------------------------------------------------------------------
def test_topic_workflow_without_sources_is_unchanged(env):
    tmp, s, conn, jm = env
    s["encoding"] = {**s["encoding"], "preset": "ultrafast", "crf": 32}
    wf = TopicWorkflow(jm, s, {}, tts=tone_tts())
    j = wf.create("How habits form", "en", duration_s=30)
    assert "sources" not in jm.params(j) and "content_mode" not in jm.params(j)
    out = wf.run(j)                                                          # no review pause, no ingest stage
    stages = {r[0] for r in conn.execute("SELECT name FROM stages WHERE job_id=?", (j,))}
    assert "research" in stages and "ingest" not in stages and "review" not in stages
    assert "source_commentary" not in out and jm.get_job(j)["status"] in ("completed", "qa_failed")
    jd = Path(s["paths"]["outputs"]) / j
    assert not (jd / "sources" / "manifest.json").exists()
    names = {c["check"] for c in jm.latest_qa(j, "video")["checks"]}
    assert not any(n.startswith("source") for n in names)


def test_release_metadata_cli_and_docs_identify_v3_1():
    from core.version import RELEASE, VERSION
    assert RELEASE == "YAA V3.1" and VERSION.startswith("3.1")
    cp = subprocess.run([sys.executable, str(ROOT / "agent.py"), "--version"], capture_output=True, text=True)
    assert cp.returncode == 0 and "YAA V3.1" in cp.stdout
    helptext = subprocess.run([sys.executable, str(ROOT / "agent.py"), "video", "--help"], capture_output=True, text=True).stdout
    for flag in ("--source", "--content-mode", "--quote-words", "--auto-approve-script", "edit-script", "approve-script", "--local-footage", "--editing"):
        assert flag in helptext
    assert "V3.1" in (ROOT / "README.md").read_text() and "Source-to-Commentary" in (ROOT / "README.md").read_text()


def test_cli_reports_bad_source_without_traceback(tmp_path):
    cp = subprocess.run([sys.executable, str(ROOT / "agent.py"), "--root", str(tmp_path), "video", "create", "t", "--source", str(tmp_path / "nope.pdf")],
                        capture_output=True, text=True)
    assert cp.returncode != 0 and "Traceback" not in cp.stderr
