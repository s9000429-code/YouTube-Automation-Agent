"""YAA V3.1 image-only PDF (manga/comic) vision recap: detection, page ranges, bounded batches, provider safety, consent,
local-only, provenance, uncertainty, resume, approval gate, V3.1 compatibility. The vision model is a fake: these tests prove the
plumbing and the safety rules, NOT the quality of any real model's page understanding."""
import json
import os
import shutil
import socket
import sys
import zlib
from pathlib import Path

import pytest

import providers.vision as pv
from core.job_manager import StageFailed
from modules.source_commentary import extractors, ingest, manga
from modules.source_commentary.sources import SourceError
from providers.vision import VisionFatal, VisionTransient, VisionProvider, get_vision
from scripts import commentary_script as cs
from tests.fixtures import tone_tts
from tests.test_source_commentary import make_pdf
from workflows.topic_to_video import TopicWorkflow

needs_poppler = pytest.mark.skipif(not (shutil.which("pdftoppm") and shutil.which("pdftotext")), reason="poppler not installed")
SECRET = "sk-test-SECRET-VALUE-123456"


def make_image_pdf(path, n_pages, w=90, h=130):
    """Image-only PDF (no text layer): each page is one uncompressed-grey raster, built without any imaging library."""
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", None]
    kids, extra = [], []
    for i in range(n_pages):
        pn, cn, im = 3 + 3 * i, 4 + 3 * i, 5 + 3 * i
        kids.append(f"{pn} 0 R")
        data = zlib.compress(bytes((x * 3 + y + i * 20) % 256 for y in range(h) for x in range(w)))
        stream = f"q {w * 4} 0 0 {h * 4} 0 0 cm /Im0 Do Q"
        objs += [f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w * 4} {h * 4}] /Contents {cn} 0 R /Resources << /XObject << /Im0 {im} 0 R >> >> >>",
                 f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream", ("IMG", data, w, h)]
    objs[1] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {n_pages} >>"
    out, offs = b"%PDF-1.4\n", []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        if isinstance(o, tuple):
            _, data, ww, hh = o
            out += (f"{i} 0 obj\n<< /Type /XObject /Subtype /Image /Width {ww} /Height {hh} /ColorSpace /DeviceGray /BitsPerComponent 8 "
                    f"/Filter /FlateDecode /Length {len(data)} >>\nstream\n").encode() + data + b"\nendstream\nendobj\n"
        else:
            out += f"{i} 0 obj\n{o}\nendobj\n".encode()
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode() + b"".join(f"{o:010d} 00000 n \n".encode() for o in offs)
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    Path(path).write_bytes(out)


def reply(page, **kw):
    d = {"page_type": "story", "panels": [{"order": 1, "action": f"a swordsman walks a road on page {page}", "characters": "a tall man", "setting": "a road"}],
         "summary": f"A tall swordsman travels along a road and meets a stranger. The mood is tense.", "story_progress": "He is now headed to the town.",
         "uncertain": [], "confidence": "high"}
    d.update(kw)
    return json.dumps(d)


class Fake(VisionProvider):
    """Fake vision model. `script` maps page -> reply string or an exception to raise."""
    name = "fake"
    calls: list = []
    script: dict = {}
    seen_tmp: list = []

    def validate(self):
        if not self.model:
            raise VisionFatal("vision model not configured")

    def _call(self, b64, prompt, max_tokens, image_path):
        page = int(image_path.stem.split("_p")[-1])
        Fake.calls.append(page)
        Fake.seen_tmp.append(len(list(image_path.parent.glob("_tmp_*"))))
        r = Fake.script.get(page, reply(page))
        if isinstance(r, BaseException):
            raise r
        return r


@pytest.fixture(autouse=True)
def fake_registry(monkeypatch):
    monkeypatch.setitem(pv.REGISTRY, "fake", Fake)
    Fake.calls, Fake.script, Fake.seen_tmp = [], {}, []
    monkeypatch.setattr(Fake, "backoff", 0, raising=False)


LOCAL = {"provider": "fake", "model": "m-1", "base_url": "http://127.0.0.1:9", "retries": 0}
EXTERNAL = {"provider": "fake", "model": "m-1", "base_url": "https://vision.example.invalid/v1", "retries": 0}


def ctx(tmp, vision=LOCAL, consent=False, local_only=False, pages=None, mode="auto", batch=2):
    return {"work_dir": str(tmp / "work"), "language": "en", "pdf_mode": mode, "pdf_pages": pages,
            "vision_opts": {"vision": vision, "consent": consent, "local_only": local_only, "batch": batch, "cache_root": str(tmp / "vcache")}}


@pytest.fixture()
def pdf8(tmp_path):
    p = tmp_path / "book.pdf"
    make_image_pdf(p, 8)
    return p


# ---- detection / page ranges ------------------------------------------------------------------------------------------------
@needs_poppler
def test_image_only_pdf_is_detected_and_text_pdf_is_not(tmp_path, pdf8):
    texts, _ = extractors._pdf_pages(pdf8)
    assert len(texts) == 8 and manga.is_image_only(texts, list(range(1, 9)))
    tp = tmp_path / "t.pdf"
    make_pdf(tp, ["Habits form through repeated cues and rewards in daily life.", "Environment design changes behavior more than motivation."])
    t2, _ = extractors._pdf_pages(tp)
    assert not manga.is_image_only(t2, [1, 2])


def test_page_range_parsing_and_errors():
    assert manga.parse_pages("1-5", 238) == [1, 2, 3, 4, 5]
    assert manga.parse_pages("7, 1-2,2", 10) == [1, 2, 7]
    assert manga.parse_pages(None, 3) == [1, 2, 3]
    for bad, msg in (("0-3", "start at 1"), ("5-3", "upward"), ("1-9", "past the end"), ("a-b", "invalid page range"), ("1-", "invalid page range")):
        with pytest.raises(SourceError, match=msg):
            manga.parse_pages(bad, 8)
    with pytest.raises(SourceError, match="at most"):
        manga.parse_pages("1-500", 1000)


# ---- extraction: pages, batches, cleanup, provenance -----------------------------------------------------------------------------
@needs_poppler
def test_only_selected_pages_are_rendered_and_analysed_with_page_refs(tmp_path, pdf8):
    res = manga.extract_visual(pdf8, ctx(tmp_path, pages="2-4"), ["", ""] * 4, [2, 3, 4])
    assert Fake.calls == [2, 3, 4]
    assert [u["ref"]["page"] for u in res["units"]] == [2, 3, 4]
    assert all(u["kind"] == "visual" and u["text"] and "vision" in u["flags"] for u in res["units"])
    assert res["meta"]["analysed_pages"] == [2, 3, 4] and res["meta"]["failed_pages"] == []
    assert all(Path(u["image"]).is_file() and Path(u["image"]).stat().st_size < 600_000 for u in res["units"])


@needs_poppler
def test_batches_are_bounded_and_nothing_is_left_behind(tmp_path, pdf8):
    manga.extract_visual(pdf8, ctx(tmp_path, batch=3), [""] * 8, list(range(1, 9)))
    assert max(Fake.seen_tmp) <= 1                                   # never more than one temporary render alive at a time
    root = tmp_path / "vcache"
    assert not list(root.rglob("_tmp_*")) and not list(root.rglob("pg*")) and not list(root.rglob("yaa_pg_*"))
    assert len(list(root.rglob("p000*.json"))) == 8


@needs_poppler
def test_low_memory_reduces_batch_and_very_low_memory_stops(tmp_path, pdf8, monkeypatch):
    monkeypatch.setattr(manga, "mem_available_mb", lambda: 400)
    res = manga.extract_visual(pdf8, ctx(tmp_path, batch=8), [""] * 8, [1, 2])
    assert res["meta"]["vision"]["batch"] == 1 and res["meta"]["vision"]["max_side"] <= 1000
    monkeypatch.setattr(manga, "mem_available_mb", lambda: 50)
    with pytest.raises(SourceError, match="memory"):
        manga.extract_visual(pdf8, ctx(tmp_path / "b"), [""] * 8, [1])


@needs_poppler
def test_text_pdf_keeps_working_and_never_calls_the_vision_model(tmp_path):
    tp = tmp_path / "t.pdf"
    make_pdf(tp, ["Habits form through repeated cues and rewards in daily life.", "Environment design changes behavior more than motivation does."])
    res = extractors.extract_pdf(tp, ctx(tmp_path))
    assert Fake.calls == [] and [u["kind"] for u in res["units"]] == ["text", "text"] and res["meta"]["tool"] != "vision"
    res = extractors.extract_pdf(tp, ctx(tmp_path, pages="2"))             # page range also works for text PDFs
    assert [u["ref"]["page"] for u in res["units"]] == [2]


@needs_poppler
def test_image_only_without_vision_config_keeps_the_old_ocr_path(tmp_path, pdf8):
    res = extractors.extract_pdf(pdf8, ctx(tmp_path, vision={"provider": "none"}, pages="1-2"))
    assert Fake.calls == [] and all(u["kind"] != "visual" for u in res["units"])
    assert any("image-only" in w for w in res["warnings"])


@needs_poppler
def test_vision_mode_without_provider_is_a_clear_error(tmp_path, pdf8):
    with pytest.raises(SourceError, match="no vision provider"):
        extractors.extract_pdf(pdf8, ctx(tmp_path, vision={"provider": "none"}, mode="vision"))


# ---- provider validation / consent / local-only ---------------------------------------------------------------------------------
def test_provider_validation_messages(monkeypatch):
    with pytest.raises(VisionFatal, match="model not configured"):
        get_vision({"provider": "ollama"})
    with pytest.raises(VisionFatal, match="unknown vision provider"):
        get_vision({"provider": "nope", "model": "x"})
    with pytest.raises(VisionFatal, match="base_url"):
        get_vision({"provider": "openai_compatible", "model": "m-1"})
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(VisionFatal, match="ANTHROPIC_API_KEY"):
        get_vision({"provider": "anthropic", "model": "m-1"}, consent_external=True)
    with pytest.raises(VisionFatal, match="command"):
        get_vision({"provider": "command", "model": "m"})
    assert get_vision({"provider": "none"}) is None and get_vision(None) is None


@needs_poppler
def test_external_provider_needs_consent_and_nothing_is_rendered_or_sent_without_it(tmp_path, pdf8, monkeypatch):
    monkeypatch.setattr(manga, "render_page", lambda *a, **k: pytest.fail("a page was rendered before consent"))
    with pytest.raises(SourceError, match="UPLOAD page images.*--allow-external-vision"):
        manga.extract_visual(pdf8, ctx(tmp_path, vision=EXTERNAL), [""] * 8, [1, 2])
    assert Fake.calls == []
    with pytest.raises(SourceError, match="local-only"):
        manga.extract_visual(pdf8, ctx(tmp_path, vision=EXTERNAL, consent=True, local_only=True), [""] * 8, [1])
    assert Fake.calls == []


@needs_poppler
def test_consent_allows_external_provider(tmp_path, pdf8):
    res = manga.extract_visual(pdf8, ctx(tmp_path, vision=EXTERNAL, consent=True), [""] * 8, [1])
    assert Fake.calls == [1] and res["meta"]["vision"]["external"] is True


def test_loopback_detection_decides_what_counts_as_local():
    assert not pv.OllamaVision({"model": "m-1"}).external
    assert pv.OpenAICompatibleVision({"model": "m-1", "base_url": "http://localhost:8080/v1"}).external is False
    assert pv.OpenAICompatibleVision({"model": "m-1", "base_url": "http://192.168.1.5/v1"}).external is True
    assert pv.AnthropicVision({"model": "m-1"}).external is True
    assert pv.CommandVision({"model": "m", "command": ["x"]}).external is False


@needs_poppler
def test_local_only_mode_makes_no_network_calls_with_a_local_command(tmp_path, pdf8, monkeypatch):
    prog = tmp_path / "fake_vision.py"
    prog.write_text("import sys,json\nsys.stdin.read()\nprint(json.dumps({'page_type':'story','summary':'A swordsman walks along a road at dusk.',"
                    "'panels':[],'uncertain':[],'confidence':'high'}))\n")
    cfg = {"provider": "command", "model": "local-test", "command": [sys.executable, str(prog), "{image}"]}

    def no_net(*a, **k):
        raise AssertionError("network access attempted in local-only mode")
    monkeypatch.setattr(socket.socket, "connect", no_net)
    monkeypatch.setattr(socket, "create_connection", no_net)
    res = manga.extract_visual(pdf8, ctx(tmp_path, vision=cfg, local_only=True), [""] * 8, [1, 2])
    assert [u["ref"]["page"] for u in res["units"]] == [1, 2] and res["meta"]["vision"]["external"] is False


def test_http_adapters_parse_replies_and_never_leak_keys(tmp_path, monkeypatch):
    import http.server, threading
    seen = {}

    class H(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            seen[self.path] = (dict(self.headers), body)
            if self.path.endswith("chat/completions") and body["model"] == "bad-model":
                self.send_response(400); self.end_headers(); self.wfile.write(b'{"error":"model does not support image input"}'); return
            if self.path.endswith("/api/chat"):
                out = {"message": {"content": reply(1)}}
            elif self.path.endswith("/v1/messages"):
                out = {"content": [{"type": "text", "text": reply(1)}]}
            else:
                out = {"choices": [{"message": {"content": reply(1)}}]}
            self.send_response(200); self.end_headers(); self.wfile.write(json.dumps(out).encode())

        def log_message(self, *a):
            pass
    srv = http.server.HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_port}"
    img = tmp_path / "p.jpg"
    img.write_bytes(b"\xff\xd8\xff\xe0fakejpeg")
    monkeypatch.setenv("MY_KEY", SECRET)
    try:
        for p in (pv.OpenAICompatibleVision({"model": "m-1", "base_url": base + "/v1", "api_key_env": "MY_KEY"}),
                  pv.OllamaVision({"model": "m-1", "base_url": base}), pv.AnthropicVision({"model": "m-1", "base_url": base, "api_key_env": "MY_KEY"})):
            p.validate()
            assert manga.parse_reply(p.describe(img, "prompt"))["summary"].startswith("A tall swordsman")
        assert "Bearer " + SECRET == seen["/v1/chat/completions"][0]["Authorization"]
        bad = pv.OpenAICompatibleVision({"model": "bad-model", "base_url": base + "/v1", "api_key_env": "MY_KEY"})
        with pytest.raises(VisionFatal, match="does not support images") as ei:
            bad.describe(img, "p")
        assert SECRET not in str(ei.value)
    finally:
        srv.shutdown()


def test_unreachable_server_is_a_clean_transient_error_without_the_key(tmp_path, monkeypatch):
    monkeypatch.setenv("MY_KEY", SECRET)
    p = pv.OpenAICompatibleVision({"model": "m-1", "base_url": "http://127.0.0.1:9/v1", "api_key_env": "MY_KEY", "timeout_s": 2, "retries": 0})
    img = tmp_path / "p.jpg"
    img.write_bytes(b"\xff\xd8\xff\xe0x")
    with pytest.raises(VisionTransient) as e:
        p.describe(img, "p")
    assert SECRET not in str(e.value) and "cannot reach" in str(e.value)


# ---- uncertainty, failures, resume -------------------------------------------------------------------------------------------------
def test_reply_parsing_removes_copied_dialogue_and_defaults_to_low_confidence():
    an = manga.parse_reply('noise ' + reply(1, summary='He says "I will never forgive you for this" and leaves. He walks away.', confidence="certain"))
    assert '"' not in an["summary"] and "dialogue_removed" in an["flags"] and an["confidence"] == "low"
    for bad in ("no json here", "{}", '{"summary": ""}', "[1,2]"):
        with pytest.raises((ValueError, KeyError)):
            manga.parse_reply(bad)


@needs_poppler
def test_uncertain_failed_and_blank_pages_are_reported_not_invented(tmp_path, pdf8):
    Fake.script = {2: reply(2, confidence="low", uncertain=["who the stranger is"]), 3: VisionTransient("timeout after 120s"),
                   4: "this is not json", 5: reply(5, page_type="blank", summary="")}
    res = manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, [1, 2, 3, 4, 5])
    byp = {u["ref"]["page"]: u for u in res["units"]}
    assert byp[2]["confidence"] == "low" and "uncertain_details" in byp[2]["flags"]
    assert byp[3]["confidence"] == "unreadable" and byp[3]["text"] == "" and byp[4]["confidence"] == "unreadable"
    assert byp[5]["text"] == "" and byp[5]["confidence"] == "ok" and any(f.startswith("no_story_content") for f in byp[5]["flags"])
    assert [f["page"] for f in res["meta"]["failed_pages"]] == [3, 4] and any("could not be analysed" in w for w in res["warnings"])


@needs_poppler
def test_first_pages_all_failing_stops_early_with_a_clear_message(tmp_path, pdf8):
    Fake.script = {n: VisionTransient("rate limited") for n in range(1, 9)}
    with pytest.raises(SourceError, match="first 3 pages all failed"):
        manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, list(range(1, 9)))
    assert Fake.calls == [1, 2, 3]


@needs_poppler
def test_fatal_provider_error_stops_without_leaking_the_key(tmp_path, pdf8, monkeypatch):
    monkeypatch.setenv("MY_KEY", SECRET)
    Fake.script = {2: VisionFatal("credentials rejected by fake (HTTP 401); check the key in $MY_KEY")}
    with pytest.raises(SourceError, match="credentials rejected") as e:
        manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, [1, 2, 3])
    assert SECRET not in str(e.value) and Fake.calls == [1, 2]
    for f in (tmp_path).rglob("*"):
        if f.is_file() and f.suffix in (".json", ".md", ".txt", ".log"):
            assert SECRET not in f.read_text(errors="replace")


@needs_poppler
def test_interrupted_run_resumes_without_repeating_finished_pages(tmp_path, pdf8):
    Fake.script = {3: KeyboardInterrupt()}
    with pytest.raises(KeyboardInterrupt):
        manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, [1, 2, 3, 4])
    assert not list((tmp_path / "vcache").rglob("_tmp_*"))
    Fake.calls, Fake.script = [], {}
    res = manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, [1, 2, 3, 4])
    assert Fake.calls == [3, 4] and len(res["units"]) == 4
    Fake.calls = []
    manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, [1, 2, 3, 4, 5])
    assert Fake.calls == [5]                                         # extending the range only analyses the new page


@needs_poppler
def test_corrupt_page_is_reported_and_the_rest_continue(tmp_path, pdf8, monkeypatch):
    real = manga.render_page

    def flaky(pdf, n, dest, *a, **k):
        if n == 2:
            raise RuntimeError("page 2 could not be rendered (corrupt page?)")
        return real(pdf, n, dest, *a, **k)
    monkeypatch.setattr(manga, "render_page", flaky)
    res = manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, [1, 2, 3])
    assert [f["page"] for f in res["meta"]["failed_pages"]] == [2] and Fake.calls == [1, 3]


@needs_poppler
def test_missing_pdftoppm_is_a_clear_error(tmp_path, pdf8, monkeypatch):
    monkeypatch.setattr(manga.shutil, "which", lambda n: None)
    with pytest.raises(SourceError, match="pdftoppm is missing"):
        manga.extract_visual(pdf8, ctx(tmp_path), [""] * 8, [1])


# ---- script generation ---------------------------------------------------------------------------------------------------------------
def _units(pages, per=None):
    per = per or {}
    out = []
    for i, n in enumerate(pages, 1):
        an = manga.parse_reply(per.get(n) or reply(n))
        u = manga.analysis_to_unit(n, an, None)
        u.update(id=f"u{i:04d}", order=i, fact_id=i, source="src1", source_type="pdf",
                 confidence_label="uncertain" if u["confidence"] == "low" or "uncertain_details" in u["flags"] else "supported")
        out.append(u)
    return out


def test_script_sections_carry_page_numbers_and_never_quote(tmp_path):
    units = _units([1, 2, 3, 4, 5], {3: reply(3, confidence="low")})
    units[3]["flags"].append("uncertain_details")
    sc = cs.generate_commentary_script("Berserk recap", units, "recap", "en", 120, {"en": 150}, quote_words=0)
    body = [s for s in sc["sections"] if s["kind"] == "body"]
    assert body and all("Page" in s["title"] for s in body)
    claims = [x for s in body for x in s["sentences"] if x["kind"] == "claim"]
    assert all(x["unit"] and x["fact_ids"] for x in claims)
    text = " ".join(x["text"] for x in claims)
    assert '"' not in text and "One line reads" not in text
    assert "On page 1" in text and "appears that" in text and "unclear" in text
    assert sc["commentary"]["quote_words"] == 0
    sc2 = cs.generate_commentary_script("Berserk recap", units, "recap", "en", 120, {"en": 150}, quote_words=12)
    assert "One line reads" not in " ".join(x["text"] for s in sc2["sections"] for x in s["sentences"])      # visual text is never quoted


def test_failed_pages_are_not_narrated_but_are_reported(tmp_path):
    units = _units([1, 2])
    units.append({**manga.analysis_to_unit(3, {"page_type": "story", "summary": "", "panels": [], "uncertain": [], "confidence": "low", "flags": []}, None),
                  "kind": "visual", "text": "", "confidence": "unreadable", "id": "u0003", "order": 3, "source": "src1", "source_type": "pdf"})
    sc = cs.generate_commentary_script("Berserk recap", units, "recap", "en", 120, {"en": 150})
    assert "u0003" in sc["commentary"]["unreadable_units"] and any("could not be read" in w for w in sc["warnings"])


# ---- workflow: review gate, approval invalidation, V3.1 compatibility ----------------------------------------------------------------
@pytest.fixture()
def wf_env(env, tmp_path, pdf8=None):
    tmp, s, conn, jm = env
    s["encoding"] = {**s["encoding"], "preset": "ultrafast", "crf": 32}
    d = tmp_path / "src"
    d.mkdir()
    make_image_pdf(d / "book.pdf", 8)
    wf = TopicWorkflow(jm, s, {"vision": LOCAL}, tts=tone_tts())
    return s, jm, d, wf


@needs_poppler
def test_vision_job_pauses_for_review_and_edits_invalidate_approval(wf_env):
    s, jm, d, wf = wf_env
    j = wf.create("Volume one recap", "en", duration_s=60, sources=[str(d / "book.pdf")], pdf_pages="1-5", pdf_mode="vision", vision_batch=2)
    with pytest.raises(StageFailed) as e:
        wf.run(j)
    assert e.value.status == "review_required" and "visual_summaries.md" in str(e.value)
    assert Fake.calls == [1, 2, 3, 4, 5]
    jd = Path(s["paths"]["outputs"]) / j
    vs = json.loads((jd / "sources" / "visual_summaries.json").read_text())
    assert [p["page"] for p in vs["pages"]] == [1, 2, 3, 4, 5] and vs["vision"]["model"] == "m-1"
    md = (jd / "sources" / "visual_summaries.md").read_text()
    assert "page 5" in md and "Page numbers are PDF page numbers" in md
    assert not any((jd / "narration").iterdir()) and not any((jd / "final_video").iterdir())          # nothing narrated before approval
    script = wf.script_text(j)
    assert "Page" in script
    wf.approve_script(j)
    assert jm.params(j)["script_approved"] is True
    wf.edit_script(j, script.replace("A tall swordsman", "A tired swordsman", 1))
    assert jm.params(j)["script_approved"] is False                                                   # an edit invalidates approval
    with pytest.raises(StageFailed) as e2:
        wf.run(j)
    assert e2.value.status == "review_required"
    Fake.calls = []
    wf.approve_script(j)
    wf.jm.update_params(j, script_approved=False)
    with pytest.raises(StageFailed):
        wf.run(j, force=False)
    assert Fake.calls == []                                                                           # nothing re-analysed (resumed from the job stages)


@needs_poppler
def test_create_fails_fast_on_bad_range_missing_consent_or_missing_provider(wf_env):
    s, jm, d, wf = wf_env
    src = [str(d / "book.pdf")]
    with pytest.raises(ValueError, match="invalid page range"):
        wf.create("t", "en", sources=src, pdf_pages="5-1")
    with pytest.raises(ValueError, match="need at least one --source"):
        wf.create("t", "en", pdf_pages="1-5")
    wf2 = TopicWorkflow(jm, s, {}, tts=tone_tts())
    with pytest.raises(ValueError, match="UPLOAD"):
        wf2.create("t", "en", sources=src, pdf_mode="vision", vision_provider="fake", vision_model="m-1")
    with pytest.raises(ValueError, match="needs a vision provider"):
        wf2.create("t", "en", sources=src, pdf_mode="vision")
    wf.pcfg = {"vision": EXTERNAL}
    with pytest.raises(ValueError, match="UPLOAD"):
        wf.create("t", "en", sources=src, pdf_mode="vision")
    wf.create("t", "en", sources=src, pdf_mode="vision", allow_external_vision=True)
    with pytest.raises(ValueError, match="local-only"):
        wf.create("t", "en", sources=src, pdf_mode="vision", allow_external_vision=True, vision_local_only=True)
    assert Fake.calls == []


@needs_poppler
def test_source_job_without_vision_options_is_unchanged_for_text_pdfs(wf_env):
    s, jm, d, wf = wf_env
    make_pdf(d / "t.pdf", ["Habits form through repeated cues and rewards in daily life.", "Environment design changes behavior more than motivation does."])
    j = wf.create("Habits", "en", duration_s=40, sources=[str(d / "t.pdf")])
    with pytest.raises(StageFailed) as e:
        wf.run(j)
    assert e.value.status == "review_required" and Fake.calls == []
    assert not (Path(s["paths"]["outputs"]) / j / "sources" / "visual_summaries.md").exists()


@needs_poppler
def test_vision_job_renders_after_approval(wf_env):
    pytest.importorskip("PIL")
    s, jm, d, wf = wf_env
    j = wf.create("Volume one recap", "en", duration_s=40, sources=[str(d / "book.pdf")], pdf_pages="1-3", pdf_mode="vision", quote_words=0)
    with pytest.raises(StageFailed):
        wf.run(j)
    wf.approve_script(j)
    out = wf.run(j)
    assert jm.get_job(j)["status"] in ("completed", "qa_failed") and "source_commentary" in out
    assert Fake.calls == [1, 2, 3]                                                                    # the render did not call the model again


def test_cli_exposes_the_new_flags_and_old_ones_remain():
    import subprocess
    root = Path(__file__).resolve().parent.parent
    h = subprocess.run([sys.executable, str(root / "agent.py"), "video", "--help"], capture_output=True, text=True).stdout
    for flag in ("--pdf-mode", "--pdf-pages", "--vision-provider", "--vision-model", "--allow-external-vision", "--vision-local-only",
                 "--vision-batch", "--quote-words", "--source", "--content-mode", "--editing", "--stock", "--local-footage"):
        assert flag in h
    cfg = json.loads((root / "config" / "providers.json").read_text())
    assert cfg["vision"] == {"provider": "none"} and cfg["llm"] == {"provider": "none"}
    assert json.loads((root / "config" / "providers.vision.example.json").read_text())
