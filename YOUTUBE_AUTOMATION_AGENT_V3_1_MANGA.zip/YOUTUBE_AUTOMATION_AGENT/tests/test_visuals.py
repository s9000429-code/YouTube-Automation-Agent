"""Scene visual hints, optional Pexels provider (mocked API; no network), licence/metadata handling, fallbacks, natural style."""
import json
from pathlib import Path

import pytest

from core.media import ffmpeg, make_silence, probe
from providers.stock_media import PexelsProvider, StockError, get_stock_provider
from scripts import asset_manager, render_video, visual_hints
from tests.fixtures import NOTES, tone_tts
from workflows.topic_to_video import TopicWorkflow

SECRET = "SECRET-KEY-VALUE-123"


def sec(kind, *texts, structure=False):
    return {"id": "x", "title": "t", "kind": kind, "sentences": [{"text": t, "kind": "structure" if structure else "claim"} for t in texts]}


# ---- 1. scene-specific hints ------------------------------------------------------------------------------------
def test_each_scene_gets_its_own_concrete_hint_not_the_topic():
    script = {"topic": "discipline", "sections": [
        sec("hook", "Discipline decides whether a student keeps studying late at night."),
        sec("body", "Phones pull your attention away every few minutes with notifications."),
        sec("body", "Those who start running each morning build momentum."),
        sec("body", "A simple checklist for the day removes guesswork."),
        sec("conclusion", "Thanks for watching.", structure=True)]}
    visual_hints.apply(script)
    hints = [s["visual_hint"] for s in script["sections"]]
    assert hints[:4] == ["student studying at desk at night", "phone distractions while working",
                         "morning running outdoors", "writing daily checklist in planner"]
    assert len(set(hints[:4])) == 4 and all(h != "discipline" for h in hints[:4])
    assert script["sections"][1]["visual_hint_source"] == "lexicon"
    assert hints[4] == "discipline" and script["sections"][4]["visual_hint_source"] == "topic"   # template-only outro talks about the topic


def test_topic_word_alone_does_not_trigger_a_visual():
    s = {"topic": "habits", "sections": [sec("body", "Habits are behaviours that become automatic over time.")]}
    visual_hints.apply(s)
    assert s["sections"][0]["visual_hint_source"] == "keywords" and "habits" not in s["sections"][0]["visual_hint"]


def test_keyword_fallback_uses_narration_words_only_and_no_abstract_filler():
    s = {"topic": "x", "sections": [sec("body", "Research shows that glaciers lose ice faster during warm summers.")]}
    visual_hints.apply(s)
    h = s["sections"][0]["visual_hint"]
    narration = "research shows that glaciers lose ice faster during warm summers"
    assert h and all(w in narration for w in h.split()) and "research" not in h.split() and s["sections"][0]["visual_hint_source"] in ("keywords", "lexicon")


def test_hints_for_non_latin_script_are_not_searchable():
    s = {"topic": "आदतें", "sections": [sec("body", "आदतें हमारे रोज़ के व्यवहार को बनाती हैं।")]}
    visual_hints.apply(s)
    h = s["sections"][0]["visual_hint"]
    assert not visual_hints.searchable(h)            # kept for card headings, never sent to a stock search


def test_llm_hint_accepted_only_when_related_to_narration():
    class LLM:
        def __init__(self, out):
            self.out = out

        def complete(self, prompt, max_tokens=0):
            return self.out

    base = {"topic": "x", "sections": [sec("body", "Bees visit flowers to collect nectar every day.")]}
    ok = json.loads(json.dumps(base))
    visual_hints.apply(ok, LLM("bee collecting nectar from flower"))
    assert ok["sections"][0]["visual_hint_source"] == "llm" and "bee" in ok["sections"][0]["visual_hint"]
    bad = json.loads(json.dumps(base))
    visual_hints.apply(bad, LLM("luxury sports car racing"))               # unrelated: rejected, deterministic rule used
    assert bad["sections"][0]["visual_hint_source"] != "llm" and "car" not in bad["sections"][0]["visual_hint"]


def test_generated_and_user_scripts_both_get_hints(env, tmp_path):
    _, s, _, jm = env
    wf = TopicWorkflow(jm, s, {})
    sf = tmp_path / "s.txt"
    sf.write_text("## Hook\nWhy is it hard to stay focused? Your phone buzzes constantly.\n\n## Body\nTry running every morning before work. "
                  "Then write a short checklist.\n\n## End\nThat is all. Thanks.")
    script = wf._script_from_file(str(sf), "focus", "en")
    hints = [x["visual_hint"] for x in script["sections"]]
    assert hints[0] != "focus" and hints[1] != "focus" and len(set(hints)) >= 2
    from scripts import script_generator
    from scripts.research_manager import ResearchManager
    j = jm.create_job("topic_to_video", "How habits form", "en")
    ResearchManager(jm, s).run(j, "How habits form")
    facts = ResearchManager(jm, s, []).load(j)["facts"]
    gen = script_generator.generate_script("How habits form", facts, "en", "educational", 60, s["topic_to_video"]["words_per_minute"])
    body = [x["visual_hint"] for x in gen["sections"] if x["kind"] == "body"]
    assert body and all(h and h != "How habits form" for h in body) and all("visual_hint_source" in x for x in gen["sections"])


# ---- 2. Pexels provider (mocked) ---------------------------------------------------------------------------------
def video_item(i, dur=8, files=None, who="Jane Doe"):
    return {"id": i, "url": f"https://www.pexels.com/video/clip-{i}/", "duration": dur, "user": {"name": who, "url": "https://www.pexels.com/@jane"},
            "video_files": files or [
                {"link": f"https://videos.pexels.com/{i}_sd.mp4", "file_type": "video/mp4", "width": 640, "height": 360},
                {"link": f"https://videos.pexels.com/{i}_hd.mp4", "file_type": "video/mp4", "width": 1920, "height": 1080},
                {"link": f"https://videos.pexels.com/{i}_uhd.mp4", "file_type": "video/mp4", "width": 3840, "height": 2160}]}


class FakePexels(PexelsProvider):
    def __init__(self, cfg=None, videos=None, photos=None, error=None):
        super().__init__(cfg or {})
        self.videos, self.photos, self.error = videos or [], photos or [], error
        self.calls, self.downloads = [], []

    def _get_json(self, path, params):
        self.calls.append((path, params))
        if self.error:
            raise StockError(self.error)
        return {"videos": self.videos} if "videos" in path else {"photos": self.photos}

    def _download(self, url, dest, max_bytes):
        self.downloads.append(url)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(b"stub")


@pytest.fixture()
def key(monkeypatch):
    monkeypatch.setenv("PEXELS_API_KEY", SECRET)


def test_video_preferred_with_orientation_metadata_and_licence(key, tmp_path):
    p = FakePexels(videos=[video_item(1)])
    a = p.fetch("student studying at desk", tmp_path, "shorts", min_duration=5)
    path, params = p.calls[0]
    assert path == "/v1/videos/search" and params["orientation"] == "portrait" and params["query"] == "student studying at desk"
    assert a["kind"] == "video" and a["path"].endswith("pexels_video_1.mp4") and p.downloads == ["https://videos.pexels.com/1_hd.mp4"]
    assert (a["provider"], a["license"], a["license_status"], a["query"]) == ("pexels", "Pexels License", "ok", "student studying at desk")
    assert a["source_url"] == "https://www.pexels.com/video/clip-1/" and a["creator"] == "Jane Doe"
    assert a["attribution"].startswith("Video by Jane Doe on Pexels") and a["license_url"] == "https://www.pexels.com/license/"
    assert "endorsement" in a["license_notes"] and "attribution not required" in a["license_notes"]   # restrictions stated, not "unrestricted"
    assert "unrestricted" not in json.dumps(a).lower()
    assert asset_manager.classify_license(a["license"]) == "ok"


@pytest.mark.parametrize("fmt,orient", [("landscape", "landscape"), ("shorts", "portrait"), ("square", "square")])
def test_orientation_follows_output_format(key, tmp_path, fmt, orient):
    p = FakePexels(videos=[video_item(2)])
    p.fetch("q", tmp_path, fmt)
    assert p.calls[0][1]["orientation"] == orient


def test_file_choice_is_sharp_enough_but_not_4k():
    v = video_item(3)
    assert PexelsProvider.pick_video_file(v, 1920, 1080)["width"] == 1920
    assert PexelsProvider.pick_video_file(video_item(4, files=[{"link": "u", "file_type": "video/mp4", "width": 640, "height": 360}]), 1920, 1080)["width"] == 640
    assert PexelsProvider.pick_video_file(video_item(5, files=[{"link": "u", "file_type": "video/webm", "width": 1920, "height": 1080}]), 1920, 1080) is None


def test_image_fallback_when_no_video_and_duplicate_ids_skipped(key, tmp_path):
    photos = [{"id": 7, "url": "https://www.pexels.com/photo/a-7/", "photographer": "Sam Roe", "photographer_url": "https://www.pexels.com/@sam",
               "width": 4000, "height": 3000, "src": {"large2x": "https://images.pexels.com/photos/7/large2x.jpg"}}]
    p = FakePexels(videos=[], photos=photos)
    a = p.fetch("morning running", tmp_path, "landscape")
    assert [c[0] for c in p.calls] == ["/v1/videos/search", "/v1/search"]
    assert a["kind"] == "image" and a["attribution"].startswith("Photo by Sam Roe on Pexels") and a["creator_url"].endswith("@sam")
    p2 = FakePexels(videos=[video_item(9)])
    assert p2.fetch("q", tmp_path, "landscape", exclude={9}) is None            # already used in another scene
    assert any("no Pexels match" in d for d in p2.diagnostics)


def test_no_api_key_is_diagnosed_and_makes_no_requests(monkeypatch, tmp_path):
    monkeypatch.delenv("PEXELS_API_KEY", raising=False)
    p = FakePexels(videos=[video_item(1)])
    assert p.fetch("q", tmp_path, "landscape") is None and p.calls == []
    assert any("PEXELS_API_KEY" in d for d in p.diagnostics)
    assert p.fetch("q2", tmp_path, "landscape") is None and p.calls == []


@pytest.mark.parametrize("err", ["Pexels rejected the API key (HTTP 401); check the key in the environment variable",
                                 "network unavailable for Pexels (timed out); continuing with local assets",
                                 "Pexels rate limit reached (HTTP 429); continuing with local assets"])
def test_fatal_errors_stop_further_requests(key, tmp_path, err):
    p = FakePexels(error=err)
    assert p.fetch("a", tmp_path, "landscape") is None
    assert p.fetch("b", tmp_path, "landscape") is None
    assert len(p.calls) == 1 and err in p.diagnostics                                   # one request, then straight to fallback


def test_secret_never_appears_in_diagnostics_or_metadata(key, tmp_path):
    p = FakePexels(videos=[video_item(1)])
    a = p.fetch("q", tmp_path, "landscape")
    q = FakePexels(error="Pexels rejected the API key (HTTP 401); check the key in the environment variable")
    q.fetch("q", tmp_path, "landscape")
    assert SECRET not in json.dumps(a) and SECRET not in json.dumps(p.diagnostics) and SECRET not in json.dumps(q.diagnostics)
    ok, why = PexelsProvider({}).available()
    assert ok and SECRET not in why


def test_real_http_errors_map_to_clear_messages(key, monkeypatch):
    import io
    import urllib.error
    import urllib.request

    def boom(code):
        def f(req, timeout=0):
            raise urllib.error.HTTPError(req.full_url, code, "x", {}, io.BytesIO(b""))
        return f

    for code, word in ((401, "rejected the API key"), (429, "rate limit")):
        monkeypatch.setattr(urllib.request, "urlopen", boom(code))
        with pytest.raises(StockError) as e:
            PexelsProvider({})._get_json("/v1/search", {"query": "q"})
        assert word in str(e.value) and SECRET not in str(e.value)

    def offline(req, timeout=0):
        raise urllib.error.URLError("Name or service not known")
    monkeypatch.setattr(urllib.request, "urlopen", offline)
    with pytest.raises(StockError) as e:
        PexelsProvider({})._get_json("/v1/search", {"query": "q"})
    assert "network unavailable" in str(e.value)


def test_downloads_only_from_pexels_https_hosts(tmp_path):
    for bad in ("https://evil.example.com/a.mp4", "http://videos.pexels.com/a.mp4", "https://pexels.com.evil.io/a.mp4"):
        with pytest.raises(StockError):
            PexelsProvider({})._download(bad, tmp_path / "a.mp4", 1000)
    assert not list(tmp_path.iterdir())


def test_request_budget_and_provider_registry(key, tmp_path):
    p = FakePexels({"max_requests": 1}, videos=[])
    p.fetch("a", tmp_path, "landscape")                    # uses the budget (video then image search counts as 2 requests)
    p.fetch("b", tmp_path, "landscape")
    assert any("budget" in d for d in p.diagnostics)
    assert get_stock_provider({"provider": "none"}) is None and get_stock_provider(None) is None
    assert isinstance(get_stock_provider({"provider": "pexels"}), PexelsProvider)
    with pytest.raises(KeyError):
        get_stock_provider({"provider": "getty"})


# ---- 3. asset assignment and fallbacks ------------------------------------------------------------------------------
def _script():
    return {"topic": "discipline", "sections": [
        {"id": "s0", "title": "Hook", "kind": "hook", "visual_hint": "student studying at desk", "sentences": [{"text": "studying hard"}]},
        {"id": "s1", "title": "Body", "kind": "body", "visual_hint": "morning running outdoors", "sentences": [{"text": "running daily"}]}]}


def test_stock_assets_used_with_metadata_and_cards_when_stock_fails(key, tmp_path):
    from providers.image_generation import get_image_provider
    p = FakePexels(videos=[video_item(1)])
    out = asset_manager.assign_assets(_script(), tmp_path / "lib", tmp_path / "o", get_image_provider(), 320, 180, "en",
                                      stock=p, fmt="landscape", durations={"s0": 5, "s1": 5})
    assert out[0]["provider"] == "pexels" and out[0]["license_status"] == "ok" and out[0]["query"] == "student studying at desk"
    assert out[0]["path"].startswith(str(tmp_path / "o" / "stock"))
    assert out[1]["source"].startswith("generated:") and "provider" not in out[1]       # id 1 already used: second scene falls back to a card


def test_offline_default_uses_cards_and_no_stock_object_needed(tmp_path):
    from providers.image_generation import get_image_provider
    out = asset_manager.assign_assets(_script(), tmp_path / "lib", tmp_path / "o", get_image_provider(), 320, 180, "en")
    assert all(a["source"] == "generated:local_cards" for a in out)


def test_local_library_wins_over_stock_and_non_english_hint_skips_search(key, tmp_path):
    from PIL import Image
    from providers.image_generation import get_image_provider
    lib = tmp_path / "lib"
    lib.mkdir()
    Image.new("RGB", (64, 64)).save(lib / "studying_desk.jpg")
    (lib / "studying_desk.jpg.license.json").write_text(json.dumps({"license": "CC0", "tags": ["studying"]}))
    sc = _script()
    sc["sections"][1]["visual_hint"] = "आदतें बनाना"
    p = FakePexels(videos=[video_item(1)])
    out = asset_manager.assign_assets(sc, lib, tmp_path / "o", get_image_provider(), 320, 180, "en", stock=p, fmt="landscape")
    assert out[0]["path"].endswith("studying_desk.jpg") and p.calls == []
    assert out[1]["source"].startswith("generated:") and any("no English visual phrase" in d for d in p.diagnostics)


# ---- 4. natural editing -----------------------------------------------------------------------------------------------
def test_shot_plan_is_synchronised_varied_and_sensible():
    assert render_video.shot_plan(6.0, "a") == [6.0]                       # short scenes stay one shot
    for dur in (11.0, 20.0, 47.3):
        shots = render_video.shot_plan(dur, "s2")
        assert abs(sum(shots) - dur) < 1e-9 and min(shots) >= render_video.NATURAL["shot_min"] and max(shots) <= 9.5
        assert shots == render_video.shot_plan(dur, "s2")                  # deterministic (resume-safe)
    assert len({round(x, 2) for x in render_video.shot_plan(40, "q")}) > 2   # lengths vary


def test_natural_vs_classic_arguments_passed_to_renderer(tmp_path, monkeypatch, env):
    _, settings, _, _ = env
    calls = []
    monkeypatch.setattr(render_video, "render_section", lambda *a, **k: (calls.append((a, k)), Path(a[2]).write_bytes(b"x")))
    monkeypatch.setattr(render_video, "ffmpeg", lambda *a, **k: None)
    monkeypatch.setattr(render_video, "require_free_space", lambda *a, **k: None)
    spans = [("s0", 0.0, 6.0), ("s1", 6.0, 26.0)]
    assets = {"s0": {"kind": "image", "path": "a.png"}, "s1": {"kind": "image", "path": "b.png"}}
    render_video.render_video(spans, assets, "n.wav", tmp_path / "c.mp4", tmp_path / "w1", settings)
    assert len(calls) == 2 and all(len(a) == 9 and not k for a, k in calls)                     # classic: untouched call shape
    calls.clear()
    render_video.render_video(spans, assets, "n.wav", tmp_path / "n.mp4", tmp_path / "w2", settings, editing="natural")
    assert len(calls) > 2
    durs = [a[1] for a, _ in calls]
    assert abs(sum(durs) - 26.0) < 1e-6                                                         # timing identical to narration spans
    assert calls[0][1]["fade_in"] > 0 and all(k["fade_in"] == 0 for _, k in calls[1:])          # open fade only on the first shot
    assert calls[-1][1]["fade_out"] > 0 and all(k["fade_out"] == 0 for _, k in calls[:-1])      # close fade only on the last shot
    assert len({k["variant"] % 3 for _, k in calls}) > 1                                        # framing varies between shots
    with pytest.raises(ValueError):
        render_video.render_video(spans, assets, "n.wav", tmp_path / "x.mp4", tmp_path / "w3", settings, editing="wild")


def test_natural_music_is_quiet_and_fades(tmp_path, monkeypatch, env):
    _, settings, _, _ = env
    seen = []
    monkeypatch.setattr(render_video, "render_section", lambda *a, **k: Path(a[2]).write_bytes(b"x"))
    monkeypatch.setattr(render_video, "ffmpeg", lambda args, **k: seen.append([str(x) for x in args]))
    monkeypatch.setattr(render_video, "require_free_space", lambda *a, **k: None)
    (tmp_path / "m.mp3").write_bytes(b"x")
    spans, assets = [("s0", 0.0, 8.0)], {"s0": {"kind": "image", "path": "a.png"}}
    render_video.render_video(spans, assets, "n.wav", tmp_path / "n.mp4", tmp_path / "w", settings, editing="natural",
                              music=str(tmp_path / "m.mp3"), music_volume=0.3)
    fc = next(a[a.index("-filter_complex") + 1] for a in seen if "-filter_complex" in a)
    assert "volume=0.08" in fc and "afade=t=in" in fc and "afade=t=out:st=5.50:d=2.5" in fc
    seen.clear()
    render_video.render_video(spans, assets, "n.wav", tmp_path / "c.mp4", tmp_path / "w4", settings, music=str(tmp_path / "m.mp3"), music_volume=0.3)
    fc = next(a[a.index("-filter_complex") + 1] for a in seen if "-filter_complex" in a)
    assert "volume=0.3" in fc and "afade=t=in" not in fc                                        # classic unchanged


def test_natural_real_render_with_image_and_video_assets(tmp_path, env):
    from PIL import Image
    _, settings, _, _ = env
    settings = {**settings, "encoding": {**settings["encoding"], "preset": "ultrafast", "crf": 32}}
    img = tmp_path / "a.png"
    Image.new("RGB", (800, 600), (30, 90, 160)).save(img)
    clip = tmp_path / "c.mp4"
    ffmpeg(["-f", "lavfi", "-i", "testsrc=size=640x360:rate=25:duration=3", "-pix_fmt", "yuv420p", clip])
    wav = make_silence(tmp_path / "n.wav", 13.0)
    spans = [("s0", 0.0, 4.0), ("s1", 4.0, 13.0)]
    assets = {"s0": {"kind": "image", "path": str(img)}, "s1": {"kind": "video", "path": str(clip)}}
    out = render_video.render_video(spans, assets, wav, tmp_path / "out.mp4", tmp_path / "w", settings, fmt="square",
                                    style="educational", editing="natural")
    info = probe(out)
    assert (info["width"], info["height"]) == (1080, 1080) and abs(info["duration"] - 13.0) < 0.6 and info["has_audio"]


# ---- 5. whole workflow ------------------------------------------------------------------------------------------------
@pytest.fixture(scope="module")
def stock_run(tmp_path_factory):
    import os
    from core.config import load_settings
    from core.database import open_database
    from core.job_manager import JobManager
    d = tmp_path_factory.mktemp("stock")
    (d / "notes.txt").write_text(NOTES)
    clip = d / "clip.mp4"
    ffmpeg(["-f", "lavfi", "-i", "testsrc=size=640x360:rate=25:duration=4", "-pix_fmt", "yuv420p", clip])
    s = load_settings(d, {"paths": {"outputs": str(d / "out"), "database": str(d / "a.db"), "assets": str(d / "assets"),
                                    "backups": str(d / "bk"), "logs": str(d / "l")},
                          "encoding": {"preset": "ultrafast", "crf": 32},
                          "topic_to_video": {"research": {"providers": ["manual"], "manual": {"paths": [str(d / "notes.txt")]}}}})
    jm = JobManager(open_database(d / "a.db", d / "bk"), s)
    os.environ["PEXELS_API_KEY"] = SECRET

    class Stub(FakePexels):
        def _get_json(self, path, params):
            self.calls.append((path, params))
            if "videos" in path:
                n = len(self.calls)
                return {"videos": [video_item(100 + n)]}
            return {"photos": []}

        def _download(self, url, dest, max_bytes):
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(clip.read_bytes())

    stock = Stub()
    wf = TopicWorkflow(jm, s, {}, tts=tone_tts(), stock=stock)
    j = wf.create("How habits form", "en", duration_s=30, editing="natural", stock="pexels")
    out = wf.run(j)
    os.environ.pop("PEXELS_API_KEY", None)
    return d, jm, wf, j, out, stock


def test_workflow_uses_stock_natural_style_and_records_credits(stock_run):
    d, jm, wf, j, out, stock = stock_run
    jd = d / "out" / j
    assets = json.loads((jd / "assets" / "assets.json").read_text())
    stock_assets = [a for a in assets if a.get("provider") == "pexels"]
    assert stock_assets and all(a["kind"] == "video" and a["license_status"] == "ok" and a["query"] for a in stock_assets)
    script = json.loads((jd / "scripts" / "script.json").read_text())
    assert len({s["visual_hint"] for s in script["sections"] if s["kind"] == "body"}) >= 2           # per-scene queries
    assert {c[1]["query"] for c in stock.calls if "videos" in c[0]} <= {s["visual_hint"] for s in script["sections"]}
    v = probe(jd / "final_video" / "video.mp4")
    assert abs(v["duration"] - json.loads((jd / "narration" / "timeline.json").read_text())["duration"]) < 1
    meta = json.loads((jd / "metadata" / "metadata.json").read_text())
    assert "Visual credits" in meta["description"] and "Jane Doe on Pexels" in meta["description"] and meta["visual_credits"]
    assert len(meta["description"]) <= 5000
    row = jm.conn.execute("SELECT meta_json, license FROM assets WHERE job_id=? AND meta_json LIKE '%pexels%' LIMIT 1", (j,)).fetchone()
    assert row and json.loads(row[0])["source_url"].startswith("https://www.pexels.com/video/") and row[1] == "Pexels License"
    rep = json.loads((jd / "assets" / "stock_report.json").read_text())
    assert rep["provider"] == "pexels" and rep["stock_assets"] == len(stock_assets)
    assert out["editing"] == "natural" and out["stock_media"]["provider"] == "pexels"
    assert SECRET not in json.dumps(out) and SECRET not in (jd / "assets" / "assets.json").read_text()


def test_workflow_without_key_falls_back_to_cards_with_diagnostics(env, monkeypatch):
    monkeypatch.delenv("PEXELS_API_KEY", raising=False)
    _, s, _, jm = env
    wf = TopicWorkflow(jm, s, {}, tts=tone_tts())
    j = wf.create("How habits form", "en", duration_s=30, stock="pexels")
    out = wf.run(j)
    jd = Path(s["paths"]["outputs"]) / j
    assets = json.loads((jd / "assets" / "assets.json").read_text())
    assert all(a["source"] == "generated:local_cards" for a in assets)
    rep = out["stock_media"]
    assert rep["stock_assets"] == 0 and any("PEXELS_API_KEY" in d for d in rep["diagnostics"]) and out["editing"] == "classic"
    assert jm.get_job(j)["status"] in ("completed", "qa_failed")


def test_unknown_editing_preset_rejected_at_create(env):
    _, s, _, jm = env
    with pytest.raises(ValueError):
        TopicWorkflow(jm, s, {}).create("How habits form", "en", editing="wild")
