"""Compose narration + per-section visuals (+ optional music, captions) into the final video."""
from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

from core.captions import stage_fonts
from core.media import concat_line, ffmpeg, probe, quality_args
from core.safe_io import require_free_space, reserved_output

FORMATS = {"landscape": (1920, 1080), "shorts": (1080, 1920), "square": (1080, 1080)}
STYLE = {  # zoom strength per second (Ken Burns), fade seconds
    "educational": (0.010, 0.35), "motivational": (0.020, 0.25), "documentary": (0.014, 0.45),
    "storytelling": (0.016, 0.40), "facts": (0.018, 0.25), "technology": (0.012, 0.30), "science": (0.012, 0.35),
    "news": (0.006, 0.20), "tutorial": (0.004, 0.20), "entertainment": (0.020, 0.25), "comedy": (0.022, 0.20),
    "podcast": (0.008, 0.30), "debate": (0.008, 0.25)}


# "natural" editing preset (opt-in; the STYLE table above is unchanged): restrained motion, mostly clean cuts, long scenes split
# into varied-length shots (same asset, different framing/offset) so pacing is not mechanical, subtle music with fades.
NATURAL = {"zoom": 0.0035, "cap": 1.06, "pan_zoom": 1.05, "shot_target": 5.5, "shot_min": 3.0, "shot_max": 8.0,
           "open_fade": 0.4, "close_fade": 0.6, "music_volume": 0.08, "music_fade_in": 1.0, "music_fade_out": 2.5}
EDITING = ("classic", "natural")


def shot_plan(dur: float, seed: str = "") -> list[float]:
    """Split a scene of `dur` seconds into shots of varied (deterministic) length, each >= shot_min; sums to dur exactly."""
    n = NATURAL
    if dur <= n["shot_max"] * 1.25:
        return [dur]
    k = max(2, round(dur / n["shot_target"]))
    while k > 1 and dur / k < n["shot_min"] * 1.1:
        k -= 1
    if k == 1:
        return [dur]
    w = [0.75 + 0.5 * (int(hashlib.sha256(f"{seed}:{i}".encode()).hexdigest()[:6], 16) / 0xFFFFFF) for i in range(k)]
    out = [dur * x / sum(w) for x in w]
    out[-1] = dur - sum(out[:-1])
    return out


def section_spans(timeline: list[dict], script: dict, total: float, lead: float = 0.0) -> list[tuple[str, float, float]]:
    """(section_id, start, end) covering [0,total] with no gaps (each section runs until the next begins)."""
    first = {}
    for it in timeline:
        first.setdefault(it["section"], it["start"])
    ids = [s["id"] for s in script["sections"] if s["id"] in first]
    spans = []
    for k, sid in enumerate(ids):
        a = 0.0 if k == 0 else first[sid]
        b = first[ids[k + 1]] if k + 1 < len(ids) else total
        spans.append((sid, a, b))
    return spans


def render_section(asset: dict, dur: float, out: Path, w: int, h: int, fps: int, style: str, settings: dict,
                   profile: str | None, editing: str = "classic", variant: int = 0, offset: float = 0.0,
                   fade_in: float | None = None, fade_out: float | None = None) -> None:
    zoom, fade = STYLE.get(style, STYLE["educational"])
    natural = editing == "natural"
    frames = max(1, int(round(dur * fps)))
    fd = min(fade, dur / 3)
    fi = fd if fade_in is None else min(fade_in, dur / 3)       # classic: fade at both ends (unchanged); natural: cuts
    fo = fd if fade_out is None else min(fade_out, dur / 3)
    fades = (f",fade=t=in:st=0:d={fi:.2f}" if fi > 0 else "") + (f",fade=t=out:st={max(0, dur - fo):.2f}:d={fo:.2f}" if fo > 0 else "")
    if asset["kind"] == "image":
        big_w, big_h = int(w * 1.5) // 2 * 2, int(h * 1.5) // 2 * 2    # 1.5x oversample: smooth enough, ~45% cheaper than 2x
        cx, cy = "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
        z = f"min(1+{zoom}*on/{fps},1.25)"
        if natural:
            n = NATURAL
            mode = variant % 3                                       # slow push-in / slow pull-out / gentle sideways drift
            z = [f"min(1+{n['zoom']}*on/{fps},{n['cap']})", f"max(1,{n['cap']}-{n['zoom']}*on/{fps})", f"{n['pan_zoom']}"][mode]
            if mode == 2:
                cx = f"(iw-iw/zoom)*on/{frames}"
        vf = (f"scale={big_w}:{big_h}:force_original_aspect_ratio=increase,crop={big_w}:{big_h},"
              f"zoompan=z='{z}':x='{cx}':y='{cy}':d={frames}:s={w}x{h}:fps={fps}{fades},format=yuv420p")
        ffmpeg(["-loop", "1", "-framerate", str(fps), "-i", asset["path"], "-vf", vf, "-t", f"{dur:.3f}", "-an",
                "-c:v", "libx264", "-preset", settings["encoding"]["preset"], "-crf", str(settings["encoding"]["crf"]),
                "-pix_fmt", "yuv420p", "-r", str(fps), out])
    else:
        vf = f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},fps={fps}{fades},format=yuv420p"
        ffmpeg(["-stream_loop", "-1"] + (["-ss", f"{offset:.3f}"] if offset > 0 else []) + ["-i", asset["path"], "-vf", vf, "-t", f"{dur:.3f}", "-an", "-c:v", "libx264",
                "-preset", settings["encoding"]["preset"], "-crf", str(settings["encoding"]["crf"]), "-pix_fmt", "yuv420p", out])


def render_video(spans, assets_by_section: dict, narration_wav: str | Path, out_path: str | Path, work_dir: str | Path,
                 settings: dict, fmt: str = "landscape", style: str = "educational", music: str | None = None,
                 music_volume: float = 0.12, ass_path: str | Path | None = None, profile: str | None = None,
                 progress=None, language: str = "en", editing: str = "classic") -> Path:
    if editing not in EDITING:
        raise ValueError(f"unknown editing preset {editing!r}; options {list(EDITING)}")
    natural = editing == "natural"
    w, h = FORMATS[fmt]
    fps = settings["fps"]
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    total = spans[-1][2]
    require_free_space(work, int(total * 2_000_000), reserve_bytes=128 * 1024 * 1024)
    segs = []
    plan = []                                   # (section_id, shot_duration, shot_index_in_section, offset_into_scene)
    for sid, a, b in spans:
        shots = shot_plan(b - a, sid) if natural else [b - a]
        plan += [(sid, d, i, sum(shots[:i])) for i, d in enumerate(shots)]
    clip_len: dict[str, float] = {}
    for n, (sid, d, i, off) in enumerate(plan):
        seg = work / f"seg_{n:03d}.mp4"
        asset = assets_by_section[sid]
        if not natural:
            render_section(asset, d, seg, w, h, fps, style, settings, profile)
        else:
            if asset["kind"] == "video" and off > 0:        # later shots of a scene start further into the same clip
                if asset["path"] not in clip_len:
                    try:
                        clip_len[asset["path"]] = probe(asset["path"])["duration"]
                    except Exception:
                        clip_len[asset["path"]] = 0.0
                L = clip_len[asset["path"]]
                off = off % max(L - 0.5, 1.0) if L > 1 else 0.0
            render_section(asset, d, seg, w, h, fps, style, settings, profile, "natural", variant=n, offset=off if asset["kind"] == "video" else 0.0,
                           fade_in=NATURAL["open_fade"] if n == 0 else 0.0,
                           fade_out=NATURAL["close_fade"] if n == len(plan) - 1 else 0.0)
        segs.append(seg)
        if progress:
            progress((n + 1) / (len(plan) + 1))
    lst = work / "segments.txt"
    lst.write_text("".join(concat_line(s) for s in segs), encoding="utf-8")
    joined = work / "visual.mp4"
    ffmpeg(["-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", joined])
    cmd: list = ["-i", joined, "-i", narration_wav]
    amap = "[1:a]aresample=48000,loudnorm=I=-16:TP=-1.5:LRA=11[a]"
    if music and Path(music).is_file():
        cmd += ["-stream_loop", "-1", "-i", music]
        mv, fin, fout = (min(music_volume, NATURAL["music_volume"]), NATURAL["music_fade_in"], NATURAL["music_fade_out"]) if natural \
            else (music_volume, 0.0, 1.5)
        fade_in = f"afade=t=in:st=0:d={fin}," if fin else ""
        amap = (f"[1:a]aresample=48000,loudnorm=I=-16:TP=-1.5:LRA=11[v];[2:a]aresample=48000,volume={mv},"
                f"atrim=0:{total:.3f},{fade_in}afade=t=out:st={max(0, total - fout):.2f}:d={fout}[m];"
                f"[v][m]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]")
    vmap, vfilter = "0:v", []
    cwd = None
    if ass_path:
        local = work / "_burn.ass"
        shutil.copyfile(ass_path, local)
        fontsdir = stage_fonts(language, work)
        vfilter = ["[0:v]ass=_burn.ass" + (f":fontsdir={fontsdir}" if fontsdir else "") + "[vb]"]
        vmap, cwd = "[vb]", work
    fc = ";".join(vfilter + [amap])
    with reserved_output(out_path) as target:
        ffmpeg(cmd + ["-filter_complex", fc, "-map", vmap, "-map", "[a]", "-t", f"{total:.3f}"] +
               (["-c:v", "libx264", "-preset", settings["encoding"]["preset"], "-crf", str(settings["encoding"]["crf"]),
                 "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", settings["encoding"]["audio_bitrate"], "-movflags", "+faststart"]
                if ass_path else ["-c:v", "copy", "-c:a", "aac", "-b:a", settings["encoding"]["audio_bitrate"], "-movflags", "+faststart"])
               + [target], cwd=cwd, duration=total, progress=progress and (lambda f: progress(0.9 + 0.1 * f)))
        final = target
    for s in segs:
        s.unlink(missing_ok=True)
    for p in (lst, joined, work / "_burn.ass"):
        p.unlink(missing_ok=True)
    shutil.rmtree(work / "_fonts", ignore_errors=True)
    return final
