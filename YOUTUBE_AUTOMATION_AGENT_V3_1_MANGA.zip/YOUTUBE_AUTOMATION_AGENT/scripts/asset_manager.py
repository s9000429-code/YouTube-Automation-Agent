"""Visual assets per section, with licence tracking.

Sources, in order: (1) the user's own library in assets/ (image/video files, optional `<file>.license.json`
sidecar: {"license": "...", "source": "...", "tags": [...], "attribution": "..."}), (2) original generated
cards (providers.image_generation). Files without a sidecar licence are 'unknown' and are NOT used unless
`allow_unknown_assets` is set; when allowed they are flagged, (2) OPTIONAL stock footage from an official API provider
(providers.stock_media; opt-in, key from an environment variable; metadata keeps source URL, creator, licence, query),
(3) original generated cards. Without a key / network / match the next source is used; nothing else is downloaded."""
from __future__ import annotations

import json
import re
from pathlib import Path

from providers.image_generation import ImageProvider
from scripts import visual_hints

IMG = {".jpg", ".jpeg", ".png", ".webp"}
VID = {".mp4", ".mov", ".mkv", ".webm"}
OPEN_LICENSES = ("cc0", "public domain", "cc by", "cc-by", "cc by-sa", "own", "original_generated", "licensed", "pexels", "pixabay", "unsplash")
RESTRICTED = ("all rights reserved", "no derivatives", "cc by-nd", "cc-nd", "non-commercial", "cc by-nc", "cc-nc", "editorial")


def classify_license(lic: str | None) -> str:
    l = (lic or "").strip().lower()
    if not l or l == "unknown":
        return "unknown"
    if any(r in l for r in RESTRICTED):
        return "restricted"
    if any(o in l for o in OPEN_LICENSES):
        return "ok"
    return "unknown"


def scan_library(lib_dir: str | Path) -> list[dict]:
    lib = Path(lib_dir)
    out = []
    if not lib.is_dir():
        return out
    for f in sorted(lib.rglob("*")):
        if f.suffix.lower() not in IMG | VID or not f.is_file():
            continue
        side = f.with_name(f.name + ".license.json")
        meta = json.loads(side.read_text(encoding="utf-8")) if side.exists() else {}
        out.append({"path": str(f), "kind": "video" if f.suffix.lower() in VID else "image",
                    "license": meta.get("license", "unknown"), "source": meta.get("source", ""),
                    "attribution": meta.get("attribution", ""),
                    "tags": [t.lower() for t in meta.get("tags", [])] + re.findall(r"[a-z]{4,}", f.stem.lower()),
                    "license_status": classify_license(meta.get("license"))})
    return out


def match(section_text: str, hint: str, lib: list[dict], used: set[str]) -> dict | None:
    words = set(re.findall(r"[a-z]{4,}", (section_text + " " + hint).lower()))
    best, score = None, 0
    for a in lib:
        s = len(words & set(a["tags"])) - (0.5 if a["path"] in used else 0)
        if s > score:
            best, score = a, s
    return best


def assign_assets(script: dict, lib_dir: str | Path, out_dir: str | Path, image_provider: ImageProvider, w: int, h: int,
                  language: str, allow_unknown: bool = False, stock=None, fmt: str = "landscape",
                  durations: dict | None = None, prefer: str = "video") -> list[dict]:
    lib = scan_library(lib_dir)
    used: set[str] = set()
    stock_ids: set = set()
    result = []
    for k, sec in enumerate(script["sections"]):
        text = " ".join(s["text"] for s in sec["sentences"])
        a = match(text, sec.get("visual_hint", ""), lib, used)
        warnings = []
        if a and a["license_status"] == "restricted":
            warnings.append(f"asset {Path(a['path']).name} has a restrictive licence ({a['license']}); not used")
            a = None
        elif a and a["license_status"] == "unknown":
            if allow_unknown:
                warnings.append(f"asset {Path(a['path']).name} has UNKNOWN usage rights; used only because allow_unknown_assets is on")
            else:
                warnings.append(f"asset {Path(a['path']).name} has no licence info; skipped")
                a = None
        if not a and stock is not None:
            hint = sec.get("visual_hint", "")
            if not visual_hints.searchable(hint):
                stock.note(f"scene {sec['id']}: no English visual phrase to search for; used a generated card")
            else:
                got = stock.fetch(hint, Path(out_dir) / "stock", fmt, (durations or {}).get(sec["id"], 0.0), stock_ids, prefer)
                if got:
                    stock_ids.add(got["stock_id"])
                    a = {**got, "warnings": list(warnings)}
        if a and a.get("provider"):
            result.append({"section": sec["id"], **a})
        elif a:
            used.add(a["path"])
            result.append({"section": sec["id"], **a, "warnings": warnings})
        else:
            card = Path(out_dir) / f"card_{k:02d}.png"
            heading = sec["title"] if sec["kind"] != "body" else (sec.get("visual_hint") or sec["title"]).title()
            body = "" if sec["kind"] in ("hook", "intro", "conclusion") else text[:140]
            image_provider.generate(heading if sec["kind"] != "hook" else script["topic"].title(), body, card, w, h,
                                    seed=sec["id"] + script["topic"], language=language)
            result.append({"section": sec["id"], "path": str(card), "kind": "image", "license": image_provider.license,
                           "source": f"generated:{image_provider.name}", "license_status": "ok", "attribution": "",
                           "tags": [], "warnings": warnings})
    return result


class NoEligibleFootage(RuntimeError):
    """Local-footage mode found no usable video clip (never silently replaced by generated cards)."""


def assign_local_sequential(script: dict, lib_dir: str | Path, allow_unknown: bool = False) -> list[dict]:
    """Test/offline mode: video clips from the assets/ directory, in filename order, cycled over the script sections.
    Same licence rules as normal matching: restricted clips are never used; unknown-licence clips only with allow_unknown."""
    lib = [a for a in scan_library(lib_dir) if a["kind"] == "video"]
    lib.sort(key=lambda a: (Path(a["path"]).name.lower(), Path(a["path"]).name, a["path"]))
    skipped, eligible = [], []
    for a in lib:
        st = a["license_status"]
        if st == "restricted":
            skipped.append(f"{Path(a['path']).name}: restrictive licence ({a['license']})")
        elif st == "unknown" and not allow_unknown:
            skipped.append(f"{Path(a['path']).name}: no licence info (use --allow-unknown-assets to permit)")
        else:
            eligible.append(a)
    if not eligible:
        found = f"{len(lib)} video file(s) found, none eligible: " + "; ".join(skipped) if lib else \
            "no video files (.mp4 .mov .mkv .webm) found"
        raise NoEligibleFootage(f"local footage mode: {found} in {lib_dir}")
    out = []
    for k, sec in enumerate(script["sections"]):
        a = eligible[k % len(eligible)]
        w = [f"clip {Path(a['path']).name} has UNKNOWN usage rights; used only because allow_unknown_assets is on"] \
            if a["license_status"] == "unknown" else []
        out.append({"section": sec["id"], **a, "warnings": w, "local_footage": "sequential",
                    "clip_index": k % len(eligible), "clip_cycle": k // len(eligible)})
    return out


SOURCE_LICENSE = "user_supplied_source (rights not verified)"


def compose_contain(src: str | Path, out: str | Path, w: int, h: int) -> Path:
    """Fit the whole page/frame inside w x h over a blurred, darkened copy of itself (nothing is cropped away; the original
    file is only read). Large images are downscaled first to keep memory low."""
    from PIL import Image, ImageEnhance, ImageFilter

    with Image.open(src) as im:
        im = im.convert("RGB")
        im.thumbnail((w * 2, h * 2))
        bg = im.copy()
        bg = ImageEnhance.Brightness(bg.resize((w, h)).filter(ImageFilter.GaussianBlur(24))).enhance(0.45)
        fg = im.copy()
        fg.thumbnail((w, h))
        bg.paste(fg, ((w - fg.width) // 2, (h - fg.height) // 2))
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    bg.save(out, quality=90)
    return out


def assign_source_visuals(script: dict, units_by_id: dict, out_dir: str | Path, image_provider: ImageProvider, w: int, h: int,
                          language: str) -> list[dict]:
    """One visual per section from the source material itself (video frame / page image), else a generated card.
    Source visuals are marked 'unknown' licence on purpose: this tool cannot know whether the creator may publish them."""
    result = []
    for k, sec in enumerate(script["sections"]):
        us = [units_by_id[i] for i in sec.get("unit_ids", []) if i in units_by_id]
        pics = [u for u in us if (u.get("frame") or u.get("image")) and Path(u.get("frame") or u["image"]).is_file()]
        pick = pics[len(pics) // 2] if pics else None
        if pick:
            src = pick.get("frame") or pick["image"]
            out = compose_contain(src, Path(out_dir) / f"src_{k:02d}.jpg", w, h)
            result.append({"section": sec["id"], "path": str(out), "kind": "image", "license": SOURCE_LICENSE, "license_status": "unknown",
                           "source": f"source:{pick['source']}:{json.dumps(pick['ref'], sort_keys=True)}", "attribution": "", "tags": [],
                           "source_unit": pick["id"], "source_file": src,
                           "warnings": ["visual comes from the supplied source material; its publication rights are not verified by this tool"]})
        else:
            card = Path(out_dir) / f"card_{k:02d}.png"
            heading = sec["title"] if sec["kind"] != "hook" else script["topic"].title()
            image_provider.generate(heading, "", card, w, h, seed=sec["id"] + script["topic"], language=language)
            result.append({"section": sec["id"], "path": str(card), "kind": "image", "license": image_provider.license,
                           "source": f"generated:{image_provider.name}", "license_status": "ok", "attribution": "", "tags": [],
                           "warnings": []})
    return result
