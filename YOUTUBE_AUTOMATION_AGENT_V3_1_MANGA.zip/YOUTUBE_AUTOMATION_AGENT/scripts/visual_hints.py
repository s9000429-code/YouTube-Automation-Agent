"""Scene-specific visual descriptions.

For every script section build a short, concrete search phrase (what a camera could film) from THAT section's own
narration, instead of reusing the overall topic. Order of preference:
  1. optional LLM phrase, accepted only if it shares a content word with the narration (nothing unrelated);
  2. a concrete phrase from a small lexicon, chosen only when the narration contains one of its trigger words;
  3. the section's most characteristic content words (English/Latin script);
  4. intro/outro sections whose narration is only template text: the topic itself (that IS what they talk about);
  5. non-Latin scripts (hi/kn/te): native keywords, used for card headings only (stock search needs ASCII).
`visual_hint_source` records which rule produced the phrase. Works for user-supplied scripts too."""
from __future__ import annotations

import re

# (trigger word prefixes, concrete visual phrase). A phrase is used only if the narration contains a trigger.
LEXICON: list[tuple[tuple[str, ...], str]] = [
    (("study", "studying", "student", "exam", "homework", "learn"), "student studying at desk at night"),
    (("phone", "smartphone", "scroll", "notification", "distract", "social media"), "phone distractions while working"),
    (("morning", "sunrise", "wake", "alarm"), "morning sunrise routine"),
    (("run", "running", "jog", "marathon", "sprint"), "morning running outdoors"),
    (("gym", "workout", "exercise", "fitness", "lift"), "workout in gym"),
    (("checklist", "to-do", "todo", "planner", "schedule", "calendar", "plan"), "writing daily checklist in planner"),
    (("sleep", "bedtime", "insomnia", "rest"), "person sleeping in bed"),
    (("money", "saving", "invest", "budget", "income", "salary", "wealth"), "counting money and budgeting"),
    (("meditat", "mindful", "calm", "breath"), "person meditating"),
    (("read", "book", "library"), "reading a book"),
    (("write", "writing", "journal", "notebook"), "writing in notebook"),
    (("team", "meeting", "colleague", "office", "workplace", "startup", "compan"), "team meeting in office"),
    (("computer", "laptop", "software", "code", "coding", "program"), "typing code on laptop"),
    (("robot", "artificial", "machine learning", "algorithm", "neural"), "robot arm technology"),
    (("brain", "neuron", "memory", "mind", "psycholog"), "brain scan neuroscience"),
    (("food", "diet", "nutrition", "eat", "meal", "cook"), "preparing healthy meal"),
    (("water", "ocean", "sea", "river"), "ocean waves"),
    (("forest", "tree", "nature", "plant"), "forest trees nature"),
    (("space", "planet", "galaxy", "star", "orbit"), "night sky stars galaxy"),
    (("city", "traffic", "urban", "street"), "city street traffic"),
    (("energy", "solar", "electric", "power", "wind turbine"), "solar panels and wind turbines"),
    (("history", "ancient", "ruin", "empire", "century", "museum"), "ancient ruins historic site"),
    (("climate", "weather", "storm", "temperature", "warming"), "storm clouds weather"),
    (("lab", "experiment", "scientist", "chemistry", "microscope"), "scientist in laboratory"),
    (("friend", "family", "together", "community", "social"), "friends talking together"),
    (("habit", "routine", "discipline", "consisten", "repeat"), "daily routine habit"),
    (("goal", "target", "success", "achiev", "win", "progress"), "climbing stairs toward goal"),
]

STOP = set("""about above after again against also another because been before being below between both could does doing down during
each even every from further have having here into itself just like many more most much must only other over really same shall should
since some such than that their them then there these they this those through under until very want were what when where which while
will with would your yours you the and for are was has had not but can may might its our out off how why who whom been said says
say according""".split())
ABSTRACT = set("""research study studies shows show shown found finds people person thing things percent percentage number numbers
result results according reportedly reported experts expert often usually likely typically actually simply important means mean
reason reasons lesson takeaway truth surprising time times year years today welcome thanks watching video channel next come back
make makes made lets let know learn use used using good better best more less first second third lot lots part parts way ways""".split())

_LATIN = re.compile(r"[a-z][a-z'-]{3,}")


def _text(sec: dict, everything: bool = False) -> str:
    """Narration that carries content. Template/structure sentences ("Let's explore X") say nothing about visuals,
    except in user-supplied scripts, where every sentence is the user's own content."""
    return " ".join(s["text"] for s in sec["sentences"] if everything or s.get("kind", "claim") != "structure")


def _word_hit(t: str, w: str) -> bool:
    return w == t or (len(t) >= 5 and w.startswith(t)) or w in (t + "s", t + "es", t + "ed", t + "ing", t + "er")


def _lexicon(text: str) -> list[str]:
    """Concrete phrases whose trigger words occur in the text, earliest occurrence first."""
    low = text.lower()
    words = re.findall(r"[a-z][a-z'-]*", low)
    hits = []
    for triggers, phrase in LEXICON:
        pos = [low.find(t) if " " in t else next((i for i, w in enumerate(words) if _word_hit(t, w)), -1) for t in triggers]
        pos = [p for p in pos if p >= 0]
        if pos:
            hits.append((min(pos), phrase))
    return [p for _, p in sorted(hits)]


def _keywords(text: str, avoid: set[str], n: int = 3) -> list[str]:
    toks = _LATIN.findall(text.lower())
    freq: dict[str, int] = {}
    first: dict[str, int] = {}
    for i, t in enumerate(toks):
        if t in STOP or t in ABSTRACT or t.endswith("ly"):
            continue
        freq[t] = freq.get(t, 0) + 1
        first.setdefault(t, i)
    pool = [t for t in freq if t not in avoid] or list(freq)
    top = sorted(pool, key=lambda t: (-freq[t], first[t]))[:n]
    return sorted(top, key=lambda t: first[t])


def _llm_hint(llm, text: str) -> str | None:
    try:
        out = llm.complete("Describe in 3 to 6 words one concrete thing a camera could film that illustrates this narration. "
                           f"Only visible objects, people or actions; no abstract words, no names.\nNARRATION: {text[:400]}\nSHOT:",
                           max_tokens=24).strip().split("\n")[0].strip(" .\"'")
    except Exception:
        return None
    words = re.findall(r"[a-z]+", out.lower())
    if not (2 <= len(words) <= 7) or not out.isascii():
        return None
    narr = {w[:5] for w in re.findall(r"[a-z]{4,}", text.lower())}
    return out.lower() if any(w[:5] in narr for w in words if len(w) >= 4) else None   # must relate to the narration


def scene_hint(sec: dict, topic: str, llm=None, used: set[str] | None = None, everything: bool = False) -> tuple[str, str]:
    topic_words = set(_LATIN.findall(topic.lower()))
    text = _text(sec, everything)
    if not text.strip():                                  # template-only section (intro/outro): it talks about the topic
        t = " ".join(_LATIN.findall(topic.lower())[:4])
        return (t, "topic") if t and sec.get("kind") in ("hook", "intro", "conclusion") else ("", "none")
    if llm is not None:
        h = _llm_hint(llm, text)
        if h:
            return h, "llm"
    used = used or set()
    cands = _lexicon(re.sub(r"\b(" + "|".join(map(re.escape, topic_words)) + r")\w*", " ", text, flags=re.I) if topic_words else text)
    h = next((c for c in cands if c not in used), None)      # a different concrete phrase per scene where possible
    if h:
        return h, "lexicon"
    kw = _keywords(text, topic_words)
    if kw:
        return " ".join(kw), "keywords"
    if sec.get("kind") in ("hook", "intro", "conclusion"):
        t = " ".join(_LATIN.findall(topic.lower())[:4])
        if t:
            return t, "topic"
    native = re.findall(r"[^\W\d_]{5,}", text)[:4]            # non-Latin scripts: card heading only, never searched
    return (" ".join(native), "native_keywords") if native else ("", "none")


def apply(script: dict, llm=None) -> dict:
    """Set visual_hint (+ visual_hint_source) on every section, from that section's own narration."""
    topic = script.get("topic", "")
    prev, used = "", set()
    for sec in script.get("sections", []):
        h, src = scene_hint(sec, topic, llm, used, script.get("method") == "user_supplied")
        if src == "lexicon":
            used.add(h)
        if h and h == prev and src == "topic":        # do not repeat the same generic topic phrase on consecutive scenes
            src = "topic_repeat"
        sec["visual_hint"], sec["visual_hint_source"] = h, src
        prev = h
    return script


def searchable(hint: str) -> bool:
    """Only ASCII phrases are sent to a stock-media search."""
    return bool(hint) and hint.isascii()
