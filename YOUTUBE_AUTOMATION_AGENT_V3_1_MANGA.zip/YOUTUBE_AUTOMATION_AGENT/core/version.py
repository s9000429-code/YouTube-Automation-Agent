"""Release metadata. V3.1 = V3 + Source-to-Commentary Video (backward compatible: all V3 workflows unchanged)."""
VERSION = "3.1.0"
RELEASE = "YAA V3.1"
