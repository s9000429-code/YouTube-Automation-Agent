"""Optional stock-media providers (official APIs only). Shipped: Pexels.

Opt-in (`topic_to_video.stock.provider = "pexels"` or `--stock pexels`). The API key is read from an environment variable
(default PEXELS_API_KEY) and is never stored, logged or printed. Only files returned by the provider's own API and served
from the provider's own hosts are downloaded; nothing is scraped. Any failure (no key, no network, rejected key, rate
limit, no match) is recorded in `diagnostics` and the caller falls back to local assets / generated cards.

Pexels terms checked against pexels.com/api/documentation, pexels.com/api and pexels.com/license (Oct-Nov 2026):
auth via `Authorization: <key>` header; default limits 200 requests/hour, 20,000/month (do not work around them);
API users are asked to credit the photographer/link to Pexels; the Pexels License allows free commercial use and editing
without attribution but forbids implying endorsement, showing identifiable people in a bad light, selling unaltered copies
and redistributing on other stock platforms. New API-key issuance was reported as paused on the Pexels API page. The licence
is NOT unrestricted: the restrictions are recorded in each asset's metadata."""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from abc import ABC, abstractmethod
from pathlib import Path

PEXELS_LICENSE_URL = "https://www.pexels.com/license/"
PEXELS_LICENSE_NOTES = ("Pexels License: free to use and edit, commercial use allowed, attribution not required. Do not imply "
                        "endorsement by people/brands shown, do not show identifiable people in a bad light, do not sell or "
                        "redistribute unaltered copies.")
ORIENTATION = {"landscape": "landscape", "shorts": "portrait", "square": "square"}


class StockError(RuntimeError):
    """Fatal for this provider for the rest of the job (bad key, offline, rate limited)."""


class StockSkip(StockError):
    """This one file is unsuitable (too large, incomplete); other results may still work."""


class StockProvider(ABC):
    name = "base"

    def __init__(self, config: dict | None = None):
        self.config = config or {}
        self.diagnostics: list[str] = []
        self.disabled_reason: str | None = None
        self.requests = 0

    def note(self, msg: str) -> None:
        if msg not in self.diagnostics:
            self.diagnostics.append(msg)

    @abstractmethod
    def available(self) -> tuple[bool, str]:
        ...

    @abstractmethod
    def fetch(self, query: str, out_dir: str | Path, fmt: str, min_duration: float = 0.0, exclude: set | None = None,
              prefer: str = "video") -> dict | None:
        """Search for `query`, download the best match into out_dir, return an asset dict (or None)."""


class PexelsProvider(StockProvider):
    name = "pexels"
    API = "https://api.pexels.com"
    HOST_SUFFIX = ".pexels.com"

    def _key(self) -> str | None:
        return os.environ.get(self.config.get("api_key_env", "PEXELS_API_KEY")) or None

    def available(self):
        env = self.config.get("api_key_env", "PEXELS_API_KEY")
        if not self._key():
            return False, f"no Pexels API key: set the {env} environment variable (free key from pexels.com/api; key issuance may be paused)"
        return True, "ok"

    # ---- network (patched in tests) -------------------------------------------
    def _get_json(self, path: str, params: dict) -> dict:
        key = self._key()
        url = f"{self.API}{path}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers={"Authorization": key or "", "User-Agent": "youtube-automation-agent/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=self.config.get("timeout_s", 15)) as r:
                remaining = r.headers.get("X-Ratelimit-Remaining")
                data = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                raise StockError(f"Pexels rejected the API key (HTTP {e.code}); check the key in the environment variable") from None
            if e.code == 429:
                raise StockError("Pexels rate limit reached (HTTP 429); continuing with local assets") from None
            raise StockError(f"Pexels API error HTTP {e.code}") from None
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise StockError(f"network unavailable for Pexels ({getattr(e, 'reason', e)}); continuing with local assets") from None
        except ValueError:
            raise StockError("Pexels returned an unreadable response") from None
        if remaining is not None and remaining.isdigit() and int(remaining) <= 2:
            self.note(f"Pexels rate limit almost used up (X-Ratelimit-Remaining={remaining}); stock search stopped")
            self.disabled_reason = "rate limit"
        return data

    def _download(self, url: str, dest: Path, max_bytes: int) -> None:
        host = urllib.parse.urlparse(url)
        if host.scheme != "https" or not (host.hostname or "").endswith(self.HOST_SUFFIX):
            raise StockError(f"refusing to download from non-Pexels host: {host.hostname}")
        part = dest.with_name(dest.name + ".part")
        part.parent.mkdir(parents=True, exist_ok=True)
        req = urllib.request.Request(url, headers={"User-Agent": "youtube-automation-agent/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=self.config.get("timeout_s", 15) * 4) as r, open(part, "wb") as f:
                size = int(r.headers.get("Content-Length") or 0)
                if size > max_bytes:
                    raise StockSkip(f"file too large ({size // 1048576} MB > {max_bytes // 1048576} MB); skipped")
                got = 0
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    got += len(chunk)
                    if got > max_bytes:
                        raise StockSkip("download exceeded the size limit; skipped")
                    f.write(chunk)
            if got == 0 or (size and got != size):
                raise StockSkip("incomplete download")
            part.replace(dest)
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise StockError(f"download failed ({getattr(e, 'reason', e)})") from None
        finally:
            part.unlink(missing_ok=True)

    # ---- selection ---------------------------------------------------------------
    @staticmethod
    def pick_video_file(video: dict, target_w: int, target_h: int) -> dict | None:
        files = [f for f in video.get("video_files", []) if f.get("link") and (f.get("file_type") or "").endswith("mp4")
                 and f.get("width") and f.get("height")]
        if not files:
            return None
        short = min(target_w, target_h)
        ok = [f for f in files if min(f["width"], f["height"]) >= short * 0.9 and max(f["width"], f["height"]) <= 2600]
        if ok:
            return min(ok, key=lambda f: f["width"] * f["height"])          # smallest file that is still sharp enough
        return max(files, key=lambda f: f["width"] * f["height"] if max(f["width"], f["height"]) <= 2600 else 0)

    def _meta(self, kind, item, query, path, extra):
        who = (item.get("user") or {}).get("name") or item.get("photographer") or ""
        who_url = (item.get("user") or {}).get("url") or item.get("photographer_url") or ""
        label = "Video" if kind == "video" else "Photo"
        return {"path": str(path), "kind": kind, "provider": "pexels", "source": item.get("url", ""), "source_url": item.get("url", ""),
                "stock_id": item.get("id"), "query": query, "creator": who, "creator_url": who_url,
                "attribution": f"{label} by {who or 'unknown'} on Pexels ({item.get('url', 'https://www.pexels.com')})",
                "license": "Pexels License", "license_url": PEXELS_LICENSE_URL, "license_notes": PEXELS_LICENSE_NOTES,
                "license_status": "ok", "tags": [], "retrieved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), **extra}

    def fetch(self, query, out_dir, fmt, min_duration=0.0, exclude=None, prefer="video"):
        from scripts.render_video import FORMATS

        exclude = exclude or set()
        if self.disabled_reason:
            return None
        ok, why = self.available()
        if not ok:
            self.disabled_reason = "no key"
            self.note(why)
            return None
        if self.requests >= self.config.get("max_requests", 40):
            self.note("per-job Pexels request budget reached; remaining scenes use local assets")
            return None
        w, h = FORMATS[fmt]
        orient = ORIENTATION[fmt]
        out = Path(out_dir)
        per_page = int(self.config.get("per_page", 10))
        max_vid = int(self.config.get("max_video_mb", 60)) * 1048576
        max_img = int(self.config.get("max_image_mb", 25)) * 1048576
        try:
            order = ["video", "image"] if prefer == "video" else ["image", "video"]
            for kind in order:
                self.requests += 1
                if kind == "video":
                    data = self._get_json("/v1/videos/search", {"query": query, "orientation": orient, "per_page": per_page})
                    items = [v for v in data.get("videos", []) if v.get("id") not in exclude and 1 <= (v.get("duration") or 0) <= 120]
                    # prefer clips long enough to cover the scene (shorter ones would loop); otherwise the longest
                    items.sort(key=lambda v: (0, abs(v["duration"] - max(min_duration, 5))) if v["duration"] >= min_duration
                               else (1, -v["duration"]))
                    for v in items:
                        f = self.pick_video_file(v, w, h)
                        if not f:
                            continue
                        dest = out / f"pexels_video_{v['id']}.mp4"
                        try:
                            if not dest.exists():
                                self._download(f["link"], dest, max_vid)
                        except StockSkip as e:
                            self.note(str(e))
                            continue
                        return self._meta("video", v, query, dest, {"width": f["width"], "height": f["height"],
                                                                    "duration": v.get("duration"), "orientation": orient})
                else:
                    data = self._get_json("/v1/search", {"query": query, "orientation": orient, "per_page": per_page})
                    for p in data.get("photos", []):
                        link = (p.get("src") or {}).get("large2x") or (p.get("src") or {}).get("large")
                        if p.get("id") in exclude or not link:
                            continue
                        dest = out / f"pexels_photo_{p['id']}.jpg"
                        try:
                            if not dest.exists():
                                self._download(link, dest, max_img)
                        except StockSkip as e:
                            self.note(str(e))
                            continue
                        return self._meta("image", p, query, dest, {"width": p.get("width"), "height": p.get("height"),
                                                                    "orientation": orient})
        except StockError as e:
            self.note(str(e))
            self.disabled_reason = str(e)                   # key/network/rate problems: stop trying for this job
            return None
        self.note(f"no Pexels match for '{query}'")
        return None


REGISTRY = {"pexels": PexelsProvider}


def get_stock_provider(cfg: dict | None) -> StockProvider | None:
    """None when stock.provider is 'none'/unset (the default: fully offline)."""
    cfg = cfg or {}
    name = cfg.get("provider", "none")
    if name in (None, "", "none"):
        return None
    if name not in REGISTRY:
        raise KeyError(f"unknown stock provider {name!r}; options: {sorted(REGISTRY)} or 'none'")
    return REGISTRY[name](cfg)
