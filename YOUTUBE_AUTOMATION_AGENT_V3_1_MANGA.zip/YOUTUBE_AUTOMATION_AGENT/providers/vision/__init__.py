"""Optional vision providers: describe ONE page image at a time (used for image-only manga PDFs, YAA V3.1).

Safety rules enforced here, before any image leaves the device:
  * provider AND model must be configured explicitly (there is no default model);
  * a provider whose endpoint is not on this device ("external") is refused unless the user consented
    (--allow-external-vision), and always refused in local-only mode (--vision-local-only);
  * API keys are read from an environment variable at call time; they are never stored, logged, printed or put in an error message.
Providers: anthropic (Messages API), openai_compatible (any /chat/completions server: hosted or local llama.cpp/LM Studio/vLLM),
ollama (local server), command (local program). Only loopback endpoints count as local."""
from __future__ import annotations

import base64
import json
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from abc import ABC, abstractmethod
from pathlib import Path

MAX_IMAGE_BYTES = 6 * 1024 * 1024


class VisionError(RuntimeError):
    """Base class."""


class VisionFatal(VisionError):
    """Stop the whole job: missing consent/credentials/model, rejected key, unsupported model, policy violation."""


class VisionTransient(VisionError):
    """This page failed (timeout, rate limit, server error, unreadable reply); other pages may still work."""


def is_loopback(url: str | None) -> bool:
    host = (urllib.parse.urlparse(url or "").hostname or "").lower()
    return host in ("localhost", "::1") or host.startswith("127.")


def _redact(text: str, secret: str | None) -> str:
    text = text[:240]
    return text.replace(secret, "***") if secret else text


class VisionProvider(ABC):
    name = "base"
    key_env_default: str | None = None            # None: no key needed
    needs_base_url = False

    def __init__(self, config: dict | None = None):
        self.config = config or {}
        self.model = (self.config.get("model") or "").strip()
        self.timeout = float(self.config.get("timeout_s", 120))
        self.retries = int(self.config.get("retries", 2))
        self.backoff = float(self.config.get("backoff_s", 2.0))

    # --- configuration -----------------------------------------------------------------------------
    @property
    def base_url(self) -> str | None:
        return self.config.get("base_url")

    @property
    def external(self) -> bool:
        """True when page images would leave this device."""
        return not is_loopback(self.base_url)

    def key_env(self) -> str | None:
        return self.config.get("api_key_env") or self.key_env_default

    def _key(self) -> str | None:
        env = self.key_env()
        return os.environ.get(env) if env else None

    def validate(self) -> None:
        if not re.fullmatch(r"[\w.:/@\-]{2,120}", self.model or ""):
            raise VisionFatal(f"vision model not configured for provider '{self.name}': set vision.model (or --vision-model) explicitly; "
                              "there is no default model")
        if self.needs_base_url and not self.base_url:
            raise VisionFatal(f"provider '{self.name}' needs vision.base_url (e.g. http://127.0.0.1:8080/v1 for a local server)")
        if self.key_env_default and not self._key():
            raise VisionFatal(f"missing credentials: set the {self.key_env()} environment variable (the key is never stored or logged)")

    # --- calls ---------------------------------------------------------------------------------------
    @abstractmethod
    def _call(self, image_b64: str, prompt: str, max_tokens: int, image_path: Path) -> str:
        ...

    def describe(self, image_path: str | Path, prompt: str, max_tokens: int = 1500) -> str:
        p = Path(image_path)
        data = p.read_bytes()
        if not data or len(data) > MAX_IMAGE_BYTES:
            raise VisionTransient(f"page image is empty or larger than {MAX_IMAGE_BYTES // 1048576} MB")
        b64 = base64.b64encode(data).decode("ascii")
        last: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                return self._call(b64, prompt, max_tokens, p)
            except VisionTransient as e:
                last = e
                if attempt < self.retries and self.backoff >= 0:
                    time.sleep(self.backoff * (attempt + 1))
        raise VisionTransient(f"{last} (after {self.retries + 1} attempts)")

    def _post_json(self, url: str, headers: dict, body: dict) -> dict:
        key = self._key()
        req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                     headers={"Content-Type": "application/json", "User-Agent": "yaa-vision/1.0", **headers}, method="POST")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if is_loopback(url) else urllib.request.build_opener()
        try:
            with opener.open(req, timeout=self.timeout) as r:     # local servers are never reached through a proxy
                return json.loads(r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            detail = _redact(e.read().decode("utf-8", "replace") if hasattr(e, "read") else "", key)
            if e.code in (401, 403):
                raise VisionFatal(f"credentials rejected by {self.name} (HTTP {e.code}); check the key in ${self.key_env()}") from None
            if e.code in (400, 404, 422) and re.search(r"model|image|vision|multimodal", detail, re.I):
                raise VisionFatal(f"model '{self.model}' is not available or does not support images on {self.name} (HTTP {e.code}: {detail[:120]})") from None
            if e.code == 429 or e.code >= 500:
                raise VisionTransient(f"{self.name} busy or rate limited (HTTP {e.code})") from None
            raise VisionTransient(f"{self.name} API error HTTP {e.code}: {detail[:120]}") from None
        except (TimeoutError, urllib.error.URLError, OSError) as e:
            raise VisionTransient(f"cannot reach {self.name} ({type(getattr(e, 'reason', e)).__name__}); timeout {self.timeout:.0f}s") from None
        except ValueError:
            raise VisionTransient(f"{self.name} returned an unreadable reply") from None


class AnthropicVision(VisionProvider):
    name = "anthropic"
    key_env_default = "ANTHROPIC_API_KEY"

    @property
    def base_url(self):
        return self.config.get("base_url") or "https://api.anthropic.com"

    def _call(self, b64, prompt, max_tokens, image_path):
        out = self._post_json(self.base_url.rstrip("/") + "/v1/messages",
                              {"x-api-key": self._key() or "", "anthropic-version": "2023-06-01"},
                              {"model": self.model, "max_tokens": max_tokens,
                               "messages": [{"role": "user", "content": [
                                   {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b64}},
                                   {"type": "text", "text": prompt}]}]})
        text = "".join(b.get("text", "") for b in out.get("content", []) if isinstance(b, dict) and b.get("type") == "text")
        if not text.strip():
            raise VisionTransient("anthropic returned no text")
        return text


class OpenAICompatibleVision(VisionProvider):
    name = "openai_compatible"
    needs_base_url = True

    def key_env(self):
        return self.config.get("api_key_env")

    def validate(self):
        super().validate()
        env = self.key_env()
        if env and not self._key():
            raise VisionFatal(f"missing credentials: set the {env} environment variable (the key is never stored or logged)")
        if self.external and not env:
            raise VisionFatal("a non-local endpoint needs vision.api_key_env (name of the environment variable that holds the key)")

    def _call(self, b64, prompt, max_tokens, image_path):
        headers = {"Authorization": f"Bearer {self._key()}"} if self._key() else {}
        out = self._post_json(self.base_url.rstrip("/") + "/chat/completions", headers,
                              {"model": self.model, "max_tokens": max_tokens,
                               "messages": [{"role": "user", "content": [
                                   {"type": "text", "text": prompt},
                                   {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}]}]})
        try:
            text = out["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            raise VisionTransient("unexpected reply format from the server") from None
        if not (text or "").strip():
            raise VisionTransient("empty reply")
        return text


class OllamaVision(VisionProvider):
    name = "ollama"

    @property
    def base_url(self):
        return self.config.get("base_url") or "http://127.0.0.1:11434"

    def _call(self, b64, prompt, max_tokens, image_path):
        out = self._post_json(self.base_url.rstrip("/") + "/api/chat", {},
                              {"model": self.model, "stream": False, "options": {"num_predict": max_tokens},
                               "messages": [{"role": "user", "content": prompt, "images": [b64]}]})
        text = (out.get("message") or {}).get("content", "")
        if not text.strip():
            raise VisionTransient("empty reply from ollama")
        return text


class CommandVision(VisionProvider):
    """Local program: config.command is a list; '{image}' is replaced by the page image path; the prompt arrives on stdin."""
    name = "command"

    @property
    def external(self):
        return False

    def validate(self):
        cmd = self.config.get("command")
        if not cmd or not isinstance(cmd, list):
            raise VisionFatal("vision.command must be a list such as [\"llava-cli\", \"--image\", \"{image}\"]")
        if not shutil.which(cmd[0]):
            raise VisionFatal(f"vision command not found: {cmd[0]}")
        if not self.model:
            raise VisionFatal("vision model not configured: set vision.model (a label for the local model; recorded in reports)")

    def _call(self, b64, prompt, max_tokens, image_path):
        cmd = [str(image_path) if c == "{image}" else c for c in self.config["command"]]
        try:
            cp = subprocess.run(cmd, input=prompt, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=self.timeout)
        except subprocess.TimeoutExpired:
            raise VisionTransient(f"local vision command timed out after {self.timeout:.0f}s") from None
        if cp.returncode != 0 or not cp.stdout.strip():
            raise VisionTransient(f"local vision command failed (exit {cp.returncode}): {cp.stderr.strip()[:120]}")
        return cp.stdout


REGISTRY = {"anthropic": AnthropicVision, "openai_compatible": OpenAICompatibleVision, "ollama": OllamaVision, "command": CommandVision}


def get_vision(cfg: dict | None, consent_external: bool = False, local_only: bool = False) -> VisionProvider | None:
    """None when no provider is configured. Raises VisionFatal for every unsafe or incomplete configuration, BEFORE any image is sent."""
    cfg = cfg or {}
    name = cfg.get("provider") or "none"
    if name == "none":
        return None
    if name not in REGISTRY:
        raise VisionFatal(f"unknown vision provider {name!r}; options: {', '.join(sorted(REGISTRY))} or 'none'")
    p = REGISTRY[name](cfg)
    p.validate()
    if p.external:
        if local_only:
            raise VisionFatal(f"local-only mode: provider '{name}' would send page images off this device; use a local provider "
                              "(ollama / openai_compatible on 127.0.0.1 / command) or drop --vision-local-only")
        if not consent_external:
            raise VisionFatal(f"provider '{name}' (model '{p.model}') would UPLOAD page images of your source to an external service. "
                              "Nothing was sent. Pass --allow-external-vision to consent, or use a local provider / --vision-local-only")
    return p
