"""Source-to-Commentary Video (YAA V3.1): import source material, extract grounded content units, hand them to the
existing script -> narration -> subtitles -> render -> QA stages of the topic workflow (no separate pipeline)."""
