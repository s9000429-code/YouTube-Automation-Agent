"""Source discovery: expand folders, detect type, clear errors for unsupported / empty / missing input."""
from __future__ import annotations

import re
from pathlib import Path

TYPES = {".txt": "text", ".md": "text", ".srt": "subtitle", ".vtt": "subtitle", ".pdf": "pdf", ".docx": "docx", ".pptx": "pptx",
         ".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image", ".bmp": "image",
         ".mp4": "video", ".mov": "video", ".mkv": "video", ".webm": "video", ".m4v": "video"}
MODES = ("recap", "explanation", "review", "theory", "lesson", "summary")
FICTION_TYPES = ("image", "video", "subtitle")      # dialogue-style material: commented on, never read out in full
RIGHTS_NOTICE = ("Source material was supplied by the user. This tool does not verify ownership, licences or permission to "
                 "publish; clearing rights for the source (and for any frames or text quoted from it) is the user's responsibility.")


class SourceError(Exception):
    """A source cannot be used; the message says why and what to do."""


def natural_key(p: Path | str):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", Path(p).name)]


def supported_list() -> str:
    return ", ".join(sorted(TYPES))


def detect_type(path: str | Path) -> str:
    p = Path(path)
    t = TYPES.get(p.suffix.lower())
    if not t:
        raise SourceError(f"unsupported file type {p.suffix or '(no extension)'!r} for {p.name}; supported: {supported_list()}")
    if p.stat().st_size == 0:
        raise SourceError(f"{p.name} is empty (0 bytes)")
    return t


def expand_sources(paths: list[str | Path]) -> list[Path]:
    """Files in the order given; a folder expands to its supported files in natural filename order (page order)."""
    out: list[Path] = []
    for raw in paths:
        p = Path(raw).expanduser()
        if not p.exists():
            raise SourceError(f"source not found: {raw}")
        if p.is_dir():
            files = sorted((f for f in p.rglob("*") if f.is_file() and f.suffix.lower() in TYPES), key=lambda f: [natural_key(x) for x in f.relative_to(p).parts])
            if not files:
                raise SourceError(f"folder {p} contains no supported files ({supported_list()})")
            out += files
        elif p.is_file():
            out.append(p)
        else:
            raise SourceError(f"not a regular file: {raw}")
    seen, uniq = set(), []
    for f in out:
        k = str(f.resolve())
        if k not in seen:
            seen.add(k)
            uniq.append(f)
    if not uniq:
        raise SourceError("no source files given")
    for f in uniq:
        detect_type(f)                                  # fail early, before any expensive work
    return uniq
