"""Image-only PDFs (scanned books, manga): understand pages with a VISION model instead of OCR (YAA V3.1, optional).

Flow: choose pages -> render them in small batches -> one vision call per page -> validated JSON -> one `visual` unit per page,
carrying its page number. Everything is checkpointed per page (so an interrupted run resumes), temporary renders are always deleted,
and page images are only sent after provider/model/consent checks (providers.vision.get_vision)."""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from core.resources import mem_available_mb
from core.safe_io import atomic_write_json, quick_fingerprint
from providers.vision import VisionFatal, VisionTransient, get_vision

from .sources import SourceError

PROMPT_VERSION = "1"
MAX_BATCH = 10
MAX_SELECTED = 400
MIN_MEM_MB = 200            # below this we refuse to render
LOW_MEM_MB = 600            # below this we process one page at a time
STOP_AFTER_CONSECUTIVE = 3  # consecutive transient failures before the run is declared systemic
TEXT_MIN_CHARS = 20

PROMPT = """You are describing ONE page of a comic/manga for a spoken recap. Read the panels in reading order (for manga: right-to-left, top-to-bottom, unless the page clearly shows otherwise).
Reply with ONE JSON object and nothing else:
{"page_type": "story" | "cover" | "title" | "blank" | "credits" | "text" | "other",
 "panels": [{"order": 1, "action": "what visibly happens", "characters": "who is visible (name only if it is written on the page, else a plain description)", "setting": "where"}],
 "summary": "2-3 plain sentences, present tense, in YOUR OWN words, telling what happens on this page",
 "story_progress": "one sentence: what changed in the story on this page, or empty",
 "uncertain": ["each thing you are not sure about, e.g. who someone is, what an action means"],
 "confidence": "high" | "medium" | "low"}
Rules: describe only what is visible. Do NOT copy speech bubbles or captions word for word; paraphrase, and never put dialogue in quotation marks.
If something is unclear, say so in "uncertain" and word the summary cautiously ("appears to", "seems to"). Never invent names, motives, plot or events that the page does not show.
For a blank, cover or credits page say so in page_type and keep the summary to one short sentence."""

_QUOTED = re.compile(r"[\"“”«»](?:[^\"“”«»]{1,300})[\"“”«»]")


# --- page selection ----------------------------------------------------------------------------------------------
def parse_pages(spec: str | None, total: int) -> list[int]:
    """'1-5', '1,3,7-9', None/'' = all. Errors are SourceError with a message that says what is wrong."""
    if total < 1:
        raise SourceError("the PDF has no pages")
    if spec is None or not str(spec).strip() or str(spec).strip().lower() == "all":
        sel = list(range(1, total + 1))
    else:
        sel = []
        for part in str(spec).replace(" ", "").split(","):
            m = re.fullmatch(r"(\d+)(?:-(\d+))?", part)
            if not m:
                raise SourceError(f"invalid page range {spec!r}: use forms like 1-5 or 1,3,7-9")
            a = int(m.group(1))
            b = int(m.group(2) or a)
            if a < 1 or b < a:
                raise SourceError(f"invalid page range {part!r}: pages start at 1 and ranges must go upward")
            if b > total:
                raise SourceError(f"page range {part!r} goes past the end: this PDF has {total} pages")
            sel += range(a, b + 1)
        sel = sorted(set(sel))
    if len(sel) > MAX_SELECTED:
        raise SourceError(f"{len(sel)} pages selected; process at most {MAX_SELECTED} at once (use --pdf-pages, e.g. 1-5)")
    return sel


def is_image_only(page_texts: list[str], selected: list[int], sample: int = 24) -> bool:
    """True when (almost) every checked page has no extractable text layer."""
    if not selected:
        return False
    idx = selected if len(selected) <= sample else [selected[round(i * (len(selected) - 1) / (sample - 1))] for i in range(sample)]
    empty = sum(1 for n in idx if n - 1 >= len(page_texts) or len(re.sub(r"\s", "", page_texts[n - 1])) < TEXT_MIN_CHARS)
    return empty / len(idx) >= 0.8


# --- rendering ---------------------------------------------------------------------------------------------------
def render_page(pdf: Path, n: int, dest: Path, max_side: int = 1400, timeout: int = 120) -> Path:
    """One page -> one bounded-size JPEG at `dest`. Raises VisionTransient-like ValueError text via RuntimeError on failure."""
    if not shutil.which("pdftoppm"):
        raise SourceError("pdftoppm is missing (Termux: pkg install poppler; Windows: install Poppler and add it to PATH)")
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="yaa_pg_", dir=dest.parent) as td:     # always removed, even on error/interrupt
        try:
            cp = subprocess.run(["pdftoppm", "-f", str(n), "-l", str(n), "-scale-to", str(max_side), "-jpeg", "-jpegopt", "quality=82",
                                 str(pdf), str(Path(td) / "pg")], capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"rendering page {n} timed out") from None
        out = sorted(Path(td).glob("pg*.jpg"))
        if cp.returncode != 0 or not out or out[0].stat().st_size == 0:
            raise RuntimeError(f"page {n} could not be rendered (corrupt page?): {cp.stderr.strip()[:100]}")
        shutil.move(str(out[0]), str(dest))
    return dest


# --- reply handling ----------------------------------------------------------------------------------------------
def _clean(s, limit=600) -> str:
    return re.sub(r"\s+", " ", s if isinstance(s, str) else "").strip()[:limit]


def parse_reply(text: str) -> dict:
    a, b = text.find("{"), text.rfind("}")
    if a < 0 or b <= a:
        raise ValueError("no JSON object in the reply")
    d = json.loads(text[a:b + 1])
    if not isinstance(d, dict):
        raise ValueError("reply is not a JSON object")
    ptype = _clean(d.get("page_type"), 20).lower() or "story"
    summary = _clean(d.get("summary"), 700)
    flags: list[str] = []
    if _QUOTED.search(summary):                     # the model must not copy dialogue; remove quoted spans
        summary = _clean(_QUOTED.sub("", summary), 700)
        flags.append("dialogue_removed")
    panels = []
    for i, p in enumerate(d.get("panels") if isinstance(d.get("panels"), list) else [], 1):
        if isinstance(p, dict) and i <= 12:
            panels.append({"order": i, **{k: _clean(_QUOTED.sub("", p.get(k, "") if isinstance(p.get(k), str) else ""), 240)
                                          for k in ("action", "characters", "setting")}})
    unc = [_clean(x, 200) for x in (d.get("uncertain") if isinstance(d.get("uncertain"), list) else []) if isinstance(x, str) and x.strip()][:8]
    conf = _clean(d.get("confidence"), 10).lower()
    conf = conf if conf in ("high", "medium", "low") else "low"       # an unusable confidence value counts as low, never as high
    if not summary and ptype in ("story", "other", "text"):
        raise ValueError("the reply has no summary")
    return {"page_type": ptype, "panels": panels, "summary": summary, "story_progress": _clean(_QUOTED.sub("", d.get("story_progress") or "")
            if isinstance(d.get("story_progress"), str) else "", 300), "uncertain": unc, "confidence": conf, "flags": flags}


NO_STORY = ("blank", "cover", "title", "credits")


def analysis_to_unit(n: int, an: dict, image: str | None) -> dict:
    from .extractors import unit
    flags = ["vision", *an.get("flags", [])]
    if an["page_type"] in NO_STORY:
        return unit("visual", "", {"page": n}, "ok", flags + [f"no_story_content:{an['page_type']}"], image=image)
    conf = "low" if an["confidence"] == "low" else "ok"
    if an["uncertain"]:
        flags.append("uncertain_details")
    return unit("visual", an["summary"], {"page": n}, conf, flags, image=image)


# --- the extractor -----------------------------------------------------------------------------------------------
def _cache_dir(root: Path, pdf: Path, provider, dpi_side: int) -> Path:
    h = hashlib.sha256(json.dumps({"fp": quick_fingerprint(pdf), "prov": provider.name, "model": provider.model, "side": dpi_side,
                                   "prompt": PROMPT_VERSION}, sort_keys=True).encode()).hexdigest()[:20]
    return root / h


def extract_visual(path: Path, ctx: dict, page_texts: list[str], selected: list[int]) -> dict:
    from .extractors import unit
    opts = ctx.get("vision_opts") or {}
    cfg = opts.get("vision") or {}
    try:
        provider = get_vision(cfg, consent_external=bool(opts.get("consent")), local_only=bool(opts.get("local_only")))
    except VisionFatal as e:
        raise SourceError(str(e)) from None
    if provider is None:
        raise SourceError("no vision provider configured: set vision.provider and vision.model in config/providers.json "
                          "(or --vision-provider/--vision-model). Nothing was rendered or sent.")
    mem = mem_available_mb()
    if mem and mem < MIN_MEM_MB:
        raise SourceError(f"only {mem} MB of memory is free; close other apps and re-run (finished pages are kept)")
    batch = max(1, min(int(opts.get("batch") or 2), MAX_BATCH))
    max_side = max(600, min(int(opts.get("max_side") or 1400), 2400))
    if mem and mem < LOW_MEM_MB:
        batch, max_side = 1, min(max_side, 1000)
    root = Path(opts.get("cache_root") or Path(ctx["work_dir"]) / "visual")
    cdir = _cache_dir(root, path, provider, max_side)
    (cdir / "pages").mkdir(parents=True, exist_ok=True)
    units, analyses, failed, warnings = [], {}, [], []
    done_calls = consecutive = 0
    try:
        for i in range(0, len(selected), batch):
            for n in selected[i:i + batch]:
                cj, img = cdir / f"p{n:04d}.json", cdir / "pages" / f"p{n:04d}.jpg"
                an = None
                if cj.is_file():
                    try:
                        an = json.loads(cj.read_text(encoding="utf-8")).get("analysis")
                    except (OSError, ValueError):
                        an = None
                if an is None:
                    tmp = cdir / f"_tmp_p{n:04d}.jpg"
                    try:
                        try:
                            render_page(path, n, tmp, max_side)
                        except RuntimeError as e:
                            raise VisionTransient(str(e)) from None
                        raw = provider.describe(tmp, PROMPT)
                        done_calls += 1
                        try:
                            an = parse_reply(raw)
                        except (ValueError, KeyError) as e:
                            raise VisionTransient(f"unreadable reply for this page ({e})") from None
                        shutil.move(str(tmp), str(img))                # keep the bounded page image (used as the scene visual)
                        atomic_write_json(cj, {"page": n, "model": provider.model, "provider": provider.name, "prompt_version": PROMPT_VERSION,
                                               "analysis": an})
                        consecutive = 0
                    except VisionFatal as e:
                        raise SourceError(str(e)) from None
                    except VisionTransient as e:
                        consecutive += 1
                        failed.append({"page": n, "reason": str(e)})
                        units.append(unit("visual", "", {"page": n}, "unreadable", ["vision", "page_analysis_failed"]))
                        if consecutive >= STOP_AFTER_CONSECUTIVE and not any(a for a in analyses.values()):
                            raise SourceError(f"the first {consecutive} pages all failed (last: {e}); stopping so you can check the provider, "
                                              "model and network. Nothing is lost: re-run to retry.") from None
                        continue
                    finally:
                        tmp.unlink(missing_ok=True)                    # temporary render never survives
                analyses[n] = an
                units.append(analysis_to_unit(n, an, str(img) if img.is_file() else None))
        if not analyses:
            raise SourceError("no page could be analysed: " + "; ".join(f"p{f['page']}: {f['reason']}" for f in failed[:3]))
    finally:
        for stray in cdir.glob("_tmp_*"):
            stray.unlink(missing_ok=True)
    units.sort(key=lambda u: u["ref"]["page"])
    if failed:
        warnings.append(f"{len(failed)} page(s) could not be analysed (" + ", ".join(str(f["page"]) for f in failed) + "); they are skipped, re-run to retry")
    meta = {"pages": len(page_texts), "selected_pages": [selected[0], selected[-1]] if selected else [], "analysed_pages": sorted(analyses),
            "failed_pages": failed, "vision": {"provider": provider.name, "model": provider.model, "external": provider.external,
                                               "api_calls_this_run": done_calls, "batch": batch, "max_side": max_side},
            "tool": "vision", "analyses": {str(k): v for k, v in analyses.items()}}
    return {"units": units, "warnings": warnings, "meta": meta}


# --- review files ------------------------------------------------------------------------------------------------
def write_visual_summaries(manifest: list[dict], out_dir: Path) -> list[str]:
    """sources/visual_summaries.json + .md : what the vision model said per page, with uncertainty and failures, for the user to read."""
    pages = []
    for m in manifest:
        meta = m.get("meta", {})
        if meta.get("tool") != "vision":
            continue
        for n, an in sorted(meta.get("analyses", {}).items(), key=lambda kv: int(kv[0])):
            pages.append({"source": m["name"], "page": int(n), **an})
        for f in meta.get("failed_pages", []):
            pages.append({"source": m["name"], "page": f["page"], "failed": True, "reason": f["reason"]})
    if not pages:
        return []
    pages.sort(key=lambda p: (p["source"], p["page"]))
    vis = next(m["meta"]["vision"] for m in manifest if m.get("meta", {}).get("tool") == "vision")
    jp = atomic_write_json(out_dir / "visual_summaries.json", {"vision": vis, "pages": pages})
    L = ["# Visual summaries (generated by a vision model; check them against the pages)", "",
         f"Model: {vis['provider']} / {vis['model']} ({'external API' if vis['external'] else 'local'}). "
         "Page numbers are PDF page numbers. Anything the model was unsure about is listed under *Uncertain*.", ""]
    for p in pages:
        L.append(f"## {p['source']} — page {p['page']}")
        if p.get("failed"):
            L += [f"**FAILED**: {p['reason']}", ""]
            continue
        L.append(f"Type: {p['page_type']} · confidence: {p['confidence']}")
        L.append(p["summary"] or "(no story content)")
        if p["story_progress"]:
            L.append(f"Story progress: {p['story_progress']}")
        for q in p["panels"]:
            L.append(f"- panel {q['order']}: {q['action']} | characters: {q['characters']} | setting: {q['setting']}")
        if p["uncertain"]:
            L += ["Uncertain:"] + [f"- {x}" for x in p["uncertain"]]
        if p["flags"]:
            L.append("Notes: " + ", ".join(p["flags"]))
        L.append("")
    mp = out_dir / "visual_summaries.md"
    from core.safe_io import atomic_write_text
    atomic_write_text(mp, "\n".join(L))
    return [str(jp), str(mp)]
