"""Ingest: extract every source (cached), keep source order, record the manifest, and store each readable unit as a
research fact so the existing script validation / metadata / QA modules can trace every sentence back to the source."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from core.config import resolve_path
from core.job_manager import JobManager
from core.resources import mem_available_mb
from core.safe_io import atomic_write_json, quick_fingerprint

from . import extractors
from .sources import RIGHTS_NOTICE, SourceError, detect_type, expand_sources

EXTRACTOR_VERSION = "1"
HEDGE_FLAG = "hedged_wording"


def cache_key(path: Path, stype: str, language: str, tx: dict, sidecar: Path | None, extra: dict | None = None) -> str:
    parts = {"v": EXTRACTOR_VERSION, "type": stype, "lang": language, "fp": quick_fingerprint(path), "ocr": extractors.ocr_available(),
             "side": quick_fingerprint(sidecar) if sidecar else None, "engine": tx.get("engine"), "model": tx.get("model_path")}
    if extra:
        parts["extra"] = extra                                 # only PDFs with page range / vision options; other keys unchanged
    return hashlib.sha256(json.dumps(parts, sort_keys=True).encode()).hexdigest()[:24]


def _extract_cached(path: Path, stype: str, cache_root: Path, language: str, tx: dict, extra_ctx: dict) -> tuple[dict, bool, str]:
    side = extractors._sidecar(path) if stype == "video" and not extra_ctx.get("transcript_file") else None
    pdf_extra = None
    if stype == "pdf" and (extra_ctx.get("pdf_pages") or extra_ctx.get("pdf_mode")):
        v = (extra_ctx.get("vision_opts") or {}).get("vision") or {}
        pdf_extra = {"pages": extra_ctx.get("pdf_pages"), "mode": extra_ctx.get("pdf_mode"), "prov": v.get("provider"), "model": v.get("model")}
    key = cache_key(path, stype, language, tx, side or (Path(extra_ctx["transcript_file"]) if extra_ctx.get("transcript_file") else None), pdf_extra)
    d = cache_root / key
    rj = d / "result.json"
    if rj.is_file():
        try:
            res = json.loads(rj.read_text(encoding="utf-8"))
            if res.get("version") == EXTRACTOR_VERSION:
                return res, True, key
        except (OSError, ValueError):
            pass                                              # damaged cache entry: extract again
    d.mkdir(parents=True, exist_ok=True)
    ctx = {"work_dir": str(d), "language": language, "transcription": tx, **extra_ctx}
    res = extractors.EXTRACTORS[stype](path, ctx)
    res["version"] = EXTRACTOR_VERSION
    atomic_write_json(rj, res)
    return res, False, key


def ingest_sources(jm: JobManager, job_id: str, raw_paths: list[str], settings: dict, language: str, progress=None,
                   transcript_files: dict | None = None, pdf_opts: dict | None = None) -> dict:
    jdir = jm.job_dir(job_id)
    files = expand_sources(raw_paths)
    tx = dict(settings["shorts"]["transcription"])
    cache_root = resolve_path(settings, "projects") / "cache" / "sources"
    max_frames = settings.get("source_commentary", {}).get("max_frames", 60 if mem_available_mb() > 1500 or mem_available_mb() == 0 else 30)
    manifest, errors, all_units = [], [], []
    page = 0
    for i, f in enumerate(files):
        sid, stype = f"src{i + 1}", detect_type(f)
        entry = {"id": sid, "order": i + 1, "path": str(f.resolve()), "name": f.name, "type": stype, "size": f.stat().st_size,
                 "rights": "unverified"}
        extra = {"max_frames": max_frames, "transcript_file": (transcript_files or {}).get(str(f))}
        if stype == "pdf" and pdf_opts:
            extra.update(pdf_mode=pdf_opts.get("mode"), pdf_pages=pdf_opts.get("pages"),
                         vision_opts={**pdf_opts.get("vision_opts", {}), "cache_root": str(resolve_path(settings, "projects") / "cache" / "visual")})
        try:
            res, cached, key = _extract_cached(f, stype, cache_root, language, tx, extra)
        except SourceError as e:
            entry.update(status="failed", error=str(e))
            errors.append(f"{f.name}: {e}")
            manifest.append(entry)
            continue
        except Exception as e:                              # tool failures must become a clear message, not a traceback
            entry.update(status="failed", error=f"{type(e).__name__}: {e}")
            errors.append(f"{f.name}: could not be processed ({type(e).__name__}: {e})")
            manifest.append(entry)
            continue
        if stype == "image":
            page += 1
            for u in res["units"]:
                u["ref"] = {"page": page}
        units = res["units"]
        readable = [u for u in units if u["text"]]
        entry.update(status="ok" if readable else "unreadable", cache_key=key, cached=cached, units=len(units),
                     readable_units=len(readable), warnings=res.get("warnings", []), meta=res.get("meta", {}),
                     unreadable=[u["ref"] for u in units if not u["text"] and u["confidence"] == "unreadable"],
                     low_confidence=[u["ref"] for u in units if u["confidence"] == "low"])
        for u in units:
            u.update(source=sid, source_type=stype)
        all_units += units
        manifest.append(entry)
        if progress:
            progress((i + 1) / len(files))
    if errors:
        raise SourceError("; ".join(errors))
    if not any(u["text"] for u in all_units):
        why = "; ".join(f"{m['name']}: " + ("; ".join(m.get("warnings", [])) or "no readable text") for m in manifest)
        raise SourceError("no readable content in the supplied sources (" + why + "). For scanned/image pages install tesseract "
                          "(Termux: pkg install tesseract); for video provide a subtitle file next to it or configure whisper.cpp")
    c = jm.conn
    c.execute("DELETE FROM research_facts WHERE job_id=?", (job_id,))
    c.execute("DELETE FROM research_sources WHERE job_id=?", (job_id,))
    db_src = {}
    for m in manifest:
        cur = c.execute("INSERT INTO research_sources(job_id,url,title,publisher,published,retrieved_at,license,extract) VALUES (?,?,?,?,?,?,?,?)",
                        (job_id, f"file://{m['name']}", m["name"], "user-supplied source", "", "", "unknown", ""))
        db_src[m["id"]] = cur.lastrowid
    for n, u in enumerate(all_units, 1):
        u["id"] = f"u{n:04d}"
        u["order"] = n
        if u["text"]:
            flags = list(u["flags"])
            from scripts.research_manager import HEDGE
            if HEDGE.search(u["text"]):
                flags.append(HEDGE_FLAG)
            u["confidence_label"] = "uncertain" if (u["confidence"] == "low" or HEDGE_FLAG in flags) else "supported"
            cur = c.execute("INSERT INTO research_facts(job_id,source_id,text,kind,confidence,supported,flag) VALUES (?,?,?,?,?,?,?)",
                            (job_id, db_src[u["source"]], u["text"], "explanation", u["confidence_label"],
                             int(u["confidence_label"] == "supported"), ",".join(flags)))
            u["fact_id"] = cur.lastrowid
    out_dir = jdir / "sources"
    out_dir.mkdir(exist_ok=True)
    mp = atomic_write_json(out_dir / "manifest.json", {"job_id": job_id, "rights_notice": RIGHTS_NOTICE, "sources": manifest,
                                                       "totals": {"sources": len(manifest), "units": len(all_units),
                                                                  "readable_units": sum(1 for u in all_units if u["text"]),
                                                                  "unreadable_units": sum(1 for u in all_units if not u["text"])}})
    up = atomic_write_json(out_dir / "units.json", all_units)
    from .manga import write_visual_summaries
    visual = write_visual_summaries(manifest, out_dir)
    return {"manifest": str(mp), "units": str(up), "sources": manifest, "unit_count": len(all_units), "visual_summaries": visual}
