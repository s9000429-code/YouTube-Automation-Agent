"""Extractors: one function per source type -> {"units": [...], "warnings": [...], "meta": {...}}.

A unit is the smallest grounded piece of source content:
  {"kind": text|transcript|scene|ocr, "text": str, "ref": {...page/slide/start/end...}, "confidence": ok|low|unreadable,
   "flags": [...], "frame": path|None}
Nothing is invented: unreadable content becomes a unit with empty text and an explicit flag. Everything is processed page by
page / chunk by chunk (no whole-video or whole-document loading), and the user's files are only ever read."""
from __future__ import annotations

import re
import shutil
import subprocess
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from core.media import MediaError, ffmpeg, run
from core.safe_io import require_free_space

from .sources import SourceError, natural_key

MAX_UNIT_CHARS = 500
OCR_LANG = {"en": "eng", "hinglish": "eng", "hi": "hin", "kn": "kan", "te": "tel"}
MAX_PIXELS = 120_000_000
STRIP_H = 3000                                  # tall webtoon strips are OCR'd in slices to bound memory
LOW_OCR_CONF = 55


def unit(kind, text, ref, confidence="ok", flags=None, frame=None, image=None) -> dict:
    return {"kind": kind, "text": text, "ref": ref, "confidence": confidence, "flags": list(flags or []), "frame": frame, "image": image}


def chunk_text(text: str, limit: int = MAX_UNIT_CHARS) -> list[str]:
    """Paragraphs, merged/split on sentence boundaries into units of at most ~limit characters."""
    out: list[str] = []
    for para in re.split(r"\n\s*\n", text.replace("\r\n", "\n")):
        para = re.sub(r"\s+", " ", para).strip()
        if not para:
            continue
        if len(para) <= limit:
            out.append(para)
            continue
        cur = ""
        for s in re.split(r"(?<=[.!?।])\s+", para):
            if cur and len(cur) + len(s) + 1 > limit:
                out.append(cur)
                cur = s
            else:
                cur = f"{cur} {s}".strip()
        if cur:
            out.append(cur)
    return out


# ---- text / subtitles --------------------------------------------------------------------------------------------
def extract_text(path: Path, ctx: dict) -> dict:
    raw = path.read_bytes()
    warnings = []
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="replace")
        warnings.append("not valid UTF-8; decoded as Windows-1252 (accents may be wrong)")
    if "\x00" in text[:2000]:
        raise SourceError(f"{path.name} looks like a binary file, not text")
    units = [unit("text", t, {"para": i + 1}) for i, t in enumerate(chunk_text(text))]
    if not units:
        raise SourceError(f"{path.name} contains no text")
    return {"units": units, "warnings": warnings, "meta": {"chars": len(text)}}


def _transcript_units(t, window_s=25.0) -> list[dict]:
    units, cur, a, b = [], [], None, 0.0
    for s in t.segments:
        if not s.text.strip():
            continue
        if cur and (s.end - a > window_s or sum(len(x) for x in cur) > MAX_UNIT_CHARS):
            units.append(unit("transcript", " ".join(cur), {"start": round(a, 2), "end": round(b, 2)}))
            cur, a = [], None
        if a is None:
            a = s.start
        cur.append(s.text.strip())
        b = s.end
    if cur:
        units.append(unit("transcript", " ".join(cur), {"start": round(a, 2), "end": round(b, 2)}))
    return units


def extract_subtitle(path: Path, ctx: dict) -> dict:
    from providers.transcription.parsers import load_transcript_file
    try:
        t = load_transcript_file(path)
    except Exception as e:
        raise SourceError(f"cannot parse subtitle file {path.name}: {e}") from None
    units = _transcript_units(t)
    if not units:
        raise SourceError(f"{path.name} has no subtitle text")
    return {"units": units, "warnings": [], "meta": {"cues": len(t.segments)}}


# ---- OCR ---------------------------------------------------------------------------------------------------------
def ocr_available() -> bool:
    return shutil.which("tesseract") is not None


_LANGS: set[str] | None = None


def _ocr_lang(language: str, warnings: list[str]) -> str:
    global _LANGS
    want = OCR_LANG.get(language, "eng")
    if _LANGS is None:
        try:
            cp = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=30)
            _LANGS = set((cp.stdout or "").split()[1:])
        except Exception:
            _LANGS = {"eng"}
    if want not in _LANGS:
        warnings.append(f"OCR language data '{want}' is not installed; used English (install tesseract language data for better results)")
        return "eng"
    return want


def ocr_image(path: Path, language: str, warnings: list[str], tmp_dir: Path) -> tuple[str, float | None]:
    """OCR one image file; returns (text, mean word confidence 0-100). Tall images are processed in slices."""
    from PIL import Image
    lang = _ocr_lang(language, warnings)
    texts, confs = [], []
    with Image.open(path) as im:
        w, h = im.size
        pieces = [(0, min(h, STRIP_H))] if h <= STRIP_H * 1.2 else [(y, min(h, y + STRIP_H)) for y in range(0, h, STRIP_H)]
        for k, (y0, y1) in enumerate(pieces):
            src = path
            tmp = None
            if len(pieces) > 1:
                tmp = tmp_dir / f".ocr_strip_{path.stem}_{k}.png"
                im.crop((0, y0, w, y1)).convert("RGB").save(tmp)
                src = tmp
            try:
                cp = subprocess.run(["tesseract", str(src), "stdout", "-l", lang, "--psm", "6", "tsv"], capture_output=True, text=True,
                                    timeout=180, encoding="utf-8", errors="replace")
            except subprocess.TimeoutExpired:
                warnings.append(f"OCR timed out on {path.name}")
                continue
            finally:
                if tmp:
                    tmp.unlink(missing_ok=True)
            if cp.returncode != 0:
                warnings.append(f"OCR failed on {path.name}: {cp.stderr.strip()[-120:]}")
                continue
            lines: dict[tuple, list[str]] = {}
            for row in cp.stdout.splitlines()[1:]:
                f = row.split("\t")
                if len(f) < 12 or not f[11].strip():
                    continue
                try:
                    c = float(f[10])
                except ValueError:
                    continue
                if c < 0:
                    continue
                confs.append(c)
                if c >= 30:
                    lines.setdefault((f[2], f[3], f[4]), []).append(f[11].strip())
            texts.append("\n".join(" ".join(v) for v in lines.values()))
    text = re.sub(r"[ \t]+", " ", "\n".join(t for t in texts if t)).strip()
    return text, (sum(confs) / len(confs) if confs else None)


def _ocr_unit(path: Path, ref: dict, language: str, warnings: list[str], tmp_dir: Path, kind="ocr", image=None) -> dict:
    img = image or str(path)
    if not ocr_available():
        return unit(kind, "", ref, "unreadable", ["no_ocr_engine"], image=img)
    text, conf = ocr_image(path, language, warnings, tmp_dir)
    if len(re.sub(r"\W", "", text)) < 3:
        return unit(kind, "", ref, "unreadable", ["no_text_detected"], image=img)
    low = conf is not None and conf < LOW_OCR_CONF
    return unit(kind, text, ref, "low" if low else "ok", ["low_ocr_confidence"] if low else [], image=img)


def extract_image(path: Path, ctx: dict) -> dict:
    from PIL import Image
    warnings: list[str] = []
    try:
        with Image.open(path) as im:
            im.verify()
        with Image.open(path) as im:
            w, h = im.size
    except Exception as e:                       # UnidentifiedImageError, DecompressionBombError, truncated files
        raise SourceError(f"{path.name} is not a readable image ({type(e).__name__}: {e})") from None
    if w * h > MAX_PIXELS:
        raise SourceError(f"{path.name} is too large ({w}x{h}); resize it first")
    ref = {"page": ctx.get("page", 1)}
    Path(ctx["work_dir"]).mkdir(parents=True, exist_ok=True)
    u = _ocr_unit(path, ref, ctx.get("language", "en"), warnings, Path(ctx["work_dir"]))
    u["meta"] = {"width": w, "height": h}
    return {"units": [u], "warnings": warnings, "meta": {"width": w, "height": h, "tall_strip": h > w * 3}}


# ---- documents ---------------------------------------------------------------------------------------------------
def _pdf_pages(path: Path) -> tuple[list[str], str]:
    if shutil.which("pdftotext"):
        cp = subprocess.run(["pdftotext", "-enc", "UTF-8", str(path), "-"], capture_output=True, text=True, timeout=300,
                            encoding="utf-8", errors="replace")
        if cp.returncode != 0:
            err = cp.stderr.lower()
            if "password" in err or "encrypt" in err:
                raise SourceError(f"{path.name} is password-protected; remove the password first")
            raise SourceError(f"{path.name} is corrupt or not a valid PDF ({cp.stderr.strip()[-100:]})")
        pages = cp.stdout.split("\f")
        if pages and not pages[-1].strip():
            pages = pages[:-1]
        return pages, "pdftotext"
    try:
        from pypdf import PdfReader
        r = PdfReader(str(path))
        if r.is_encrypted:
            raise SourceError(f"{path.name} is password-protected; remove the password first")
        return [(pg.extract_text() or "") for pg in r.pages], "pypdf"
    except ImportError:
        raise SourceError("no PDF text extractor found: install poppler (Termux: pkg install poppler; Windows: poppler binaries) "
                          "or `pip install pypdf`") from None
    except SourceError:
        raise
    except Exception as e:
        raise SourceError(f"{path.name} is corrupt or not a valid PDF ({type(e).__name__}: {e})") from None


def extract_pdf(path: Path, ctx: dict) -> dict:
    with open(path, "rb") as f:
        head = f.read(1024)
    if b"%PDF-" not in head:
        raise SourceError(f"{path.name} is not a PDF (missing %PDF header)")
    pages, tool = _pdf_pages(path)
    if not pages:
        raise SourceError(f"{path.name} has no pages")
    from . import manga                                  # optional V3.1 vision path for image-only PDFs
    mode = ctx.get("pdf_mode") or "auto"
    if mode not in ("auto", "text", "vision"):
        raise SourceError(f"unknown --pdf-mode {mode!r}; options: auto, text, vision")
    selected = manga.parse_pages(ctx.get("pdf_pages"), len(pages)) if ctx.get("pdf_pages") else list(range(1, len(pages) + 1))
    vopts = ctx.get("vision_opts") or {}
    has_vision = (vopts.get("vision") or {}).get("provider", "none") != "none"
    note = []
    if mode == "vision" or (mode == "auto" and manga.is_image_only(pages, selected)):
        if mode == "vision" or has_vision:
            return manga.extract_visual(path, ctx, pages, selected)
        note.append("this PDF has no text layer (image-only); OCR was used. For manga/comics configure a vision provider "
                    "(vision.provider/vision.model in config/providers.json, --vision-provider/--vision-model) for much better results")
    units, warnings, ocr_done = [], list(note), 0
    max_ocr = int(ctx.get("max_ocr_pages", 150))
    work = Path(ctx["work_dir"])
    work.mkdir(parents=True, exist_ok=True)
    for n, txt in enumerate(pages, 1):
        if n not in selected:
            continue
        if len(re.sub(r"\s", "", txt)) >= 20:
            units += [unit("text", t, {"page": n}) for t in chunk_text(txt)]
            continue
        # scanned / image-only page: render and OCR it
        if not (ocr_available() and shutil.which("pdftoppm")):
            units.append(unit("ocr", "", {"page": n}, "unreadable", ["scanned_page_no_ocr"]))
            continue
        if ocr_done >= max_ocr:
            units.append(unit("ocr", "", {"page": n}, "unreadable", ["ocr_page_limit"]))
            continue
        ocr_done += 1
        prefix = work / f"{path.stem}_p{n}"
        cp = subprocess.run(["pdftoppm", "-f", str(n), "-l", str(n), "-r", "150", "-png", str(path), str(prefix)], capture_output=True, text=True, timeout=180)
        img = next(iter(sorted(work.glob(f"{prefix.name}*.png"))), None)
        if cp.returncode != 0 or not img:
            units.append(unit("ocr", "", {"page": n}, "unreadable", ["page_render_failed"]))
            continue
        units.append(_ocr_unit(img, {"page": n}, ctx.get("language", "en"), warnings, work, "ocr", image=str(img)))
        if units[-1]["confidence"] == "unreadable":
            units[-1]["image"] = str(img)
    if ocr_done >= max_ocr:
        warnings.append(f"OCR limited to {max_ocr} scanned pages")
    if not any(u["text"] for u in units):
        warnings.append("no readable text in this PDF")
    return {"units": units, "warnings": warnings, "meta": {"pages": len(pages), "ocr_pages": ocr_done, "tool": tool}}


def _safe_xml(zf: zipfile.ZipFile, name: str) -> ET.Element:
    data = zf.read(name)
    if len(data) > 60 * 1024 * 1024 or b"<!DOCTYPE" in data[:2000] or b"<!ENTITY" in data[:20000]:
        raise SourceError(f"{name} in the archive is oversized or uses unsafe XML features; refusing to parse it")
    return ET.fromstring(data)


def extract_docx(path: Path, ctx: dict) -> dict:
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    try:
        with zipfile.ZipFile(path) as zf:
            root = _safe_xml(zf, "word/document.xml")
    except (zipfile.BadZipFile, KeyError):
        raise SourceError(f"{path.name} is corrupt or not a .docx file") from None
    except ET.ParseError as e:
        raise SourceError(f"{path.name} has unreadable XML content: {e}") from None
    paras = ["".join(t.text or "" for t in p.iter(W + "t")) for p in root.iter(W + "p")]
    units = [unit("text", t, {"para": i + 1}) for i, t in enumerate(chunk_text("\n\n".join(p for p in paras if p.strip())))]
    if not units:
        raise SourceError(f"{path.name} contains no text")
    return {"units": units, "warnings": [], "meta": {"paragraphs": len(paras)}}


def extract_pptx(path: Path, ctx: dict) -> dict:
    A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    try:
        with zipfile.ZipFile(path) as zf:
            names = sorted((n for n in zf.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)), key=natural_key)
            if not names:
                raise SourceError(f"{path.name} has no slides")
            units = []
            for i, n in enumerate(names, 1):
                root = _safe_xml(zf, n)
                text = " ".join(t for t in ("".join(x.text or "" for x in p.iter(A + "t")).strip() for p in root.iter(A + "p")) if t)
                units += [unit("text", t, {"slide": i}) for t in chunk_text(text)] or [unit("text", "", {"slide": i}, "unreadable", ["empty_slide"])]
    except zipfile.BadZipFile:
        raise SourceError(f"{path.name} is corrupt or not a .pptx file") from None
    except ET.ParseError as e:
        raise SourceError(f"{path.name} has unreadable XML content: {e}") from None
    if not any(u["text"] for u in units):
        raise SourceError(f"{path.name} contains no slide text")
    return {"units": units, "warnings": [], "meta": {"slides": len(names)}}


# ---- video -------------------------------------------------------------------------------------------------------
def detect_scenes(path: Path, duration: float, chunk_s: float = 300.0, threshold: float = 0.30, min_len: float = 2.0,
                  max_scenes: int = 60) -> tuple[list[tuple[float, float]], list[str]]:
    """Scene boundaries found window by window (bounded memory, low-res analysis)."""
    cuts: list[float] = []
    a = 0.0
    while a < duration:
        cp = run(["ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "info", "-ss", f"{a:.2f}", "-t", f"{chunk_s:.2f}", "-i", path, "-an",
                  "-vf", f"scale=160:-2,select='gt(scene,{threshold})',showinfo", "-f", "null", "-"])
        cuts += [a + float(m) for m in re.findall(r"pts_time:([0-9.]+)", cp.stderr)]
        a += chunk_s
    flags: list[str] = []
    bounds = [0.0]
    for c in sorted(cuts):
        if c - bounds[-1] >= min_len and duration - c >= min_len:
            bounds.append(c)
    if len(bounds) == 1 and duration > 90:
        step = max(60.0, duration / max_scenes)
        bounds = [i * step for i in range(int(duration // step) + 1) if i * step < duration]
        flags.append("no_scene_cuts_detected: fixed intervals used")
    if len(bounds) > max_scenes:
        keep = [bounds[int(i * len(bounds) / max_scenes)] for i in range(max_scenes)]
        bounds = keep
        flags.append(f"scenes condensed to {max_scenes}")
    bounds.append(duration)
    return [(bounds[i], bounds[i + 1]) for i in range(len(bounds) - 1)], flags


def _sidecar(path: Path) -> Path | None:
    for ext in (".srt", ".vtt", ".json"):
        p = path.with_suffix(ext)
        if p.is_file():
            return p
    return None


def extract_video(path: Path, ctx: dict) -> dict:
    from modules.long_form_to_shorts import audio_extractor, transcription_engine, video_analyzer
    from providers.transcription import EngineUnavailable, choose_engine
    warnings: list[str] = []
    an = video_analyzer.analyze_video(path)
    errs = [e for e in an["errors"] if "audio" not in e]
    if errs or not an["info"]:
        raise SourceError(f"{path.name} cannot be read as video: {'; '.join(an['errors'])}")
    info = an["info"]
    warnings += an["warnings"]
    dur = info["duration"]
    work = Path(ctx["work_dir"])
    work.mkdir(parents=True, exist_ok=True)
    require_free_space(work, int(dur * 16000 * 2) + 60_000_000, reserve_bytes=256 * 1024 * 1024)
    # --- dialogue
    segs = []
    side = ctx.get("transcript_file") or _sidecar(path)
    try:
        eng = choose_engine(ctx.get("transcription", {}), str(side) if side else None)
        if eng.name == "imported":
            t = eng.transcribe(None, None)
        elif not info["has_audio"]:
            raise EngineUnavailable("video has no audio stream")
        else:
            wav = audio_extractor.extract_audio(path, work / "audio_16k.wav", duration_hint=dur)
            try:
                t = transcription_engine.transcribe_audio(eng, wav, dur, ctx.get("language"), work,
                                                          chunk_s=ctx.get("transcription", {}).get("chunk_s", 600))
            finally:
                wav.unlink(missing_ok=True)
        segs = t.segments
        warnings.append(f"dialogue from: {eng.name}" + ("" if eng.name == "imported" else " (machine transcription; may contain errors)"))
    except EngineUnavailable as e:
        warnings.append(f"no dialogue transcript: {e}")
    # --- scenes + representative frames
    scenes, sflags = detect_scenes(path, dur, ctx.get("scene_chunk_s", 300.0), ctx.get("scene_threshold", 0.30))
    warnings += sflags
    cap = int(ctx.get("max_frames", 60))
    units = []
    fdir = work / "frames"
    fdir.mkdir(exist_ok=True)
    for k, (a, b) in enumerate(scenes[:cap]):
        mid = a + (b - a) / 2
        out = fdir / f"{path.stem}_scene{k:03d}.jpg"
        try:
            ffmpeg(["-ss", f"{mid:.2f}", "-i", path, "-frames:v", "1", "-vf", "scale='min(1280,iw)':-2", "-q:v", "4", out])
        except MediaError:
            out = None
        text = " ".join(s.text.strip() for s in segs if a <= (s.start + s.end) / 2 < b and s.text.strip())
        units.append(unit("scene", text, {"start": round(a, 2), "end": round(b, 2)}, "ok",
                          [] if text else ["no_dialogue"], frame=str(out) if out and out.exists() else None))
    if len(scenes) > cap:
        warnings.append(f"only the first {cap} of {len(scenes)} scenes were used (raise max_frames to cover more)")
    return {"units": units, "warnings": warnings, "meta": {"duration": dur, "scenes": len(scenes), "has_audio": info["has_audio"],
                                                           "width": info["width"], "height": info["height"]}}


EXTRACTORS = {"text": extract_text, "subtitle": extract_subtitle, "pdf": extract_pdf, "docx": extract_docx, "pptx": extract_pptx,
              "image": extract_image, "video": extract_video}
