YAA V3.1 manga/image-only-PDF vision feature: overlay patch (11 files: 4 new, 7 edited)
Apply from the folder that CONTAINS YOUTUBE_AUTOMATION_AGENT (back it up first):
  cp -r YOUTUBE_AUTOMATION_AGENT YOUTUBE_AUTOMATION_AGENT.bak
  unzip -o YAA_V3_1_manga_vision_patch.zip -d patchtmp && cp -r patchtmp/YOUTUBE_AUTOMATION_AGENT/. YOUTUBE_AUTOMATION_AGENT/
The 7 edited files were changed against the V3.1 release zip; if you changed them yourself, use manga_vision.patch instead (patch -p0 style, see CHANGED_FILES.txt).
Verify: cd YOUTUBE_AUTOMATION_AGENT && python agent.py video make --help | grep -E "pdf-|vision"
