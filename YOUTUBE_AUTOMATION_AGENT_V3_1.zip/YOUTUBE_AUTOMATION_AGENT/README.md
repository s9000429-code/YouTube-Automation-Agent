# YouTube Automation Agent (YAA V3.1)

Two independent workflows sharing one core (SQLite jobs, checkpoints, safe file handling):

- **Mode A**: `topic -> research -> script -> narration -> subtitles -> assets -> render -> thumbnail -> metadata -> QA`
- **Mode B**: `long video -> transcript -> highlights -> review/approve -> vertical Shorts + captions + metadata -> QA`

Nothing is uploaded or published. You upload.

## What is new in V3.1: Source-to-Commentary Video

V3.1 is V3 plus one feature; every V3 workflow and command works as before. Give the agent source material (PDF, DOCX, PPTX, TXT/MD,
SRT/VTT, manga/manhwa page images, anime episodes or clips) and it writes an **original-structure, source-grounded commentary**,
pauses for you to review/edit the script, then narrates, subtitles, renders and QA-checks it with the same stages as the topic workflow.

```bash
# Termux optional tools (without them scanned pages / image-only PDFs / speech-less video are reported "unreadable", never guessed):
pkg install tesseract poppler            # OCR + PDF text.   Windows: install Tesseract and Poppler and put them on PATH

# 1. create the job; it stops at the script review gate
python3 agent.py video make "Chapter 1 recap" --source ~/storage/shared/Download/chapter1/ --source notes.pdf \
        --content-mode recap --duration 120 --language en
# 2. read / edit / approve the script (nothing is narrated before this)
python3 agent.py video review JOB_ID
python3 agent.py video edit-script JOB_ID --file edited.md      # edit the text under each "## heading"; keep every heading
python3 agent.py video approve-script JOB_ID
# 3. narrate + render + QA
python3 agent.py video run JOB_ID
```
`--auto-approve-script` skips the pause (not recommended). Add `--editing natural`, `--format shorts`, `--tts ...`, `--burn-subtitles` as usual.

| Input | How it is read |
|---|---|
| `.txt .md` | paragraphs, in order |
| `.pdf` | text per page (`pdftotext`, else `pypdf`); image-only pages are rendered (`pdftoppm`) and OCR'd (`tesseract`) |
| `.docx .pptx` | paragraphs / slides in order (pure Python; unsafe XML is refused) |
| `.srt .vtt` | timed dialogue |
| `.png .jpg .jpeg .webp .bmp` | one page each, in filename order (a folder is read in natural order: page_2 before page_10); OCR text + the page is shown as the visual |
| `.mp4 .mov .mkv .webm .m4v` | scenes found window by window (5 min at a time, low resolution), one representative frame per scene (max 60), dialogue from a subtitle file next to the video (`ep.srt/.vtt/.json`) or from whisper.cpp/faster-whisper if configured; audio is transcribed in chunks |

Content modes (`--content-mode`): `recap` (default), `explanation`, `lesson`, `summary` work with or without an LLM. `review` and `theory`
**require an LLM** (`llm.provider` in `config/providers.json`) because opinions and theories cannot be produced from templates without inventing them.

How grounding works: every source part becomes a unit stored as a research fact; every claim sentence carries the ids of the units it comes from
(validated by the existing script checks). Unreadable or low-confidence parts are flagged, hedged ("hard to read, but seems to mention...") or left
out of the narration, never invented. Without an LLM the commentary is a **plain grounded outline**: for dialogue-style sources (video, manga) it says
what each part mentions (key terms) with at most one short quote (default 10 words, `--quote-words N`, 0 = none); it never reads dialogue out in
full. With an LLM each section is accepted only if it adds no new numbers or proper names, copies no 8-word run, stays within the section's
vocabulary, and (theory) is phrased as a possibility; otherwise the plain template is used (review/theory sections are skipped). QA reports the
share of wording copied from the source and warns above 50%. Text documents are narrated as short extracts, so expect a high copied share there.

Outputs per job: `sources/manifest.json` (each source's absolute path, type, status, cache key, warnings, rights flag), `sources/units.json`,
`scripts/script.json|md`, plus the normal video, subtitles, thumbnail, metadata and `reports/summary.json` (`source_commentary` section).
Extraction results are cached in `projects/cache/sources/` (keyed by file fingerprint, language, OCR/engine), so retries, `--force` re-runs and new
jobs on the same files do not redo OCR, transcription or scene detection. Your files are only read, never modified.

**Rights.** The tool does **not** verify that you may use or publish your source material. Frames/pages from your sources are used as visuals and are
marked "rights not verified" (QA warning `source_rights_not_verified`); the description gets a disclosure line. Whether commentary on manga/anime/documents is
permitted (licence, fair use/fair dealing, platform rules) is your responsibility. Review before publishing; nothing is uploaded.

Limits (see also below): OCR of stylised manga lettering is often poor (flagged low-confidence); tall webtoon strips are shown whole (not panel by
panel); no panel/character/visual understanding (scenes are detected by frame differences only); templates exist for English/Hinglish wording, other
languages need an LLM; scanned-PDF OCR is capped at 150 pages per file. Tested with synthetic inputs only, not on real manga/anime or on Android.

---

## Windows 10 setup (4 GB RAM PC)

Needs about 1.5 GB free disk for tools plus space for your videos. Tested on Linux only; the Windows-specific code was tested with
mocks, see [Verification status](#verification-status) before relying on it.

### 1. Install Python 3.10 or newer (once)
Download from <https://www.python.org/downloads/windows/>. In the installer **tick "Add python.exe to PATH"**. Then open
*Command Prompt* and check:
```bat
py -3 --version
```

### 2. Unzip the project
Unzip to a short path without OneDrive/Desktop sync, for example `C:\yta`. Then:
```bat
cd C:\yta\YOUTUBE_AUTOMATION_AGENT
```

### 3. Run the installer (asks before every download)
```bat
setup_windows.bat
```
This is the same as `py -3 setup.py`. It will:
1. check Python, and offer `pip install pillow` (needed for thumbnails and title cards);
2. offer to download **FFmpeg** (80-200 MB) into `tools\bin`;
3. offer to download **whisper.cpp** (Windows CPU build) into `tools\whisper`;
4. offer to download a **Whisper speech model** into `models\` -- on a 4 GB PC it picks **`base`** (142 MB, ~0.5 GB RAM);
5. write the paths into `config\settings.json` (your old file is saved as `settings.json.bak`);
6. run `agent.py doctor` as a final check.

Options:
```bat
py -3 setup.py --check            :: only report what is installed or missing; changes nothing, downloads nothing
py -3 setup.py --yes              :: accept the recommended choices without asking
py -3 setup.py --model small      :: better Hindi/Kannada/Telugu accuracy, needs ~1 GB free RAM (close other programs)
py -3 setup.py --edge-tts         :: also install online neural voices (needs internet while narrating)
py -3 setup.py --opencv           :: also install OpenCV (face-aware reframing, ~50 MB)
```
Where the download source publishes a SHA-256, the installer checks it and refuses a mismatching file. Where none is published it
prints `unverified`. If any download fails it prints the exact manual step (see Troubleshooting).

### 4. Check the machine
```bat
yta.bat doctor
```
`yta.bat` is a short launcher for `py -3 agent.py`. `doctor` lists RAM, free disk, found tools, the recommended model, and anything missing.

### 5. First runs
```bat
:: Mode B: Shorts from a long video. Stops for your approval before the final render.
yta.bat shorts create "D:\videos\talk.mp4" --count 5 --language en
yta.bat shorts list JOB_ID                       :: see the chosen clips (ids, times, scores, warnings)
yta.bat shorts preview JOB_ID                    :: low-resolution previews in outputs\JOB_ID\previews
yta.bat shorts edit JOB_ID CLIP_ID --start 62 --end 98
yta.bat shorts approve JOB_ID all
yta.bat shorts render JOB_ID                     :: add --quality draft when creating the job on slow PCs

:: no speech model yet? use an existing transcript (.json/.srt/.vtt) instead
yta.bat shorts create "D:\videos\talk.mp4" --transcript "D:\videos\talk.srt"

:: Mode A: topic to video
yta.bat video make "How habits form" --duration 120 --language en
yta.bat video make "How habits form" --tts edge_online          :: online neural voice (after setup.py --edge-tts)

yta.bat jobs                 :: all jobs and their status
yta.bat status JOB_ID        :: stages, outputs
yta.bat resume JOB_ID        :: continue an interrupted or failed job from its last good stage
```
Results are in `outputs\JOB_ID\` (`shorts\`, `final_video\`, `thumbnails\`, `metadata\`, `subtitles\`, `reports\summary.json`).
Mode A research: by default Wikipedia (needs internet) plus any notes you list in `config\settings.json` under
`topic_to_video.research.manual.paths`.

### 4 GB RAM guidance
- The low-memory profile switches on automatically when the PC reports 4.5 GB or less: FFmpeg uses 2 threads, speech recognition runs on
  5-minute chunks with 2 threads. Nothing loads a whole video into memory.
- Windows itself uses about 2 GB. Close the browser and other programs before transcribing or rendering.
- Use the **`base`** model (default). `small` may work with everything else closed; `medium` will not.
- If renders are too slow, create jobs with `--quality draft` and review with `shorts preview` first.
- Real speed on a 4 GB PC has **not been measured**; expect full 1080x1920 renders to be slow.

### Voices on Windows (Mode A narration)
| Language | Default offline voice (`--tts auto` picks it) | Notes |
|---|---|---|
| English | Windows built-in voices (SAPI: e.g. David, Zira) | clearer than eSpeak but still basic synthetic speech, not natural, not voice cloning |
| Hindi | only if the Hindi speech pack is installed | Settings > Time & Language > Language > Hindi > Options > install **Speech** |
| Hinglish | an English voice reads the romanised text | pronunciation of Hindi words will be imperfect |
| Kannada, Telugu | usually no offline Windows voice | use `--tts edge_online` (internet) or supply your own TTS command (`config\providers.json` -> `command`) |

If no voice exists for the language the job stops with a message saying so; it never reads text with a wrong-language voice silently.

### Troubleshooting
| Symptom | Fix |
|---|---|
| `'py' is not recognized` | Reinstall Python and tick **Add python.exe to PATH**, or use `python` instead of `py -3`. |
| `required tool not found: ffmpeg` | Run `setup_windows.bat`. Manual: download an *essentials* build from <https://www.gyan.dev/ffmpeg/builds/>, copy `ffmpeg.exe` and `ffprobe.exe` into `tools\bin`. |
| whisper download failed | Manual: from <https://github.com/ggml-org/whisper.cpp/releases> download `whisper-bin-x64.zip`, copy its `.exe` and `.dll` files into `tools\whisper`. |
| model download failed | Manual: download `https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin`, save as `models\ggml-base.bin`, re-run `py -3 setup.py`. |
| `whisper-cli.exe` does not start / missing DLL | Install *Microsoft Visual C++ Redistributable 2015-2022 (x64)* from Microsoft, then re-run setup. |
| antivirus or SmartScreen flags downloaded `.exe` | The files are the official FFmpeg / whisper.cpp builds; verify their source yourself and allow them, or install the tools another way and make sure they are on PATH. |
| `no speech-recognition engine found` | Finish step 3, or use `--transcript FILE`. |
| `no Windows voice installed for language 'hi'` | Install the language's Speech pack (table above) or use `--tts edge_online`. |
| captions show boxes for Hindi/Kannada/Telugu | Windows font *Nirmala UI* must exist in `C:\Windows\Fonts`; the job report warns when it cannot be found. |
| `Need ~N MB free` / insufficient storage | Free disk space or point `paths.outputs` in `config\settings.json` at a bigger drive. The job stops before copying or rendering. |
| out of memory / PC freezes | Close other programs, use the `base` or `tiny` model, `--quality draft`. |
| job shows `interrupted` or `failed` | Fix the cause, then `yta.bat resume JOB_ID`; finished stages are not repeated. |
| Hindi text prints as `?` in the console | The agent switches the console to UTF-8; if it still happens, run `chcp 65001` first. |
| antivirus locks files in `outputs` | Exclude the project folder or retry; the agent never overwrites finals, it writes `_v2`, `_v3`. |

---

## Relevant visuals and natural editing (Mode A)

**Scene-specific visuals.** Each script section gets its own concrete visual phrase built from *that section's narration*
(not the overall topic): e.g. "student studying at desk at night", "phone distractions while working", "morning running outdoors".
It works for generated and `--script-file` scripts. Rules, in order: optional LLM phrase (accepted only if it shares a word with the
narration) -> small built-in lexicon of filmable phrases (used only if the narration contains a trigger word) -> the section's own
content words -> the topic only for template-only intro/outro. The phrase and its source are stored in `scripts/script.json`
(`visual_hint`, `visual_hint_source`). Phrases are English; Hindi/Kannada/Telugu scripts without English words get generated cards.

**Optional stock footage (Pexels, off by default).**
```bat
set PEXELS_API_KEY=your_key_here
yta.bat video make "How discipline works" --stock pexels --editing natural
```
(Linux/Termux: `export PEXELS_API_KEY=...`. Put the key only in your environment, never in the project or in Git.) For every scene the agent searches Pexels
with the scene phrase, prefers a video clip (photo as fallback), matches orientation (landscape / portrait for Shorts / square),
and downloads into `outputs/JOB/assets/stock/`. Order of sources per scene: your own `assets/` library -> Pexels -> generated cards.
Each asset records provider, query, source URL, creator, licence and licence URL; credits are added to the video description.
Without a key, offline, rejected key, rate limit or no match, the scene silently uses a card and the reason is written to
`outputs/JOB/assets/stock_report.json` and the job summary (`stock_media.diagnostics`); `yta.bat doctor` shows whether a key is set (never the key).
Terms checked on pexels.com (API docs, API page, licence page): requests are limited to 200/hour and 20,000/month by default
(the agent stops on a 429 and caps requests per job); API users are asked to credit creators and link to Pexels; the Pexels License
allows free commercial use and editing without required attribution, but does **not** allow implying endorsement by people/brands shown,
showing identifiable people in a bad light, or selling/redistributing unaltered copies. Pexels also stated that new API-key issuance
is currently paused, so you may be unable to get a key. Review stock footage before publishing: matching is by search text only.
It was tested with a mocked API, **never against the live Pexels service**.

**Natural editing preset.** `--editing natural` (default stays `classic`): slow motion of at most ~6% zoom (push-in, pull-out or gentle drift),
clean cuts instead of a fade on every scene, a short fade in at the start and out at the end, scenes longer than ~10 s are split into
shots of varied length (3-8 s) with different framing or a later part of the same clip, music capped at 8% volume with fade in/out
(no automatic ducking). Shot timing always adds up to the narration section timing; captions, formats and image/video assets work as before.

**Test-only local footage mode.** `--local-footage sequential` uses only video clips from `assets/` (`.mp4 .mov .mkv .webm`, sorted by
filename, cycled across the script sections), with no keyword matching and no generated cards. The usual licence rules apply: restricted
clips are never used and clips without a licence sidecar need `--allow-unknown-assets`. If no eligible clip exists the job stops with a clear
message. The chosen clip and licence status per section are recorded in `assets.json` and the QA report. Combine with `--editing natural`.

## Linux / Termux quick start
Termux: `pkg install python ffmpeg espeak`, then `pip install pillow` (optional `opencv-python`).
```bash
python3 agent.py doctor
python3 agent.py video make "How habits form" --duration 120 --language en
python3 agent.py shorts create talk.mp4 --count 5 --transcript talk.srt   # or configure whisper.cpp
python3 agent.py shorts preview JOB | edit JOB ID --start 62 --end 98 | approve JOB all | render JOB
python3 agent.py jobs | status JOB | resume JOB
```
`python3 setup.py --check` reports missing tools on any platform (automatic downloads are Windows-only).

Outputs: `outputs/JOB_ID/{source,research,scripts,narration,transcripts,subtitles,assets,previews,final_video,shorts,thumbnails,metadata,reports}`.

## Safety guarantees (each has a test)
Originals never modified (processing copy + fingerprint re-check before render); finals never overwritten (`_v2`, `_v3`);
only the job's marked `tmp/` is cleaned; free space checked before copying/rendering; interrupted jobs are detected and resumed
from validated checkpoints; DB migrations back up first and roll back on failure; URL input needs `--i-have-rights`
and only accepts direct video files; voice cloning refuses without a valid consent record (no cloning engine ships);
the installer downloads nothing without your confirmation and verifies published checksums.

## Verification status
**Verified (automated tests, Linux):** both workflows end to end on synthetic media, all safety rules, database migrations,
recovery, QA checks, and the new Windows/low-RAM logic (process check, SAPI provider, font lookup, FFmpeg concat lists, installer helpers)
using mocked Windows APIs. See the test results in the project report (`python -m pytest -q`).

**Verified for real (one source):** the installer's FFmpeg step was run against the BtbN GitHub release: the zip downloaded,
its SHA-256 matched BtbN's published checksum, and it contained genuine x64 `ffmpeg.exe` and `ffprobe.exe`.

**NOT verified:** the gyan.dev FFmpeg URL, the whisper.cpp GitHub release lookup and asset names, and the Hugging Face model URL could
not be reached from the build environment. The installer discovers the whisper.cpp release at run time and verifies checksums where the
source provides one, but those three sources have never been exercised end to end. Nothing has run on a real Windows PC, on
real speech, with a real Windows voice, or on Android/Termux.

## Honest limitations
- **Speech recognition is not bundled.** Mode B needs whisper.cpp (+ a model; size is checked against RAM/disk first),
  faster-whisper, or `--transcript`. It was **tested with supplied transcripts only**, never on real speech audio.
- **Voices:** eSpeak and Windows SAPI are basic synthetic TTS (kn/te voice availability is unverified; Latin-script Hinglish via an
  English or Hindi voice is a guess). Online neural TTS (edge-tts) is optional and untested. Narration was **tested only with a tone
  test double**, never a real voice.
- **Mode A subtitles** are timed per sentence from measured audio and labelled `measured_sentence`/`interpolated` -- never "verified".
  QA always warns about this. Run narration through an ASR engine for word-accurate captions.
- **Script writing without an LLM is extractive**: an organised read of researched facts, not creative prose. Hook/intro/outro
  templates exist for en, hi, hinglish only. An optional LLM may reword but is rejected if it adds numbers/names.
- **Understanding/highlights are heuristic** (cue lexicons for en/hi/hinglish + statistics). Kannada/Telugu get only language-independent signals.
  No visual scene understanding. Scores are explainable, not proven. QA cannot prove a clip is not misleading: review before publishing.
- **Reframing:** blur-fill (default), centre crop, or ONE static face-centred crop per clip (OpenCV Haar). No per-frame tracking.
- **Assets:** your own library (`assets/`, licence sidecars `file.ext.license.json`), optional Pexels API footage (opt-in; mocked-API tests only), or generated cards. No scraping or other stock sites.
- **Performance on weak hardware is unmeasured.** Full-resolution renders are slow on weak CPUs; use `--quality draft` and previews.
- Not implemented: YouTube API publishing/scheduling, multi-channel, voice-clone backend, per-frame tracking.

## Tests
```bash
python3 -m pytest -q -p no:cacheprovider        # about 5 minutes; most time is real FFmpeg rendering
python3 -m pytest -q tests/test_windows.py      # Windows / low-RAM / installer tests only (seconds)
```
Tests that need Pillow report as *skipped* (with the reason) on an interpreter that lacks it.
Supported Python: 3.10+. Last results (Linux build environment): Python 3.13 with Pillow, **103 passed**; Python 3.11, **97 passed,
6 skipped** (the 6 need Pillow, which could not be installed there because the package index was unreachable). Python 3.10 and 3.12
were not run in full (3.12: core/windows/shorts/topic = 97 passed, 6 skipped). `pip` could not be tested in the build environment.
