"""Source-grounded commentary scripts (YAA V3.1), produced in the same script format the topic workflow already uses.

Every claim sentence carries the fact id of the source unit it comes from, so the existing validation, metadata and QA stages
work unchanged. Two ways to write the commentary:
  * with an LLM provider (llm.provider in config): each section is reworded as original commentary and ACCEPTED only if it adds no
    numbers or proper names absent from the source, contains no long verbatim run, and (theory mode) is phrased as possibility;
  * without one: a deterministic template that states what each part of the source mentions (key terms) plus, at most, one short
    quote. This is grounded but plain, NOT creative analysis. Review and theory modes need an LLM because opinions / theories
    cannot be produced from templates without inventing them.
Dialogue-style sources (video, manga pages, subtitles) are never read out: quotes are capped (default 10 words per unit)."""
from __future__ import annotations

import re

from modules.source_commentary.sources import FICTION_TYPES, MODES
from providers.llm import LLMUnavailable
from scripts import visual_hints

TEMPLATE_LANGS = ("en", "hinglish")            # English wording; other languages need an LLM or --script-file
QUOTE_WORDS_FICTION, QUOTE_WORDS_DOC = 10, 40
NEEDS_LLM = {"review": "opinions about the material", "theory": "interpretations"}

HOOK = {"recap": "Here is a recap of {t}.", "explanation": "Let's break down {t}.", "summary": "{t}, in a quick summary.",
        "lesson": "In this lesson we will go through {t}.", "review": "A closer look at {t}.",
        "theory": "Let's explore some ideas about {t}."}
INTRO = {"recap": "This recap follows the material in the order it appears.",
         "explanation": "We will go through it step by step, in the order it is presented.",
         "summary": "These are the main points, in order.", "lesson": "Each key idea below comes straight from the material.",
         "review": "We will look at what the material actually contains.",
         "theory": "Everything here is interpretation, so treat it as possibility rather than fact."}
OUTRO = {"recap": "That is the recap of {t}.", "explanation": "That covers the main parts of {t}.", "summary": "That was {t} in brief.",
         "lesson": "That is the end of the lesson on {t}.", "review": "That is a closer look at {t}.",
         "theory": "These are possibilities, not conclusions."}
TRANSITIONS = {"recap": ["Next.", "After that.", "Later on.", "Moving on."], "explanation": ["Now the next part.", "Let's continue."],
               "lesson": None, "summary": [], "review": ["Now another part of it."], "theory": ["Another thing to consider."]}
LLM_RULES = {
    "recap": "Recap what happens or is said, in order, in your own words.",
    "explanation": "Explain what this part says and why it matters to the topic, in your own words.",
    "summary": "Summarise this part in one or two short sentences.",
    "lesson": "Teach the key idea of this part simply, as a lesson.",
    "review": "Comment on what this part contains and how it is presented; phrase opinions as 'seems' or 'appears'.",
    "theory": "Offer one possible interpretation; phrase it as a possibility using words like might, could or perhaps."}
HEDGE = re.compile(r"\b(might|could|may|perhaps|possibly|seems?|appears?|suggests?|one reading|one possibility|maybe)\b", re.I)
WORD = re.compile(r"[\w']+", re.U)
STOP = set("""a an the and or but if then than that this these those there here is are was were be been being am do does did have has had
having i you he she it we they me him her us them my your his its our their of in on at to for from by with about as into over after
before again once so just very can will would should could not no yes all any each some such only own same too up down out off more most
other what which who whom when where why how also still even ever never one two been get got go going say said says like""".split())


class CommentaryError(Exception):
    """The commentary cannot be produced honestly; message says what to change."""


def words(text: str) -> list[str]:
    return [w.lower() for w in WORD.findall(text)]


def ngram_overlap(text: str, source: str, n: int = 6) -> float:
    """Share of `text` words that sit inside a run of >= n consecutive words copied from `source`."""
    t, s = words(text), words(source)
    if len(t) < n or len(s) < n:
        return 0.0
    grams = {tuple(s[i:i + n]) for i in range(len(s) - n + 1)}
    covered = [False] * len(t)
    for i in range(len(t) - n + 1):
        if tuple(t[i:i + n]) in grams:
            for j in range(i, i + n):
                covered[j] = True
    return sum(covered) / len(t)


def key_terms(text: str, n: int = 3) -> list[str]:
    freq: dict[str, int] = {}
    first: dict[str, int] = {}
    for i, w in enumerate(re.findall(r"[^\W\d_]{4,}", text.lower())):
        if w in STOP or w.endswith("ly"):
            continue
        freq[w] = freq.get(w, 0) + 1
        first.setdefault(w, i)
    top = sorted(freq, key=lambda w: (-freq[w], first[w]))[:n]
    return sorted(top, key=lambda w: first[w])


def _join(terms: list[str]) -> str:
    return terms[0] if len(terms) == 1 else ", ".join(terms[:-1]) + " and " + terms[-1]


def mmss(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 60:02d}:{sec % 60:02d}"


def where(u: dict) -> str:
    r = u.get("ref", {})
    if "page" in r:
        return f"On page {r['page']}"
    if "slide" in r:
        return f"On slide {r['slide']}"
    if "start" in r:
        return f"Around {mmss(r['start'])}"
    return f"In part {r.get('para', u.get('order', ''))}"


def range_label(us: list[dict]) -> str:
    a, b = us[0].get("ref", {}), us[-1].get("ref", {})
    for key, name in (("page", "Page"), ("slide", "Slide")):
        if key in a:
            return f"{name} {a[key]}" if a[key] == b.get(key) else f"{name}s {a[key]}-{b.get(key, a[key])}"
    if "start" in a:
        return f"{mmss(a['start'])}-{mmss(b.get('end', a['start']))}"
    return f"Part {us[0].get('order', '')}"


def first_words(text: str, limit: int) -> str:
    w = text.split()
    return " ".join(w[:limit]).strip(" ,;:-") if len(w) > limit else text.strip()


def is_fiction(u: dict) -> bool:
    return u.get("source_type") in FICTION_TYPES and u.get("kind") != "ocr_doc"


def template_sentences(u: dict, quote_words: int | None) -> list[dict]:
    text = u["text"]
    hedged = u.get("confidence_label", "supported") != "supported"
    base = {"fact_ids": [u["fact_id"]], "kind": "claim", "hedged": hedged, "unit": u["id"]}
    out: list[dict] = []
    if is_fiction(u):
        q = QUOTE_WORDS_FICTION if quote_words is None else quote_words
        terms = key_terms(text)
        what = "text on the page" if u.get("source_type") == "image" else "dialogue"
        if terms:
            if u["confidence"] == "low":
                out.append({**base, "text": f"{where(u)}, the text is hard to read, but it seems to mention {_join(terms)}."})
            else:
                out.append({**base, "text": f"{where(u)}, the {what} mentions {_join(terms)}."})
        if q > 0 and len(text.split()) >= 4 and u["confidence"] != "low":
            out.append({**base, "text": f"One line reads: \"{first_words(text, q)}\"."})
        return out
    q = QUOTE_WORDS_DOC if quote_words is None else max(quote_words, 12)
    sents = re.split(r"(?<=[.!?।])\s+", text)
    cur = ""
    for s in sents:
        if len((cur + " " + s).split()) > q and cur:
            break
        cur = f"{cur} {s}".strip()
    return [{**base, "text": first_words(cur or text, q + 15)}]


# ---- LLM path ----------------------------------------------------------------------------------------------------
def _nums(t: str) -> set[str]:
    return set(re.findall(r"\d[\d,\.]*", t))


def _caps(t: str) -> set[str]:
    return {w for w in re.findall(r"\b[A-Z][a-z]{2,}\b", t)}


def _grounded_share(sentence: str, source: str) -> float:
    """Share of the sentence's content words (stems of 5 letters) that also occur in the source section."""
    src = {w[:5] for w in re.findall(r"[^\W\d_]{4,}", source.lower())}
    cw = [w[:5] for w in re.findall(r"[^\W\d_]{4,}", sentence.lower()) if w not in STOP]
    return sum(1 for w in cw if w in src) / len(cw) if cw else 0.0


def validate_llm_text(out: str, source: str, topic: str, mode: str) -> list[str]:
    """Sentences of `out` that are acceptable as grounded commentary (others are dropped)."""
    ok_caps = _caps(source) | _caps(topic) | {"The", "This", "That", "These", "Those", "It", "Here", "There", "Then", "Next", "One", "Another",
                                              "What", "But", "And", "So", "Perhaps", "Maybe", "Some", "Each", "After", "Later", "Finally"}
    good = []
    for s in re.split(r"(?<=[.!?])\s+", out.strip().replace("\n", " ")):
        n = len(s.split())
        if not (4 <= n <= 60) or not _nums(s) <= _nums(source) or not _caps(s) <= ok_caps:
            continue
        if ngram_overlap(s, source, 8) > 0 or _grounded_share(s, source) < 0.4:
            continue
        if mode == "theory" and not HEDGE.search(s):
            continue
        good.append(s.strip())
    return good[:4]


def _llm_section(llm, mode: str, topic: str, source: str) -> list[str]:
    prompt = (f"You write spoken commentary for a video about '{topic}'. {LLM_RULES[mode]}\nRules: use ONLY information in SOURCE; do not add "
              "names, numbers or events that are not in SOURCE; never copy more than 7 words in a row from SOURCE; 2 to 4 short sentences; "
              f"plain spoken English.\nSOURCE:\n{source[:1400]}\nCOMMENTARY:")
    return validate_llm_text(llm.complete(prompt, max_tokens=220), source, topic, mode)


# ---- main --------------------------------------------------------------------------------------------------------
def generate_commentary_script(topic: str, units: list[dict], mode: str, language: str, duration_s: int, wpm_table: dict,
                               llm=None, quote_words: int | None = None) -> dict:
    if mode not in MODES:
        raise CommentaryError(f"unknown content mode {mode!r}; options: {', '.join(MODES)}")
    if mode in NEEDS_LLM and llm is None:
        raise CommentaryError(f"content mode '{mode}' needs an LLM (set llm.provider in config/providers.json) because {NEEDS_LLM[mode]} "
                              "cannot be produced from templates without inventing them. Use recap, explanation, lesson or summary "
                              "without an LLM.")
    if language not in TEMPLATE_LANGS and llm is None:
        raise CommentaryError(f"commentary templates exist for {', '.join(TEMPLATE_LANGS)} only; for '{language}' configure an LLM or "
                              "write the script yourself (--script-file)")
    usable = [u for u in units if u["text"] and u.get("fact_id")]
    if not usable:
        raise CommentaryError("the sources contain no readable text to base commentary on")
    warnings: list[str] = []
    wpm = wpm_table.get(language, 150)
    budget = int(duration_s * wpm / 60)
    est = 28 if is_fiction(usable[0]) else 38
    fixed = 36
    n_fit = max(3, (budget - fixed) // est)
    if mode == "summary":
        n_fit = min(n_fit, 8)
    chosen = usable
    if len(usable) > n_fit:
        idx = sorted({round(i * (len(usable) - 1) / max(n_fit - 1, 1)) for i in range(n_fit)})
        chosen = [usable[i] for i in idx]
        warnings.append(f"condensed: {len(chosen)} of {len(usable)} source parts are covered to fit about {duration_s}s; "
                        "raise --duration to cover more")
    elif len(usable) * est + fixed < budget * 0.5:
        warnings.append("the source has less material than the requested duration; the video will be shorter (nothing is padded)")
    unreadable = [u for u in units if not u["text"] and u["confidence"] == "unreadable"]
    if unreadable:
        warnings.append(f"{len(unreadable)} source part(s) could not be read (" +
                        ", ".join(sorted({f for u in unreadable for f in u['flags']})) + "); they are not described in the narration")
    low = [u for u in chosen if u["confidence"] == "low"]
    if low:
        warnings.append(f"{len(low)} part(s) have low-confidence text (OCR/transcript) and are described with hedged wording")
    group = 4 if mode == "summary" else 3
    t = topic.strip().rstrip(".?!")
    sections = [{"id": "s0", "title": "Hook", "kind": "hook", "visual_hint": "", "unit_ids": [chosen[0]["id"]],
                 "sentences": [{"text": HOOK[mode].format(t=t), "fact_ids": [], "kind": "structure", "hedged": False}]},
                {"id": "s1", "title": "Introduction", "kind": "intro", "visual_hint": "", "unit_ids": [],
                 "sentences": [{"text": INTRO[mode], "fact_ids": [], "kind": "structure", "hedged": False}]}]
    accepted = fallbacks = dropped = 0
    for n, i in enumerate(range(0, len(chosen), group), 1):
        grp = chosen[i:i + group]
        sents: list[dict] = []
        source_text = " ".join(u["text"] for u in grp)
        if llm is not None:
            try:
                lines = _llm_section(llm, mode, t, source_text)
            except LLMUnavailable:
                lines = []
                warnings.append("LLM unavailable; used the plain template where possible")
                llm = None
            if lines:
                accepted += 1
                sents = [{"text": s, "fact_ids": [u["fact_id"] for u in grp], "kind": "claim",
                          "hedged": any(u.get("confidence_label") != "supported" for u in grp), "unit": grp[0]["id"]} for s in lines]
            elif mode not in NEEDS_LLM:
                fallbacks += 1
        if not sents and mode in NEEDS_LLM:          # review/theory are never templated (would invent opinions)
            dropped += 1
            continue
        if not sents:
            tr = TRANSITIONS[mode]
            if n > 1 and mode == "lesson":
                sents.append({"text": f"Key idea {n}.", "fact_ids": [], "kind": "structure", "hedged": False})
            elif n > 1 and tr:
                sents.append({"text": tr[(n - 2) % len(tr)], "fact_ids": [], "kind": "structure", "hedged": False})
            for u in grp:
                sents += template_sentences(u, quote_words)
        sections.append({"id": f"s{len(sections)}", "title": range_label(grp), "kind": "body", "visual_hint": "",
                         "unit_ids": [u["id"] for u in grp], "sentences": sents})
    if not any(s["kind"] == "body" for s in sections):
        raise CommentaryError("the LLM output was rejected for every section (it added unsupported details or copied the source); "
                              "no commentary was produced. Try another model or a different mode.")
    if dropped:
        warnings.append(f"{dropped} section(s) skipped because the LLM text added unsupported details or copied the source")
    sections.append({"id": f"s{len(sections)}", "title": "Conclusion", "kind": "conclusion", "visual_hint": "", "unit_ids": [],
                     "sentences": [{"text": OUTRO[mode].format(t=t), "fact_ids": [], "kind": "structure", "hedged": False}]})
    method = "source_template" if llm is None and not accepted else f"source_llm_validated({accepted} sections, {fallbacks} template fallbacks)"
    if llm is None and not accepted:
        warnings.append("no LLM was used: this commentary is a plain, grounded outline (key terms and short quotes), not creative analysis. "
                        "Configure llm.provider for real commentary")
    script = {"topic": topic, "language": language, "style": f"commentary:{mode}", "sections": sections, "warnings": warnings,
              "method": method, "target_words": budget}
    script["words"] = sum(len(s["text"].split()) for sec in sections for s in sec["sentences"])
    visual_hints.apply(script)
    src_text = " ".join(u["text"] for u in chosen)
    claim_text = " ".join(s["text"] for sec in sections for s in sec["sentences"] if s["kind"] == "claim")
    script["commentary"] = {"mode": mode, "units_total": len(units), "units_readable": len(usable), "units_used": len(chosen),
                            "unreadable_units": [u["id"] for u in unreadable], "low_confidence_units": [u["id"] for u in low],
                            "verbatim_ratio": round(ngram_overlap(claim_text, src_text, 6), 3),
                            "quote_words": QUOTE_WORDS_FICTION if quote_words is None else quote_words}
    return script


# ---- review / edit -----------------------------------------------------------------------------------------------
def script_markdown(script: dict) -> str:
    return "\n\n".join(f"## {s['title']}\n" + " ".join(x["text"] for x in s["sentences"]) for s in script["sections"])


def apply_edit(script: dict, edited_md: str) -> tuple[dict, dict]:
    """Merge a user-edited script.md (same '## title' sections, same order). Unchanged sentences keep their source grounding;
    changed or new sentences become kind 'user_edit' with no fact ids (not re-verified). Returns (script, stats)."""
    blocks = re.split(r"(?m)^##\s+", edited_md.strip())
    blocks = [b for b in blocks if b.strip()]
    if len(blocks) != len(script["sections"]):
        raise CommentaryError(f"the edited script has {len(blocks)} sections but the original has {len(script['sections'])}; keep every "
                              "'## title' heading (edit the text under them, do not add or remove sections)")
    kept = changed = 0
    for sec, block in zip(script["sections"], blocks):
        title, _, body = block.partition("\n")
        old = {}                                     # each original sentence AND its sub-sentences map to the grounded original
        for x in sec["sentences"]:
            old[x["text"].strip()] = x
            for part in re.split(r"(?<=[.!?।])\s+", x["text"].strip()):
                old.setdefault(part.strip(), x)
        new = []
        for s in [x.strip() for x in re.split(r"(?<=[.!?।])\s+", body.strip()) if x.strip()]:
            if s in old:
                new.append({**old[s], "text": s})
                kept += 1
            else:
                new.append({"text": s, "fact_ids": [], "kind": "user_edit", "hedged": False})
                changed += 1
        if not new:
            raise CommentaryError(f"section '{sec['title']}' is empty after editing; delete nothing, rewrite it instead")
        sec["sentences"] = new
        sec["title"] = title.strip() or sec["title"]
    script["words"] = sum(len(s["text"].split()) for sec in script["sections"] for s in sec["sentences"])
    if changed:
        script.setdefault("warnings", []).append(f"{changed} sentence(s) were edited or added by the user; they are not traced to the source")
        script["edited_by_user"] = True
    return script, {"kept": kept, "changed": changed}
