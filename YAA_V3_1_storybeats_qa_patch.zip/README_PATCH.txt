Overlay for a folder that already has the manga patch (YAA_V3_1_manga_vision_patch.zip) applied.
unzip -o YAA_V3_1_storybeats_qa_patch.zip -d p && cp -r p/YOUTUBE_AUTOMATION_AGENT/. YOUTUBE_AUTOMATION_AGENT/
Then: python agent.py qa-video --help && python -m pytest -q tests/test_story_qa.py
The full ZIP YOUTUBE_AUTOMATION_AGENT_V3_1_FULL.zip already contains everything.
