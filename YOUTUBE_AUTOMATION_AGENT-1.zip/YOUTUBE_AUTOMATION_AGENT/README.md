# YouTube Automation Agent

Two independent workflows sharing one core (SQLite jobs, checkpoints, safe file handling):

- **Mode A**: `topic -> research -> script -> narration -> subtitles -> assets -> render -> thumbnail -> metadata -> QA`
- **Mode B**: `long video -> transcript -> highlights -> review/approve -> vertical Shorts + captions + metadata -> QA`

Nothing is uploaded or published. You upload.

## Quick start (Termux: `pkg install python ffmpeg espeak`; `pip install pillow`; optional `opencv-python`)

```bash
python3 agent.py doctor                                   # what works on this device, and what is missing

# Mode A
python3 agent.py video make "How habits form" --duration 120 --language en
#   research sources: config/settings.json -> topic_to_video.research (wikipedia needs internet; manual reads your notes)

# Mode B (stops for your approval before final render)
python3 agent.py shorts create talk.mp4 --count 5 --transcript talk.srt   # or configure whisper.cpp
python3 agent.py shorts preview JOB      # low-res previews
python3 agent.py shorts edit JOB ID --start 62 --end 98
python3 agent.py shorts approve JOB all
python3 agent.py shorts render JOB
python3 agent.py jobs | status JOB | resume JOB
```

Outputs: `outputs/JOB_ID/{source,research,scripts,narration,transcripts,subtitles,assets,previews,final_video,shorts,thumbnails,metadata,reports}`.

## Safety guarantees (each has a test)
Originals never modified (processing copy + fingerprint re-check before render); finals never overwritten (`_v2`, `_v3`);
only the job's marked `tmp/` is cleaned; free space checked before copying/rendering; interrupted jobs are detected and resumed
from validated checkpoints; DB migrations back up first and roll back on failure; URL input needs `--i-have-rights`
and only accepts direct video files; voice cloning refuses without a valid consent record (no cloning engine ships).

## Honest limitations
- **Speech recognition is not bundled.** Mode B needs whisper.cpp (+ a model you download; size is checked against RAM/disk first),
  faster-whisper, or `--transcript`. It was **tested with supplied transcripts only**, never on real speech audio.
- **Voices:** eSpeak is basic robotic TTS (kn/te voice quality is unverified; Latin-script Hinglish via the Hindi voice is a guess).
  Online neural TTS (edge-tts) is optional and untested here. This was **not tested with a real TTS**; a tone test double was used.
- **Mode A subtitles** are timed per sentence from measured audio and labelled `measured_sentence`/`interpolated` -- never "verified".
  QA always warns about this. Run narration through an ASR engine for word-accurate captions.
- **Script writing without an LLM is extractive**: an organised read of researched facts, not creative prose. Hook/intro/outro
  templates exist for en, hi, hinglish only. An optional LLM may reword but is rejected if it adds numbers/names.
- **Understanding/highlights are heuristic** (cue lexicons for en/hi/hinglish + statistics). Kannada/Telugu get only language-independent signals.
  No visual scene understanding. Scores are explainable, not proven. QA cannot prove a clip is not misleading: review before publishing.
- **Reframing:** blur-fill (default), centre crop, or ONE static face-centred crop per clip (OpenCV Haar). No per-frame tracking.
- **Assets:** your own library (`assets/`, licence sidecars `file.ext.license.json`) or generated cards. No stock-site download.
- **Not tested on Android/Termux or Windows.** Developed and tested on Linux. Full-resolution renders are slow on weak CPUs;
  use `--quality draft` and previews.
- Not implemented: YouTube API publishing/scheduling, multi-channel, voice-clone backend, per-frame tracking.

## Tests
`python3 -m pytest -q` (about 4.5 minutes here; most time is real FFmpeg rendering).
