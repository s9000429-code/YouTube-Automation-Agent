"""Lightweight video QA from FFmpeg alone (no numpy/Pillow, so it runs on Termux and old Windows PCs).

Inspired by the frame-by-frame short_qa idea, reduced to what FFmpeg can measure cheaply on a 160-px-wide copy of the video:
loudness and true peak, long silences, frozen spans, unexpected hard cuts, and brightness. Everything here is advisory
(level "warn"): a measurement can flag a problem, it cannot prove a video is good. Every probe has a timeout and failures
become a note instead of an exception."""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

PROBE_TIMEOUT = 240
LUFS_RANGE = (-23.0, -10.0)          # YouTube normalises near -14 LUFS; this only flags clearly off-range audio
TRUE_PEAK_MAX = -1.0                 # dBTP
LONG_SILENCE_S = 3.0
FREEZE_S = 4.0
CUT_SCENE = 0.5
DARK_Y, BRIGHT_Y = 25.0, 235.0       # mean luma (0-255) outside this range is very dark / blown out
NEAR_BLACK_Y = 20.0                   # video-range black is luma 16


def _ff(args: list[str]) -> str:
    """Run ffmpeg, return stderr (all the filters here report through the log). '' on timeout / missing ffmpeg."""
    try:
        cp = subprocess.run(["ffmpeg", "-hide_banner", "-nostdin", "-nostats", *args], capture_output=True, text=True,
                            encoding="utf-8", errors="replace", timeout=PROBE_TIMEOUT)
        return (cp.stderr or "") + "\n" + (cp.stdout or "")
    except (subprocess.TimeoutExpired, OSError):
        return ""


def loudness(video: Path) -> dict | None:
    e = _ff(["-i", str(video), "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"])
    tail = e[e.rfind("Summary:"):] if "Summary:" in e else ""
    i = re.search(r"I:\s+(-?[\d.]+)\s+LUFS", tail)
    p = re.search(r"Peak:\s+(-?[\d.]+)\s+dBFS", tail)
    if not i:
        return None
    return {"integrated_lufs": float(i.group(1)), "true_peak_dbtp": float(p.group(1)) if p else None}


def long_silences(video: Path, min_s: float = LONG_SILENCE_S, noise_db: float = -45.0) -> list[tuple[float, float]]:
    e = _ff(["-i", str(video), "-vn", "-af", f"silencedetect=n={noise_db}dB:d={min_s}", "-f", "null", "-"])
    starts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", e)]
    ends = [(float(a), float(b)) for a, b in re.findall(r"silence_end: (-?[\d.]+) \| silence_duration: ([\d.]+)", e)]
    out = [(max(0.0, s), d) for s, (_, d) in zip(starts, ends)]
    if len(starts) > len(ends):                      # silence runs to the end of the file
        out.append((max(0.0, starts[-1]), -1.0))
    return out


def frozen_spans(video: Path, min_s: float = FREEZE_S) -> list[tuple[float, float]]:
    e = _ff(["-i", str(video), "-an", "-vf", f"scale=160:-2,freezedetect=n=0.003:d={min_s}", "-f", "null", "-"])
    st = [float(x) for x in re.findall(r"freeze_start: ([\d.]+)", e)]
    du = [float(x) for x in re.findall(r"freeze_duration: ([\d.]+)", e)]
    return [(s, d) for s, d in zip(st, du)] + [(s, -1.0) for s in st[len(du):]]


def hard_cuts(video: Path, threshold: float = CUT_SCENE) -> list[float]:
    e = _ff(["-i", str(video), "-an", "-vf", f"scale=160:-2,select='gt(scene,{threshold})',showinfo", "-f", "null", "-"])
    return [float(x) for x in re.findall(r"pts_time:([\d.]+)", e)]


def brightness(video: Path) -> dict | None:
    """Mean luma (0-255) sampled twice a second."""
    e = _ff(["-i", str(video), "-an", "-vf", "fps=2,scale=160:-2,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=-", "-f", "null", "-"])
    ys = [float(x) for x in re.findall(r"lavfi\.signalstats\.YAVG=([\d.]+)", e)]
    if not ys:
        return None
    return {"mean_y": sum(ys) / len(ys), "min_y": min(ys), "max_y": max(ys), "near_black_share": sum(1 for y in ys if y < NEAR_BLACK_Y) / len(ys),
            "samples": len(ys)}


def analyze(video: str | Path) -> dict:
    v = Path(video)
    r: dict = {"video": str(v), "notes": []}
    for key, fn in (("loudness", loudness), ("silences", long_silences), ("frozen", frozen_spans), ("cuts", hard_cuts), ("brightness", brightness)):
        try:
            r[key] = fn(v)
        except Exception as e:                                    # a failed probe must never break QA
            r[key] = None
            r["notes"].append(f"{key} probe failed ({type(e).__name__})")
    return r


def _fmt_spans(spans) -> str:
    return ", ".join(f"{s:.1f}s+{'end' if d < 0 else f'{d:.1f}s'}" for s, d in spans[:5])


def checks(rep: dict, planned_cuts: int | None = None, has_audio: bool = True, placeholder_audio: bool = False) -> list[dict]:
    """Advisory checks (level 'warn') from analyze(). planned_cuts = how many hard cuts the edit is expected to have."""
    out: list[dict] = []

    def add(name, ok, detail=""):
        out.append({"check": name, "ok": bool(ok), "detail": str(detail), "level": "warn"})

    if has_audio and not placeholder_audio:
        lo = rep.get("loudness")
        if lo:
            add("qa_loudness_in_range", LUFS_RANGE[0] <= lo["integrated_lufs"] <= LUFS_RANGE[1],
                f"{lo['integrated_lufs']:.1f} LUFS (expected {LUFS_RANGE[0]:.0f} to {LUFS_RANGE[1]:.0f}; YouTube targets about -14)")
            if lo["true_peak_dbtp"] is not None:
                add("qa_true_peak_ok", lo["true_peak_dbtp"] <= TRUE_PEAK_MAX, f"{lo['true_peak_dbtp']:.1f} dBTP (limit {TRUE_PEAK_MAX})")
        sil = rep.get("silences")
        if sil is not None:
            add("qa_no_long_silence", not sil, f"silent for {LONG_SILENCE_S:.0f}s or more at: {_fmt_spans(sil)}" if sil else "")
    fr = rep.get("frozen")
    if fr is not None:
        add("qa_no_frozen_video", not fr, f"picture frozen {FREEZE_S:.0f}s or more at: {_fmt_spans(fr)}" if fr else "")
    cuts = rep.get("cuts")
    if cuts is not None and planned_cuts is not None:
        allowed = planned_cuts + 2
        add("qa_no_unexpected_cuts", len(cuts) <= allowed,
            f"{len(cuts)} hard cuts detected, edit plans about {planned_cuts}; first at {', '.join(f'{c:.1f}s' for c in cuts[:5])}")
    b = rep.get("brightness")
    if b:
        add("qa_brightness_ok", DARK_Y <= b["mean_y"] <= BRIGHT_Y and b["near_black_share"] < 0.3,
            f"mean luma {b['mean_y']:.0f}/255, near-black {b['near_black_share'] * 100:.0f}% of samples")
    for n in rep.get("notes", []):
        add("qa_probe_note", False, n)
    return out


def format_report(rep: dict, planned_cuts: int | None = None) -> str:
    lines = [f"VIDEO QA  {rep['video']}"]
    for c in checks(rep, planned_cuts):
        lines.append(f"  [{'ok  ' if c['ok'] else 'WARN'}] {c['check']}: {c['detail']}")
    lo, b = rep.get("loudness"), rep.get("brightness")
    if lo:
        lines.append(f"  loudness {lo['integrated_lufs']:.1f} LUFS, true peak {lo['true_peak_dbtp']} dBTP")
    if b:
        lines.append(f"  luma mean {b['mean_y']:.0f} (min {b['min_y']:.0f}, max {b['max_y']:.0f})")
    if rep.get("cuts") is not None:
        lines.append(f"  hard cuts: {len(rep['cuts'])}")
    lines.append("  These are advisory measurements: they flag likely problems, they do not prove the video is good.")
    return "\n".join(lines)
