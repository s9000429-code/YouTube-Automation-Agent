"""V3.1 additions: optional story_beats script style (Mode A) and advisory FFmpeg-only video QA."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from core import videoqa
from scripts import quality_checker
from scripts.script_generator import generate_script, validate_script

needs_ffmpeg = pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg not installed")
F = lambda i, t, c="supported": {"id": i, "text": t, "confidence": c}
FACTS = [F(1, "The bridge opened in 1831 near Broughton."), F(2, "Seventy-four soldiers marched across it in step."),
         F(3, "The bridge collapsed because their steps matched its natural frequency."), F(4, "Nobody died but the bridge never reopened."),
         F(5, "Engineers later banned marching in step on bridges."), F(6, "It was built from iron chains."),
         F(7, "Crowds gathered to watch the repair.")]


def gen(style, facts=FACTS, lang="en"):
    return generate_script("The Broughton bridge", facts, lang, style, 60, {"en": 150, "hinglish": 140, "hi": 130, "kn": 100})


# ---- story_beats -------------------------------------------------------------------------------------------------------
def test_story_beats_structure_and_traceability():
    sc = gen("story_beats")
    assert sc["method"] == "extractive_story_beats" and sc["style"] == "story_beats"
    assert set(sc["beats"]) == {"hook", "setting", "escalation", "question", "explanation", "payoff"}
    secs = sc["sections"]
    assert secs[0]["kind"] == "hook" and secs[-1]["kind"] == "conclusion"
    assert [s["title"] for s in secs][:2] == ["Hook", "Setting"]
    claims = [x for s in secs for x in s["sentences"] if x["kind"] == "claim"]
    assert claims and all(x["fact_ids"] for x in claims)                         # every factual line is still a researched fact
    texts = {f["text"] for f in FACTS}
    assert all(x["text"] in texts for x in claims)                               # nothing invented or reworded
    used = [i for x in claims for i in x["fact_ids"]]
    assert len(used) == len(set(used))                                           # no fact repeated
    expl = next(s for s in secs if s["title"] == "Explanation")
    assert any("because" in x["text"] for x in expl["sentences"])                # the mechanism fact lands in the explanation beat
    assert "?" in next(s for s in secs if s["title"] == "Question")["sentences"][0]["text"]
    assert not any(c["check"] == "story_beats_complete" and not c["ok"] for c in validate_script(sc, FACTS, "en"))


def test_hook_prefers_a_punchy_non_setting_fact():
    sc = gen("story_beats")
    hook = sc["sections"][0]["sentences"][0]["text"]
    assert "1831" not in hook                                                    # the dated context goes to the setting beat


def test_beats_that_the_material_cannot_support_are_skipped_and_reported():
    facts = [F(1, "Tea is a drink."), F(2, "Many people enjoy it daily."), F(3, "It comes in many varieties.")]
    sc = gen("story_beats", facts)
    assert any("no fact states a cause" in w for w in sc["warnings"]) and any("no fact with a date or place" in w for w in sc["warnings"])
    titles = [s["title"] for s in sc["sections"]]
    assert "Explanation" not in titles and "Question" not in titles                 # no question without an answer
    chk = next(c for c in validate_script(sc, facts, "en") if c["check"] == "story_beats_complete")
    assert not chk["ok"] and chk["level"] == "warn" and "explanation" in chk["detail"]


def test_story_beats_falls_back_for_unsupported_language_or_too_few_facts():
    sc = gen("story_beats", FACTS[:2])
    assert sc["method"] == "extractive_template" and "beats" not in sc and any("standard structure" in w for w in sc["warnings"])
    sc2 = gen("story_beats", lang="kn")
    assert "beats" not in sc2


def test_other_styles_are_unchanged():
    for st in ("educational", "storytelling", "news"):
        sc = gen(st)
        assert sc["method"] == "extractive_template" and "beats" not in sc
        assert [s["title"] for s in sc["sections"]][:2] == ["Hook", "Introduction"] and sc["sections"][-1]["title"] == "Conclusion"
        assert not any(c["check"] == "story_beats_complete" for c in validate_script(sc, FACTS, "en"))


def test_story_beats_hinglish_uses_native_lines():
    sc = gen("story_beats", lang="hinglish")
    assert sc["beats"] and any("Toh yeh kaise" in x["text"] for s in sc["sections"] for x in s["sentences"])


def test_story_beats_is_refused_for_source_commentary(env, tmp_path):
    from tests.fixtures import tone_tts
    from workflows.topic_to_video import TopicWorkflow
    _, s, _, jm = env
    f = tmp_path / "n.txt"
    f.write_text("Habits form through repeated cues and rewards in everyday life.")
    wf = TopicWorkflow(jm, s, {}, tts=tone_tts())
    with pytest.raises(ValueError, match="story_beats"):
        wf.create("t", "en", style="story_beats", sources=[str(f)])


# ---- video QA ----------------------------------------------------------------------------------------------------------
def ff(tmp, name, vf, af, dur=8, size="320x240"):
    out = tmp / name
    vsrc = f"{vf}=s={size}:r=25:d={dur}" if "=" not in vf else f"{vf}:s={size}:r=25:d={dur}"
    asrc = f"{af}:d={dur}" if "=" in af and "," not in af else f"{af.split(',')[0]}:d={dur}," + ",".join(af.split(",")[1:]) if "," in af else f"{af}=d={dur}"
    args = ["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", vsrc, "-f", "lavfi", "-i", asrc, "-shortest",
            "-pix_fmt", "yuv420p", str(out)]
    subprocess.run(args, check=True)
    return out


@needs_ffmpeg
def test_clean_clip_passes_every_advisory_check(tmp_path):
    v = ff(tmp_path, "ok.mp4", "testsrc2", "sine=f=440")
    cs = videoqa.checks(videoqa.analyze(v), planned_cuts=3)
    names = {c["check"] for c in cs}
    assert {"qa_loudness_in_range", "qa_true_peak_ok", "qa_no_long_silence", "qa_no_frozen_video", "qa_no_unexpected_cuts", "qa_brightness_ok"} <= names
    assert all(c["ok"] for c in cs) and all(c["level"] == "warn" for c in cs)


@needs_ffmpeg
def test_silence_frozen_black_and_cuts_are_detected(tmp_path):
    v = ff(tmp_path, "bad.mp4", "color=c=black", "anullsrc=r=44100:cl=mono", dur=8)      # silent + black + frozen
    r = videoqa.analyze(v)
    byname = {c["check"]: c for c in videoqa.checks(r, planned_cuts=0)}
    assert not byname["qa_no_long_silence"]["ok"] and not byname["qa_no_frozen_video"]["ok"] and not byname["qa_brightness_ok"]["ok"]
    assert r["silences"] and r["frozen"] and r["brightness"]["near_black_share"] > 0.9
    # alternating white and black = many hard cuts
    cut = tmp_path / "cuts.mp4"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "color=c=white:s=160x120:r=25:d=1", "-f", "lavfi", "-i", "color=c=black:s=160x120:r=25:d=1",
                    "-filter_complex", "[0][1][0][1][0][1][0][1]concat=n=8:v=1:a=0", str(cut)], check=True)
    cs = {c["check"]: c for c in videoqa.checks(videoqa.analyze(cut), planned_cuts=1, has_audio=False)}
    assert not cs["qa_no_unexpected_cuts"]["ok"] and "qa_loudness_in_range" not in cs


@needs_ffmpeg
def test_loud_clipped_audio_is_flagged(tmp_path):
    v = ff(tmp_path, "loud.mp4", "testsrc2", "sine=f=300,volume=40dB")
    c = {x["check"]: x for x in videoqa.checks(videoqa.analyze(v))}
    assert not c["qa_true_peak_ok"]["ok"] or not c["qa_loudness_in_range"]["ok"]


def test_probe_failure_becomes_a_note_not_an_exception(tmp_path, monkeypatch):
    monkeypatch.setattr(videoqa, "loudness", lambda v: (_ for _ in ()).throw(RuntimeError("boom")))
    monkeypatch.setattr(videoqa, "_ff", lambda a: "")
    rep = videoqa.analyze(tmp_path / "missing.mp4")
    assert rep["loudness"] is None and any("loudness probe failed" in n for n in rep["notes"])
    assert any(c["check"] == "qa_probe_note" and not c["ok"] for c in videoqa.checks(rep))


@needs_ffmpeg
def test_qa_video_keeps_old_checks_and_adds_advisory_ones(tmp_path):
    v = ff(tmp_path, "a.mp4", "testsrc2", "sine=f=440", dur=6, size="1920x1080")
    narr = {"duration": 6.0, "placeholder": False, "timeline_drift_s": 0.0, "natural_voice": True}
    res = {"sources": [1], "facts": []}
    args = (str(v), "landscape", narr, None, None, [], [], res, [], None)
    deep = quality_checker.qa_video(*args)
    plain = quality_checker.qa_video(*args, deep=False)
    names = {c["check"] for c in deep["checks"]}
    assert {c["check"] for c in plain["checks"]} <= names and "qa_brightness_ok" in names and "qa_brightness_ok" not in {c["check"] for c in plain["checks"]}
    assert all(c["level"] == "warn" for c in deep["checks"] if c["check"].startswith("qa_"))
    assert deep["passed"] == plain["passed"]                                   # advisory checks never change pass/fail
    for k in ("video_exists", "playable", "resolution", "audio_present", "no_black_frames", "real_narration"):
        assert k in names


@needs_ffmpeg
def test_qa_video_cli_command(tmp_path):
    v = ff(tmp_path, "c.mp4", "testsrc2", "sine=f=440", dur=4)
    root = Path(__file__).resolve().parent.parent
    out = subprocess.run([sys.executable, str(root / "agent.py"), "qa-video", str(v), "--json"], capture_output=True, text=True)
    assert out.returncode == 0, out.stderr
    d = json.loads(out.stdout[out.stdout.index("{"):])
    assert d["loudness"] and any(c["check"] == "qa_brightness_ok" for c in d["checks"])
    bad = subprocess.run([sys.executable, str(root / "agent.py"), "qa-video", str(tmp_path / "nope.mp4")], capture_output=True, text=True)
    assert "no such file" in bad.stdout
